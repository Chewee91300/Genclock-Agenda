package fr.monagenda.alarmes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class EventStore(context: Context) {
    private val prefs = context.getSharedPreferences("agenda_events", Context.MODE_PRIVATE)

    fun load(): List<AgendaEvent> {
        val array = JSONArray(prefs.getString("events", "[]"))
        return (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                AgendaEvent(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    description = o.optString("description"),
                    timeMillis = o.getLong("timeMillis"),
                    reminderMode = o.getString("reminderMode"),
                    leadMinutes = o.getInt("leadMinutes")
                )
            }.getOrNull()
        }.sortedBy { it.timeMillis }
    }

    fun save(events: List<AgendaEvent>) {
        val array = JSONArray()
        events.forEach { e ->
            array.put(JSONObject().apply {
                put("id", e.id)
                put("title", e.title)
                put("description", e.description)
                put("timeMillis", e.timeMillis)
                put("reminderMode", e.reminderMode)
                put("leadMinutes", e.leadMinutes)
            })
        }
        prefs.edit().putString("events", array.toString()).apply()
    }
}
