package fr.monagenda.alarmes

data class AgendaEvent(
    val id: Long,
    val title: String,
    val description: String,
    val timeMillis: Long,
    val reminderMode: String, // "notification" ou "alarm"
    val leadMinutes: Int,
    val outlookEventId: Long? = null
)
