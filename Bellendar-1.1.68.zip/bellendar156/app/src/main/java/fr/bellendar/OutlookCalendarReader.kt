package fr.bellendar

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.Calendar

data class DeviceCalendar(val id: Long, val displayName: String, val accountName: String, val accountType: String)

object OutlookCalendarReader {
    private const val PREFS_NAME = "calendar_sync"
    private const val KEY_SELECTED_IDS = "selected_calendar_ids"
    private const val KEY_DELETED_SOURCE_EVENT_IDS = "deleted_source_event_ids"

    private fun deletedSourceEventIds(context: Context): Set<Long> =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getStringSet(KEY_DELETED_SOURCE_EVENT_IDS, emptySet()).orEmpty()
            .mapNotNull { it.toLongOrNull() }.toSet()

    fun listCalendars(context: Context): List<DeviceCalendar> {
        if (!hasPermission(context)) return emptyList()
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME, CalendarContract.Calendars.ACCOUNT_NAME, CalendarContract.Calendars.ACCOUNT_TYPE)
        val result = mutableListOf<DeviceCalendar>()
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, "${CalendarContract.Calendars.VISIBLE}=1", null, "${CalendarContract.Calendars.ACCOUNT_NAME} ASC, ${CalendarContract.Calendars.CALENDAR_DISPLAY_NAME} ASC")?.use { cursor ->
            val id = cursor.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
            val name = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
            val account = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_NAME)
            val type = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_TYPE)
            while (cursor.moveToNext()) result += DeviceCalendar(cursor.getLong(id), cursor.getString(name).orEmpty().ifBlank { "Calendrier" }, cursor.getString(account).orEmpty(), cursor.getString(type).orEmpty())
        }
        return result
    }

    fun selectedCalendarIds(context: Context, calendars: List<DeviceCalendar> = listCalendars(context)): Set<Long> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_SELECTED_IDS)) return calendars.map { it.id }.toSet()
        return prefs.getStringSet(KEY_SELECTED_IDS, emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun saveSelectedCalendarIds(context: Context, ids: Set<Long>) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putStringSet(KEY_SELECTED_IDS, ids.map { it.toString() }.toSet()).apply()
    }

    /** Retourne un calendrier sélectionné et réellement modifiable par l'application. */
    fun firstWritableSelectedCalendarId(context: Context): Long? {
        if (!hasPermission(context) || !hasWritePermission(context)) return null
        val selected = selectedCalendarIds(context)
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.SYNC_EVENTS,
            CalendarContract.Calendars.VISIBLE
        )
        var destination: Long? = null
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            null,
            null,
            "${CalendarContract.Calendars._ID} ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
            val accessCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
            val syncCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.SYNC_EVENTS)
            val visibleCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.VISIBLE)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val access = cursor.getInt(accessCol)
                val syncEnabled = cursor.getInt(syncCol) == 1
                val visible = cursor.getInt(visibleCol) == 1
                if (visible && syncEnabled && access >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR &&
                    (selected.isEmpty() || id in selected)
                ) {
                    destination = id
                    break
                }
            }
        }
        return destination
    }

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    fun readEvents(context: Context, selectedCalendarIds: Set<Long> = selectedCalendarIds(context)): List<AgendaEvent> {
        if (!hasPermission(context)) return emptyList()

        val now = Calendar.getInstance()
        val begin = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            add(Calendar.YEAR, -1)
            set(Calendar.MONTH, Calendar.JANUARY)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }.timeInMillis
        val end = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            add(Calendar.YEAR, 2)
            set(Calendar.MONTH, Calendar.DECEMBER)
            set(Calendar.DAY_OF_MONTH, 31)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
        }.timeInMillis

        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(builder, begin)
        android.content.ContentUris.appendId(builder, end)

        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.CALENDAR_ID
        )
        val result = mutableListOf<AgendaEvent>()
        // Certains fournisseurs (notamment les calendriers synchronisés) peuvent republier
        // une ligne après sa suppression. On mémorise les IDs supprimés pour éviter
        // que ces événements réapparaissent dans Bellendar lors d'une nouvelle lecture.
        val deletedSourceIds = deletedSourceEventIds(context)
        context.contentResolver.query(
            builder.build(),
            projection,
            null,
            null,
            "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
            val titleCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
            val beginCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
            val descCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.DESCRIPTION)
            val calendarCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_ID)
            while (cursor.moveToNext()) {
                val language = context.getSharedPreferences("interface", Context.MODE_PRIVATE).getString("app_language", "fr") ?: "fr"
                val title = cursor.getString(titleCol).orEmpty().ifBlank {
                    when (language) { "en" -> "(Untitled)"; "es" -> "(Sin título)"; "de" -> "(Ohne Titel)"; "pt" -> "(Sem título)"; else -> "(Sans titre)" }
                }
                val start = cursor.getLong(beginCol)
                val eventId = cursor.getLong(idCol)
                val calendarId = cursor.getLong(calendarCol)
                if (calendarId !in selectedCalendarIds || eventId in deletedSourceIds) continue
                val description = cursor.getString(descCol).orEmpty()
                // Distinct negative IDs keep imported entries separate from locally-created events.
                val stableId = -((eventId * 100_003L) + ((start / 60_000L) % 100_003L) + 1L)
                result += AgendaEvent(
                    id = stableId,
                    title = title,
                    description = if (description.isBlank()) when (language) {
                        "en" -> "Android calendar synchronized (Outlook or another account)"
                        "es" -> "Calendario de Android sincronizado (Outlook u otra cuenta)"
                        "de" -> "Synchronisierter Android-Kalender (Outlook oder anderes Konto)"
                        "pt" -> "Calendário Android sincronizado (Outlook ou outra conta)"
                        else -> "Calendrier Android synchronisé (Outlook ou autre compte)"
                    } else description,
                    timeMillis = start,
                    reminderMode = "outlook",
                    leadMinutes = 0,
                    outlookEventId = eventId
                )
            }
        }
        return result.distinctBy { it.id }
    }

    data class UpdateResult(val success: Boolean, val reason: String = "")

    /** Met à jour un événement importé et conserve le motif précis d'un éventuel refus. */
    fun updateLinkedEventDetailed(context: Context, event: AgendaEvent): UpdateResult {
        val linkedId = event.outlookEventId
            ?: return UpdateResult(false, "identifiant de l'événement source absent")
        if (!hasPermission(context)) return UpdateResult(false, "autorisation de lecture du calendrier absente")
        if (!hasWritePermission(context)) return UpdateResult(false, "autorisation d'écriture du calendrier absente")
        return try {
            val uri = android.content.ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, linkedId)
            val projection = arrayOf(CalendarContract.Events._ID, CalendarContract.Events.CALENDAR_ID, CalendarContract.Events.TITLE)
            var calendarId: Long? = null
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val calendarCol = cursor.getColumnIndexOrThrow(CalendarContract.Events.CALENDAR_ID)
                    calendarId = cursor.getLong(calendarCol)
                }
            }
            if (calendarId == null) return UpdateResult(false, "événement source introuvable (ID $linkedId)")
            val calendarUri = android.content.ContentUris.withAppendedId(CalendarContract.Calendars.CONTENT_URI, calendarId!!)
            val accessProjection = arrayOf(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
            context.contentResolver.query(calendarUri, accessProjection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val access = cursor.getInt(cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL))
                    val name = cursor.getString(cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)).orEmpty()
                    if (access < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                        return UpdateResult(false, "le calendrier « $name » est en lecture seule (niveau d'accès $access)")
                    }
                }
            }
            val values = android.content.ContentValues().apply {
                put(CalendarContract.Events.TITLE, event.title)
                put(CalendarContract.Events.DESCRIPTION, event.description)
                put(CalendarContract.Events.DTSTART, event.timeMillis)
                put(CalendarContract.Events.DTEND, event.endTimeMillis ?: (event.timeMillis + 60L * 60L * 1000L))
                put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
            }
            val count = context.contentResolver.update(uri, values, null, null)
            if (count == 1) UpdateResult(true) else UpdateResult(false, "le fournisseur calendrier a confirmé $count ligne(s) modifiée(s)")
        } catch (e: SecurityException) {
            UpdateResult(false, "permission refusée : ${e.message ?: "SecurityException"}")
        } catch (e: Exception) {
            UpdateResult(false, "${e.javaClass.simpleName} : ${e.message ?: "erreur du fournisseur calendrier"}")
        }
    }

    fun updateLinkedEvent(context: Context, event: AgendaEvent): Boolean =
        updateLinkedEventDetailed(context, event).success

    data class DeleteResult(val success: Boolean, val reason: String = "")

    /** Supprime un événement source et expose le motif précis d'un éventuel refus. */
    fun deleteEventDetailed(context: Context, event: AgendaEvent): DeleteResult {
        val sourceId = event.outlookEventId
            ?: return DeleteResult(false, "identifiant de l'événement source absent")
        if (!hasPermission(context)) {
            return DeleteResult(false, "autorisation Android READ_CALENDAR absente")
        }
        if (!hasWritePermission(context)) {
            return DeleteResult(false, "autorisation Android WRITE_CALENDAR absente")
        }

        return try {
            val eventUri = android.content.ContentUris.withAppendedId(
                CalendarContract.Events.CONTENT_URI, sourceId
            )
            val eventProjection = arrayOf(
                CalendarContract.Events._ID,
                CalendarContract.Events.CALENDAR_ID
            )
            var calendarId: Long? = null
            context.contentResolver.query(eventUri, eventProjection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    calendarId = cursor.getLong(cursor.getColumnIndexOrThrow(CalendarContract.Events.CALENDAR_ID))
                }
            }
            if (calendarId == null) {
                // L'événement a déjà été supprimé de la source (par exemple directement
                // dans Outlook). Il ne faut pas bloquer la suppression de sa copie dans
                // Bellendar : mémoriser l'ID comme supprimé et terminer avec succès.
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val ids = prefs.getStringSet(KEY_DELETED_SOURCE_EVENT_IDS, emptySet())
                    .orEmpty().toMutableSet()
                ids.add(sourceId.toString())
                prefs.edit().putStringSet(KEY_DELETED_SOURCE_EVENT_IDS, ids).commit()
                return DeleteResult(true, "événement déjà absent du calendrier source ; copie Bellendar supprimée")
            }

            var calendarName = "calendrier source"
            var accountName = ""
            var accessLevel: Int? = null
            val calendarUri = android.content.ContentUris.withAppendedId(
                CalendarContract.Calendars.CONTENT_URI, calendarId!!
            )
            val calendarProjection = arrayOf(
                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                CalendarContract.Calendars.ACCOUNT_NAME,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL
            )
            context.contentResolver.query(calendarUri, calendarProjection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    calendarName = cursor.getString(cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)).orEmpty().ifBlank { calendarName }
                    accountName = cursor.getString(cursor.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_NAME)).orEmpty()
                    accessLevel = cursor.getInt(cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL))
                }
            }

            if (accessLevel != null && accessLevel!! < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                return DeleteResult(
                    false,
                    "le calendrier « $calendarName » est en lecture seule (niveau d'accès $accessLevel). Le compte $accountName doit autoriser la modification depuis Android."
                )
            }

            val deletedRows = context.contentResolver.delete(eventUri, null, null)
            if (deletedRows <= 0) {
                var stillExists = false
                context.contentResolver.query(
                    eventUri,
                    arrayOf(CalendarContract.Events._ID),
                    null, null, null
                )?.use { cursor -> stillExists = cursor.moveToFirst() }
                val account = if (accountName.isBlank()) "" else " (compte $accountName)"
                return DeleteResult(
                    false,
                    if (stillExists) {
                        "le fournisseur Android a refusé la suppression dans « $calendarName »$account (0 ligne supprimée). Vérifie les droits du compte et la synchronisation Outlook."
                    } else {
                        "l'événement n'existe déjà plus dans le calendrier Android ; actualise la liste des événements."
                    }
                )
            }

            // Certains fournisseurs synchronisés republient la ligne depuis le serveur.
            // Mémoriser l'ID évite qu'elle réapparaisse dans Bellendar après synchronisation.
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val ids = prefs.getStringSet(KEY_DELETED_SOURCE_EVENT_IDS, emptySet())
                .orEmpty().toMutableSet()
            ids.add(sourceId.toString())
            prefs.edit().putStringSet(KEY_DELETED_SOURCE_EVENT_IDS, ids).commit()
            DeleteResult(true)
        } catch (e: SecurityException) {
            DeleteResult(false, "permission refusée par Android : ${e.message ?: "SecurityException"}")
        } catch (e: Exception) {
            DeleteResult(false, "${e.javaClass.simpleName} : ${e.message ?: "erreur du fournisseur calendrier"}")
        }
    }

    fun deleteEvent(context: Context, event: AgendaEvent): Boolean =
        deleteEventDetailed(context, event).success

    /**
     * Met à jour prioritairement les événements déjà liés à un calendrier Android
     * (y compris les événements importés depuis Outlook, dont l'identifiant Bellendar est négatif).
     * Le calendrier d'origine est conservé : on ne redirige jamais une modification vers
     * le premier calendrier sélectionné.
     */
    fun syncLocalEventsToCalendar(context: Context, localEvents: List<AgendaEvent>, calendarId: Long?, includeRestoredEvents: Boolean = false): List<AgendaEvent> {
        if (!hasWritePermission(context)) return localEvents
        val resolver = context.contentResolver
        val result = localEvents.toMutableList()
        localEvents.forEachIndexed { index, event ->
            val linkedId = event.outlookEventId

            // Un événement importé possède déjà l'identifiant de l'événement Android/Outlook.
            // Il faut le mettre à jour directement, même si son ID Bellendar est négatif.
            if (linkedId != null) {
                // Ne jamais recréer un événement importé : mise à jour exclusive de son ID source.
                updateLinkedEvent(context, event)
                return@forEachIndexed
            }

            // Les événements Outlook lus en direct ne doivent pas être recréés.
            // Les événements restaurés depuis une sauvegarde ont perdu leur ancien
            // outlookEventId : ils peuvent être publiés explicitement vers le calendrier choisi,
            // même si leur identifiant Bellendar historique est négatif.
            // Lors d'une publication explicite, tout événement sans outlookEventId
            // est local/non lié, y compris ceux restaurés avec reminderMode="outlook".
            // reminderMode décrit le rappel, pas l'existence d'un lien Outlook.
            if ((event.id < 0 && !includeRestoredEvents) || calendarId == null || calendarId <= 0L) {
                return@forEachIndexed
            }

            val eventEnd = event.endTimeMillis ?: (event.timeMillis + 60L * 60L * 1000L)
            // Avant toute insertion, rechercher si cette fiche a déjà été publiée.
            // Une publication précédente peut avoir réussi côté calendrier alors que
            // Bellendar n'a pas encore persisté le nouvel outlookEventId (fermeture,
            // interruption ou synchronisation concurrente). Sans ce contrôle, une
            // nouvelle sauvegarde recrée le même rendez-vous dans Outlook.
            val existingId = try {
                var found: Long? = null
                val selection = "${CalendarContract.Events.CALENDAR_ID}=? AND ${CalendarContract.Events.TITLE}=? AND ${CalendarContract.Events.DTSTART}=? AND ${CalendarContract.Events.DTEND}=?"
                val args = arrayOf(calendarId.toString(), event.title, event.timeMillis.toString(), eventEnd.toString())
                resolver.query(
                    CalendarContract.Events.CONTENT_URI,
                    arrayOf(CalendarContract.Events._ID, CalendarContract.Events.DESCRIPTION),
                    selection, args, "${CalendarContract.Events._ID} ASC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(CalendarContract.Events._ID)
                    val descCol = cursor.getColumnIndexOrThrow(CalendarContract.Events.DESCRIPTION)
                    while (cursor.moveToNext()) {
                        if (cursor.getString(descCol).orEmpty() == event.description) {
                            found = cursor.getLong(idCol)
                            break
                        }
                    }
                }
                found
            } catch (error: Exception) {
                android.util.Log.w("BellendarCalendar", "Vérification d'un doublon impossible pour ${event.id}", error)
                null
            }
            if (existingId != null) {
                result[index] = event.copy(outlookEventId = existingId)
                return@forEachIndexed
            }

            val values = android.content.ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calendarId)
                put(CalendarContract.Events.TITLE, event.title)
                put(CalendarContract.Events.DESCRIPTION, event.description)
                put(CalendarContract.Events.DTSTART, event.timeMillis)
                put(CalendarContract.Events.DTEND, eventEnd)
                put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 0)
                put(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_BUSY)
                put(CalendarContract.Events.STATUS, CalendarContract.Events.STATUS_CONFIRMED)
            }
            val uri = try {
                resolver.insert(CalendarContract.Events.CONTENT_URI, values)
            } catch (error: Exception) {
                android.util.Log.e("BellendarCalendar", "Échec publication événement ${event.id} vers calendrier $calendarId", error)
                null
            }
            if (uri != null) {
                val newId = android.content.ContentUris.parseId(uri)
                result[index] = event.copy(outlookEventId = newId)
            }
        }
        return result
    }

    fun hasWritePermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

}
