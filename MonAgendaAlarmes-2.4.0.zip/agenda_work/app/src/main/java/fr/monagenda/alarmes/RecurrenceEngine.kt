package fr.monagenda.alarmes

import java.util.Calendar

/** Génère les occurrences d'une série à la demande, sans les enregistrer comme événements indépendants. */
object RecurrenceEngine {
    fun expand(events: List<AgendaEvent>, fromMillis: Long, untilMillis: Long): List<AgendaEvent> {
        val result = mutableListOf<AgendaEvent>()
        events.forEach { event ->
            if (event.recurrenceType == "NONE") {
                if (event.timeMillis in fromMillis..untilMillis) result += event
                return@forEach
            }
            val duration = event.endTimeMillis?.minus(event.timeMillis)?.coerceAtLeast(0L)
            val anchor = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
            val anchorDay = anchor.get(Calendar.DAY_OF_MONTH)
            var occurrenceIndex = 0
            var cursor = event.timeMillis
            var guard = 0
            while (cursor <= untilMillis && guard++ < 5000) {
                if (event.recurrenceEndMillis != null && cursor > event.recurrenceEndMillis) break
                if (event.recurrenceCount != null && occurrenceIndex >= event.recurrenceCount) break
                val current = Calendar.getInstance().apply { timeInMillis = cursor }
                val anchorWeek = Calendar.getInstance().apply { timeInMillis = event.timeMillis; setFirstDayOfWeek(Calendar.MONDAY); set(Calendar.DAY_OF_WEEK, Calendar.MONDAY); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                val currentWeek = Calendar.getInstance().apply { timeInMillis = cursor; setFirstDayOfWeek(Calendar.MONDAY); set(Calendar.DAY_OF_WEEK, Calendar.MONDAY); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                val weeksBetween = ((currentWeek.timeInMillis - anchorWeek.timeInMillis) / (7L * 24L * 60L * 60L * 1000L)).toInt()
                val matches = when (event.recurrenceType) {
                    "DAILY", "CUSTOM", "MONTHLY", "YEARLY" -> true
                    "WEEKLY" -> weeksBetween % event.recurrenceInterval == 0 && (event.recurrenceDays.isEmpty() || current.get(Calendar.DAY_OF_WEEK) in event.recurrenceDays)
                    else -> false
                }
                if (matches) {
                    if (cursor >= fromMillis) {
                        val occurrenceId = if (occurrenceIndex == 0) event.id else (event.id xor (cursor / 60_000L)).let { if (it == 0L) cursor else it }
                        result += event.copy(
                            id = occurrenceId,
                            timeMillis = cursor,
                            endTimeMillis = duration?.let { cursor + it },
                            recurrenceType = "NONE"
                        )
                    }
                    occurrenceIndex++
                }
                when (event.recurrenceType) {
                    "DAILY" -> current.add(Calendar.DAY_OF_MONTH, event.recurrenceInterval)
                    "CUSTOM" -> current.add(Calendar.DAY_OF_MONTH, event.recurrenceInterval)
                    "WEEKLY" -> current.add(Calendar.DAY_OF_MONTH, 1)
                    "MONTHLY" -> {
                        val next = Calendar.getInstance().apply { timeInMillis = event.timeMillis; add(Calendar.MONTH, occurrenceIndex * event.recurrenceInterval) }
                        next.set(Calendar.DAY_OF_MONTH, minOf(anchorDay, next.getActualMaximum(Calendar.DAY_OF_MONTH)))
                        cursor = next.timeInMillis
                        continue
                    }
                    "YEARLY" -> {
                        val next = Calendar.getInstance().apply { timeInMillis = event.timeMillis; add(Calendar.YEAR, occurrenceIndex * event.recurrenceInterval) }
                        next.set(Calendar.DAY_OF_MONTH, minOf(anchorDay, next.getActualMaximum(Calendar.DAY_OF_MONTH)))
                        cursor = next.timeInMillis
                        continue
                    }
                    else -> break
                }
                cursor = current.timeInMillis
            }
        }
        return result.distinctBy { it.id }.sortedBy { it.timeMillis }
    }
}
