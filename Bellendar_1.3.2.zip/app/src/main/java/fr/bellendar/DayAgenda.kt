package fr.bellendar

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
internal fun DayAgenda(selected: Long, events: List<AgendaEvent>, nowMillis: Long, onEditEvent: (AgendaEvent) -> Unit, onAddAtTime: (Long, Long?) -> Unit, onDeleteEvent: (AgendaEvent) -> Unit, expanded: Boolean, creationActive: Boolean = true, modifier: Modifier = Modifier) {
    val uiLocale = currentUiLocale()
    val dayEvents = events.filter { sameDay(it.timeMillis, selected) }.sortedBy { it.timeMillis }
    val overlapLanes = remember(dayEvents) { calculateOverlapLanes(dayEvents) }
    val context = LocalContext.current
    var attachmentTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var eventPendingDeletion by remember { mutableStateOf<AgendaEvent?>(null) }
    var rangeStartY by remember { mutableFloatStateOf(Float.NaN) }
    var rangeEndY by remember { mutableFloatStateOf(Float.NaN) }
    var creationStartMillis by remember(selected) { mutableStateOf<Long?>(null) }
    var creationEndMillis by remember(selected) { mutableStateOf<Long?>(null) }
    val density = LocalDensity.current.density
    val scrollState = rememberScrollState()
    // Échelle compacte : 36 dp par tranche de 30 minutes (72 dp/heure).
    // Les événements utilisent exactement cette même échelle, à la minute près.
    val rowHeight = 36.dp
    val minuteHeight = 1.2f
    Column(
        modifier.fillMaxWidth()
            .padding(bottom = 6.dp)
    ) {
        Text(tr("Planning horaire · précision 30 min"), style = MaterialTheme.typography.labelLarge)
        BoxWithConstraints(
            Modifier.fillMaxWidth()
                .weight(1f)
                .verticalScroll(scrollState)
        ) {
            // Capturer la largeur depuis BoxWithConstraints avant les lambdas imbriquées.
            val timelineWidth = this.maxWidth
            // Par défaut, afficher 07:00–22:00. Étendre à la journée complète
            // uniquement si un événement touche la plage nocturne (00:00–07:00
            // ou 22:00–23:59), en tenant compte de son heure de fin.
            // Les deux extensions nocturnes sont indépendantes : un événement
            // tôt le matin n'ouvre pas la plage du soir, et inversement.
            val hasEarlyEvent = dayEvents.any { event ->
                val startCal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val startMinute = startCal.get(Calendar.HOUR_OF_DAY) * 60 + startCal.get(Calendar.MINUTE)
                val endMillis = event.endTimeMillis?.takeIf { it > event.timeMillis }
                val endMinute = endMillis?.let {
                    val endCal = Calendar.getInstance().apply { timeInMillis = it }
                    endCal.get(Calendar.HOUR_OF_DAY) * 60 + endCal.get(Calendar.MINUTE)
                } ?: startMinute
                startMinute < 7 * 60 || (endMillis != null && startMinute < 7 * 60 && endMinute > 0)
            }
            val hasLateEvent = dayEvents.any { event ->
                val startCal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val startMinute = startCal.get(Calendar.HOUR_OF_DAY) * 60 + startCal.get(Calendar.MINUTE)
                val endMillis = event.endTimeMillis?.takeIf { it > event.timeMillis }
                val endMinute = endMillis?.let {
                    val endCal = Calendar.getInstance().apply { timeInMillis = it }
                    endCal.get(Calendar.HOUR_OF_DAY) * 60 + endCal.get(Calendar.MINUTE)
                } ?: startMinute
                startMinute >= 22 * 60 || (endMillis != null && endMinute > 22 * 60)
            }
            val visibleStartHour = if (hasEarlyEvent) 0 else 7
            val visibleEndHour = if (hasLateEvent) 24 else 22
            // Graduation toutes les 30 minutes ; la position des événements
            // reste calculée à la minute près sur la même échelle verticale.
            val firstHalfHour = visibleStartHour * 2
            val halfHourCount = (visibleEndHour - visibleStartHour) * 2
            val timelineHeight = rowHeight * halfHourCount
            // Grille et événements partagent la même origine temporelle.
            Box(
                Modifier.fillMaxWidth().height(timelineHeight)
                    .pointerInput(selected, visibleStartHour, visibleEndHour) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { offset -> rangeStartY = offset.y; rangeEndY = offset.y },
                            onDrag = { change, _ -> rangeEndY = change.position.y; change.consume() },
                            onDragEnd = {
                                if (!rangeStartY.isNaN() && !rangeEndY.isNaN()) {
                                    val a = (visibleStartHour * 60 + (minOf(rangeStartY, rangeEndY) / density / minuteHeight).toInt()).coerceIn(0, 1439)
                                    val b = (visibleStartHour * 60 + (maxOf(rangeStartY, rangeEndY) / density / minuteHeight).toInt()).coerceIn(0, 1439)
                                    val start = ((a + 7) / 15) * 15
                                    val finish = (((b + 7) / 15) * 15).coerceAtLeast(start + 15).coerceAtMost(1440)
                                    val day = Calendar.getInstance().apply { timeInMillis = selected }
                                    day.set(Calendar.HOUR_OF_DAY, (start / 60).coerceAtMost(23)); day.set(Calendar.MINUTE, start % 60)
                                    day.set(Calendar.SECOND, 0); day.set(Calendar.MILLISECOND, 0)
                                    val end = Calendar.getInstance().apply { timeInMillis = day.timeInMillis }
                                    end.add(Calendar.MINUTE, finish - start)
                                    onAddAtTime(day.timeInMillis, end.timeInMillis)
                                }
                                rangeStartY = Float.NaN; rangeEndY = Float.NaN
                            },
                            onDragCancel = { rangeStartY = Float.NaN; rangeEndY = Float.NaN }
                        )
                    }
                    .pointerInput(selected, visibleStartHour, visibleEndHour) {
                        detectTapGestures(onDoubleTap = { offset ->
                            val rawMinutes = visibleStartHour * 60 + (offset.y / density / minuteHeight).toInt()
                            val snappedMinutes = (((rawMinutes.coerceIn(0, 1439) + 7) / 15) * 15).coerceAtMost(1365)
                            val day = Calendar.getInstance().apply { timeInMillis = selected }
                            day.set(Calendar.HOUR_OF_DAY, snappedMinutes / 60)
                            day.set(Calendar.MINUTE, snappedMinutes % 60)
                            day.set(Calendar.SECOND, 0)
                            day.set(Calendar.MILLISECOND, 0)
                            val finish = (day.clone() as Calendar).apply { add(Calendar.MINUTE, 60) }
                            creationStartMillis = day.timeInMillis
                            creationEndMillis = finish.timeInMillis
                            onAddAtTime(day.timeInMillis, finish.timeInMillis)
                        })
                    }
            ) {
                Column(Modifier.fillMaxWidth()) {
                    repeat(halfHourCount) { index ->
                        val halfHour = firstHalfHour + index
                        val hour = halfHour / 2
                        val minute = (halfHour % 2) * 30
                        // Chaque graduation est placée au début exact de son intervalle
                        // de 30 minutes ; les événements gardent leur placement à la minute.
                        Box(Modifier.fillMaxWidth().height(rowHeight)) {
                            Text(
                                String.format(Locale.FRANCE, "%02d:%02d", hour, minute),
                                modifier = Modifier.width(52.dp).align(Alignment.TopStart),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelSmall
                            )
                            HorizontalDivider(
                                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                        }
                    }
                }
                if (!rangeStartY.isNaN() && !rangeEndY.isNaN()) {
                    val top = minOf(rangeStartY, rangeEndY)
                    val height = (kotlin.math.abs(rangeEndY - rangeStartY)).coerceAtLeast(18f)
                    Surface(
                        modifier = Modifier.offset(y = with(LocalDensity.current) { top.toDp() })
                            .fillMaxWidth().padding(start = 56.dp).height(with(LocalDensity.current) { height.toDp() }),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                    ) {}
                }
                // Sélection persistante de création : le rectangle reste visible derrière la feuille d'édition.
                val selectedStart = creationStartMillis
                val selectedEnd = creationEndMillis
                if (creationActive && selectedStart != null && selectedEnd != null && selectedEnd > selectedStart) {
                    val startCal = Calendar.getInstance().apply { timeInMillis = selectedStart }
                    val endCal = Calendar.getInstance().apply { timeInMillis = selectedEnd }
                    val startMinute = startCal.get(Calendar.HOUR_OF_DAY) * 60 + startCal.get(Calendar.MINUTE)
                    val endMinute = endCal.get(Calendar.HOUR_OF_DAY) * 60 + endCal.get(Calendar.MINUTE)
                    val topDp = ((startMinute - visibleStartHour * 60).coerceAtLeast(0) * minuteHeight).dp
                    val heightDp = ((endMinute - startMinute).coerceAtLeast(15) * minuteHeight).dp
                    Box(Modifier.offset(y = topDp).fillMaxWidth().padding(start = 56.dp).height(heightDp)) {
                        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(7.dp), border = androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary)) {}
                        Box(Modifier.align(Alignment.TopCenter).offset(y = (-7).dp).size(width = 46.dp, height = 14.dp)
                            .clip(RoundedCornerShape(7.dp)).background(MaterialTheme.colorScheme.primary)
                            .pointerInput(selected) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    val delta = (drag.y / density / minuteHeight).roundToInt()
                                    val current = Calendar.getInstance().apply { timeInMillis = creationStartMillis ?: selectedStart }
                                    val old = current.get(Calendar.HOUR_OF_DAY) * 60 + current.get(Calendar.MINUTE)
                                    val next = (((old + delta + 7) / 15) * 15).coerceIn(visibleStartHour * 60, endMinute - 15)
                                    current.set(Calendar.HOUR_OF_DAY, next / 60); current.set(Calendar.MINUTE, next % 60); current.set(Calendar.SECOND, 0); current.set(Calendar.MILLISECOND, 0)
                                    val end = Calendar.getInstance().apply { timeInMillis = creationEndMillis ?: selectedEnd }
                                    val duration = ((end.timeInMillis - (creationStartMillis ?: selectedStart)) / 60000L).toInt().coerceAtLeast(15)
                                    end.timeInMillis = current.timeInMillis + duration * 60000L
                                    creationStartMillis = current.timeInMillis; creationEndMillis = end.timeInMillis
                                    onAddAtTime(current.timeInMillis, end.timeInMillis)
                                }
                            })
                        Box(Modifier.align(Alignment.BottomCenter).offset(y = 7.dp).size(width = 46.dp, height = 14.dp)
                            .clip(RoundedCornerShape(7.dp)).background(MaterialTheme.colorScheme.primary)
                            .pointerInput(selected) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    val delta = (drag.y / density / minuteHeight).roundToInt()
                                    val start = Calendar.getInstance().apply { timeInMillis = creationStartMillis ?: selectedStart }
                                    val startMinute = start.get(Calendar.HOUR_OF_DAY) * 60 + start.get(Calendar.MINUTE)
                                    val end = Calendar.getInstance().apply { timeInMillis = creationEndMillis ?: selectedEnd }
                                    val oldEnd = end.get(Calendar.HOUR_OF_DAY) * 60 + end.get(Calendar.MINUTE)
                                    val next = (((oldEnd + delta + 7) / 15) * 15).coerceIn(startMinute + 15, 1425)
                                    end.add(Calendar.MINUTE, next - oldEnd)
                                    creationEndMillis = end.timeInMillis
                                    onAddAtTime(start.timeInMillis, end.timeInMillis)
                                }
                            })
                    }
                }
                dayEvents.forEach { event ->
                    val cal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                    val startMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                    val end = event.endTimeMillis?.takeIf { it > event.timeMillis }
                    val durationMinutes = end?.let { ((it - event.timeMillis) / 60000L).toInt() } ?: 12
                    val y = ((startMinutes - visibleStartHour * 60).coerceAtLeast(0) * minuteHeight).dp
                    val h = if (end == null) 36.dp else (durationMinutes * minuteHeight).coerceAtLeast(34f).dp
                    // Utiliser les couloirs calculés pour réellement séparer les événements
                    // simultanés en vue Jour (le calcul existait déjà mais n'était pas appliqué).
                    val lane = overlapLanes[event.id]?.first ?: 0
                    val laneCount = (overlapLanes[event.id]?.second ?: 1).coerceAtLeast(1)
                    val availableEventWidth = (timelineWidth - 60.dp).coerceAtLeast(1.dp)
                    val laneWidth = availableEventWidth / laneCount
                    val startLabel = SimpleDateFormat("HH:mm", uiLocale).format(Date(event.timeMillis))
                    val endLabel = end?.let { SimpleDateFormat("HH:mm", uiLocale).format(Date(it)) }
                    val eventBackground = parseEventColor(event.colorHex) ?: MaterialTheme.colorScheme.secondaryContainer
                    val eventForeground = eventTextColor(eventBackground)
                    Surface(
                        modifier = Modifier
                            .offset(x = 56.dp + laneWidth * lane, y = y)
                            .width(laneWidth)
                            .height(h)
                            .pointerInput(event.id, y, visibleStartHour) {
                                detectTapGestures(
                                    onLongPress = { eventPendingDeletion = event },
                                    onTap = { onEditEvent(event) },
                                    onDoubleTap = { tapOffset ->
                                        val absoluteY = y.value * density + tapOffset.y
                                        val rawMinutes = visibleStartHour * 60 + (absoluteY / (density * minuteHeight)).toInt()
                                        val snappedMinutes = ((rawMinutes.coerceIn(0, 1439) + 2) / 5) * 5
                                        val day = Calendar.getInstance().apply { timeInMillis = selected }
                                        day.set(Calendar.HOUR_OF_DAY, (snappedMinutes / 60).coerceAtMost(23))
                                        day.set(Calendar.MINUTE, snappedMinutes % 60)
                                        day.set(Calendar.SECOND, 0)
                                        day.set(Calendar.MILLISECOND, 0)
                                        onAddAtTime(day.timeInMillis, null)
                                    }
                                )
                            },
                        shape = RoundedCornerShape(7.dp),
                        color = eventBackground
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = if (end == null) 1.dp else 2.dp),
                            verticalArrangement = if (end == null) Arrangement.Center else Arrangement.spacedBy(1.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "$startLabel  ${event.title}",
                                    modifier = Modifier.weight(1f),
                                    color = eventForeground,
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = if (end == null) 1 else 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (event.attachments.isNotEmpty()) {
                                    Icon(
                                        Icons.Default.AttachFile,
                                        contentDescription = tr("Ouvrir les pièces jointes"),
                                        tint = eventForeground,
                                        modifier = Modifier.size(19.dp).clickable { attachmentTarget = event }
                                    )
                                }
                                val hasAlarm = event.reminderMode == "alarm" || event.reminderMode == "both"
                                val hasNotification = event.reminderMode == "notification" || event.reminderMode == "both"
                                if (hasNotification) {
                                    Icon(Icons.Default.Notifications, contentDescription = tr("Notification programmée"),
                                        tint = eventForeground, modifier = Modifier.padding(start = 5.dp).size(18.dp))
                                }
                                if (hasAlarm) {
                                    Icon(Icons.Default.Alarm, contentDescription = tr("Alarme programmée"),
                                        tint = eventForeground, modifier = Modifier.padding(start = 5.dp).size(18.dp))
                                }
                            }
                            if (end != null) {
                                Text(
                                    "$startLabel – $endLabel  ·  ${durationMinutes / 60} h ${durationMinutes % 60} min",
                                    color = eventForeground,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
                // Curseur de l'heure actuelle, uniquement sur la journée d'aujourd'hui.
                if (sameDay(selected, nowMillis)) {
                    val nowCal = Calendar.getInstance().apply { timeInMillis = nowMillis }
                    val nowMinutes = nowCal.get(Calendar.HOUR_OF_DAY) * 60 + nowCal.get(Calendar.MINUTE)
                    val cursorY = ((nowMinutes - visibleStartHour * 60).coerceAtLeast(0) * minuteHeight).dp
                    if (nowMinutes in (visibleStartHour * 60)..(visibleEndHour * 60)) {
                        val eventUnderCursor = dayEvents.firstOrNull { event ->
                            val visualEnd = event.endTimeMillis?.takeIf { it > event.timeMillis }
                                ?: (event.timeMillis + 30L * 60L * 1000L)
                            nowMillis >= event.timeMillis && nowMillis < visualEnd
                        }
                        val cursorColor = eventUnderCursor?.let { event ->
                            eventTextColor(parseEventColor(event.colorHex) ?: MaterialTheme.colorScheme.secondaryContainer)
                        } ?: MaterialTheme.colorScheme.error
                        Row(
                            Modifier.offset(y = cursorY - 1.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(9.dp).background(cursorColor, RoundedCornerShape(50)))
                            Box(Modifier.weight(1f).height(2.dp).background(cursorColor))
                        }
                    }
                }
            }
        }
    }
    attachmentTarget?.let { event ->
        AlertDialog(
            onDismissRequest = { attachmentTarget = null },
            title = { Text(tr("Pièces jointes")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    event.attachments.forEach { attachment ->
                        TextButton(onClick = {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(attachment.uri), attachment.mimeType.ifBlank { "*/*" })
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            runCatching { context.startActivity(intent) }
                            attachmentTarget = null
                        }) {
                            Icon(Icons.Default.InsertDriveFile, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(attachment.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { attachmentTarget = null }) { Text(tr("Fermer")) } }
        )
    }
    eventPendingDeletion?.let { event ->
        AlertDialog(
            onDismissRequest = { eventPendingDeletion = null },
            title = { Text(tr("Supprimer l’événement ?")) },
            text = { Text(tr("Voulez-vous vraiment supprimer « ${event.title} » ?")) },
            confirmButton = {
                TextButton(onClick = { onDeleteEvent(event); eventPendingDeletion = null }) { Text(tr("Supprimer")) }
            },
            dismissButton = { TextButton(onClick = { eventPendingDeletion = null }) { Text(tr("Annuler")) } }
        )
    }
}

