package fr.monagenda.alarmes

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val isEnglish = context.getSharedPreferences("interface", Context.MODE_PRIVATE).getString("app_language", "fr") == "en"
            val channelId = "agenda_reminders_v3"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
                manager.createNotificationChannel(NotificationChannel(channelId, if (isEnglish) "Calendar reminders" else "Rappels Mon Agenda", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(sound, attrs); enableVibration(true)
                })
            }
            val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(intent.getStringExtra("title") ?: if (isEnglish) "Reminder" else "Rappel")
                .setContentText(intent.getStringExtra("description") ?: if (isEnglish) "Your event is scheduled now." else "Votre événement est prévu maintenant.")
                .setCategory(NotificationCompat.CATEGORY_REMINDER).setAutoCancel(true).setContentIntent(open).build()
            manager.notify(intent.getLongExtra("eventId", 0L).hashCode(), n)
        } catch (_: Exception) { }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val service = Intent(context, AlarmPlaybackService::class.java).apply {
            putExtras(intent)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
            else context.startService(service)
        } catch (_: Exception) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            EventStore(context).load().forEach { event ->
                if (event.reminderMode == "alarm" || event.reminderMode == "both") ReminderScheduler.scheduleAlarm(context, event)
                if (event.reminderMode == "notification" || event.reminderMode == "both") ReminderScheduler.schedule(context, event)
            }
        } catch (_: Exception) { }
    }
}
