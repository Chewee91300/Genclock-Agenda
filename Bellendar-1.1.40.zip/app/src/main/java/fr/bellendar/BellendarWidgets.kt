package fr.bellendar

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.app.WallpaperManager
import android.os.Build
import android.location.LocationManager
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private object BellendarWidgetUi {
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    private fun launch(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, 7101, intent, FLAGS)
    }
    private fun wallpaperTextColor(context: Context): Int {
        if (Build.VERSION.SDK_INT >= 27) {
            val wallpaper = WallpaperManager.getInstance(context)
            val colors = runCatching { wallpaper.getWallpaperColors(WallpaperManager.FLAG_SYSTEM) }.getOrNull()
            val color = colors?.primaryColor?.toArgb()
            if (color != null) {
                val luminance = (0.2126 * Color.red(color) + 0.7152 * Color.green(color) + 0.0722 * Color.blue(color)) / 255.0
                return if (luminance < 0.48) Color.WHITE else Color.BLACK
            }
        }
        return Color.WHITE
    }
    private fun accentColor(fg: Int): Int = if (fg == Color.WHITE) 0xFFFFD76A.toInt() else 0xFF245A9B.toInt()
    private fun applyTransparentTheme(context: Context, rv: RemoteViews, textIds: List<Int>, accentIds: List<Int> = emptyList()) {
        val fg = wallpaperTextColor(context)
        val accent = accentColor(fg)
        rv.setInt(R.id.widget_root, "setBackgroundColor", Color.TRANSPARENT)
        textIds.forEach { rv.setTextColor(it, fg) }
        accentIds.forEach { rv.setTextColor(it, accent) }
    }
    private fun weatherText(context: Context): String {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) return "Météo : autorisez la localisation dans les paramètres"
        return "Météo : actualisation…"
    }
    private fun refreshWeather(context: Context, appWidgetId: Int) {
        Thread {
            val result = runCatching {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
                val loc = providers.mapNotNull { provider ->
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                        runCatching { lm.getLastKnownLocation(provider) }.getOrNull() else null
                }.maxByOrNull { it.time } ?: error("Position indisponible")
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,weather_code&timezone=auto")
                val connection = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 7000; readTimeout = 7000 }
                val json = connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
                val current = json.getJSONObject("current")
                val temp = current.getDouble("temperature_2m").toInt()
                val code = current.getInt("weather_code")
                val condition = when (code) {
                    0 -> "Ensoleillé"; 1, 2 -> "Peu nuageux"; 3 -> "Couvert"; 45, 48 -> "Brouillard"
                    51, 53, 55, 56, 57 -> "Bruine"; 61, 63, 65, 66, 67 -> "Pluie"; 71, 73, 75, 77 -> "Neige"
                    80, 81, 82 -> "Averses"; 85, 86 -> "Averses de neige"; 95, 96, 99 -> "Orage"; else -> "Conditions variables"
                }
                val symbol = when (code) { 0 -> "☀"; 1,2,3 -> "☁"; 45,48 -> "〰"; in 51..67, in 80..82 -> "☂"; in 71..77,85,86 -> "❄"; else -> "⚡" }
                "$symbol  $temp°C · $condition"
            }.getOrElse { "Météo indisponible" }
            val manager = AppWidgetManager.getInstance(context)
            val views = RemoteViews(context.packageName, R.layout.widget_agenda)
            views.setTextViewText(R.id.widget_weather, result)
            applyTransparentTheme(context, views, listOf(R.id.widget_title, R.id.widget_date, R.id.widget_clock, R.id.widget_weather, R.id.widget_line1, R.id.widget_line2, R.id.widget_line3, R.id.widget_line4), listOf(R.id.widget_footer))
            manager.partiallyUpdateAppWidget(appWidgetId, views)
        }.start()
    }
    private fun colors(context: Context): Triple<Int, Int, Int> {
        val p = context.getSharedPreferences("interface", Context.MODE_PRIVATE)
        val theme = p.getString("selected_theme", "elegance") ?: "elegance"
        val primary = when(theme) {
            "purple" -> 0xFF7653A6.toInt(); "sunset" -> 0xFFB65F45.toInt(); "greenenergy" -> 0xFF287765.toInt()
            "blackgold" -> 0xFF9A7A3D.toInt(); "midnight" -> 0xFFB99AFF.toInt(); "pastel" -> 0xFF8876C7.toInt()
            "glass" -> 0xFF356BD6.toInt(); "nature" -> 0xFF477B5A.toInt(); else -> 0xFF245A9B.toInt()
        }
        val dark = theme == "blackgold" || theme == "midnight"
        val bg = if (dark) 0xFF1D293A.toInt() else 0xFFF7FAFF.toInt()
        val fg = if (dark) 0xFFF2EFE8.toInt() else 0xFF202B39.toInt()
        return Triple(primary, bg, fg)
    }
    private fun applyTheme(context: Context, rv: RemoteViews, root: Int, textIds: List<Int>, accentIds: List<Int> = emptyList()) {
        val (primary, _, fg) = colors(context)
        val dark = context.getSharedPreferences("interface", Context.MODE_PRIVATE).getString("selected_theme", "elegance") in listOf("blackgold", "midnight")
        rv.setInt(root, "setBackgroundResource", if (dark) R.drawable.widget_dark_bg else R.drawable.widget_card_bg)
        textIds.forEach { rv.setTextColor(it, fg) }
        accentIds.forEach { rv.setTextColor(it, primary) }
    }
    fun update(context: Context, manager: AppWidgetManager, ids: IntArray, layout: Int, kind: String) {
        val allEvents = EventStore(context).load().sortedBy { it.timeMillis }
        val events = allEvents.filter { it.timeMillis > System.currentTimeMillis() - 60_000 }
        ids.forEach { id ->
            val rv = RemoteViews(context.packageName, layout)
            val open = launch(context)
            rv.setOnClickPendingIntent(R.id.widget_root, open)
            when(kind) {
                "next" -> {
                    val next = events.firstOrNull()
                    rv.setTextViewText(R.id.widget_next_title, next?.title ?: "Aucun événement à venir")
                    rv.setTextViewText(R.id.widget_next_time, next?.let { SimpleDateFormat("EEEE d MMMM · HH:mm", Locale.getDefault()).format(Date(it.timeMillis)) } ?: "Votre agenda est libre")
                    val remaining = next?.let { ((it.timeMillis - System.currentTimeMillis()).coerceAtLeast(0) / 60000) }
                    val countdown = when { remaining == null -> ""; remaining < 60 -> "Dans $remaining min"; remaining < 1440 -> "Dans ${remaining / 60} h ${remaining % 60} min"; else -> "Dans ${remaining / 1440} j ${remaining % 1440 / 60} h" }
                    rv.setTextViewText(R.id.widget_next_countdown, countdown)
                    applyTheme(context, rv, R.id.widget_root, listOf(R.id.widget_next_title, R.id.widget_next_time), listOf(R.id.widget_next_countdown))
                }
                "agenda" -> {
                    val now = Calendar.getInstance()
                    val todayEvents = allEvents.filter { sameDayWidget(it.timeMillis, now.timeInMillis) && it.timeMillis >= System.currentTimeMillis() - 60_000 }.sortedBy { it.timeMillis }
                    val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
                    val showTomorrow = todayEvents.isEmpty()
                    val displayed = if (showTomorrow) allEvents.filter { sameDayWidget(it.timeMillis, tomorrow.timeInMillis) }.sortedBy { it.timeMillis } else todayEvents
                    rv.setTextViewText(R.id.widget_title, if (showTomorrow) "BELLENDAR · DEMAIN" else "BELLENDAR · AUJOURD'HUI")
                    rv.setTextViewText(R.id.widget_date, SimpleDateFormat("EEEE d MMMM yyyy", Locale.getDefault()).format(if (showTomorrow) tomorrow.time else now.time))
                    rv.setTextViewText(R.id.widget_clock, SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
                    rv.setTextViewText(R.id.widget_weather, weatherText(context))
                    val rows = listOf(R.id.widget_line1, R.id.widget_line2, R.id.widget_line3, R.id.widget_line4)
                    rows.forEachIndexed { index, viewId ->
                        val e = displayed.getOrNull(index)
                        rv.setTextViewText(viewId, e?.let { "${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it.timeMillis))}   ${it.title}" } ?: if (index == 0) if (showTomorrow) "Aucun événement demain" else "Aucun événement à venir aujourd'hui" else "")
                    }
                    applyTransparentTheme(context, rv, rows + listOf(R.id.widget_date, R.id.widget_clock, R.id.widget_weather, R.id.widget_title), listOf(R.id.widget_footer))
                    rows.forEachIndexed { index, viewId -> displayed.getOrNull(index)?.colorHex?.let { hex -> runCatching { rv.setTextColor(viewId, Color.parseColor(hex)) } } }
                    refreshWeather(context, id)
                }
                "shortcut" -> {
                    rv.setTextViewText(R.id.widget_shortcut_date, SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date()))
                    rv.setOnClickPendingIntent(R.id.widget_shortcut_add, open)
                    applyTheme(context, rv, R.id.widget_root, listOf(R.id.widget_shortcut_date), listOf(R.id.widget_shortcut_add))
                }
                "month" -> updateMonth(context, rv, allEvents)
            }
            manager.updateAppWidget(id, rv)
        }
    }
    private fun updateMonth(context: Context, rv: RemoteViews, events: List<AgendaEvent>) {
        val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
        rv.setTextViewText(R.id.widget_month_title, SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time).uppercase(Locale.getDefault()))
        rv.setTextColor(R.id.widget_month_title, colors(context).first)
        val firstOffset = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val (_, _, fg) = colors(context)
        for (i in 0 until 42) {
            val id = context.resources.getIdentifier("day_$i", "id", context.packageName)
            if (id == 0) continue
            val day = i - firstOffset + 1
            if (day in 1..days) {
                val date = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, day) }.timeInMillis
                val hasEvent = events.any { sameDayWidget(it.timeMillis, date) }
                val isToday = sameDayWidget(date, System.currentTimeMillis())
                rv.setTextViewText(id, if (hasEvent) "•$day" else day.toString())
                rv.setTextColor(id, if (hasEvent) colors(context).first else fg)
                rv.setInt(id, "setBackgroundColor", if (isToday) 0x223569A8 else android.graphics.Color.TRANSPARENT)
                } else rv.setTextViewText(id, "")
            rv.setOnClickPendingIntent(id, launch(context))
        }
    }
    private fun sameDayWidget(a: Long, b: Long): Boolean {
        val x = Calendar.getInstance().apply { timeInMillis = a }
        val y = Calendar.getInstance().apply { timeInMillis = b }
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
    }
}

abstract class BellendarBaseWidget : AppWidgetProvider() {
    abstract val layout: Int
    abstract val kind: String
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = BellendarWidgetUi.update(context, manager, ids, layout, kind)
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) refresh(context)
    }
    companion object {
        const val ACTION_REFRESH = "fr.bellendar.action.REFRESH_WIDGETS"
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            listOf(
                Triple(WidgetNextProvider::class.java, R.layout.widget_next, "next"),
                Triple(WidgetAgendaProvider::class.java, R.layout.widget_agenda, "agenda"),
                Triple(WidgetMonthProvider::class.java, R.layout.widget_month, "month"),
                Triple(WidgetShortcutProvider::class.java, R.layout.widget_shortcut, "shortcut")
            ).forEach { (clazz, layout, kind) ->
                val component = ComponentName(context, clazz)
                val ids = manager.getAppWidgetIds(component)
                if (ids.isNotEmpty()) BellendarWidgetUi.update(context, manager, ids, layout, kind)
            }
        }
    }
}
class WidgetNextProvider : BellendarBaseWidget() { override val layout = R.layout.widget_next; override val kind = "next" }
class WidgetAgendaProvider : BellendarBaseWidget() { override val layout = R.layout.widget_agenda; override val kind = "agenda" }
class WidgetMonthProvider : BellendarBaseWidget() { override val layout = R.layout.widget_month; override val kind = "month" }
class WidgetShortcutProvider : BellendarBaseWidget() { override val layout = R.layout.widget_shortcut; override val kind = "shortcut" }
