Mon Agenda & Alarmes — version 2.6.0

Amélioration architecturale : extraction du dictionnaire anglais et des fonctions de traduction de MainActivity.kt vers UiTranslations.kt.

Aucun changement fonctionnel attendu : les appels tr(), currentUiLocale() et les traductions dynamiques sont conservés.
VersionCode : 139.
