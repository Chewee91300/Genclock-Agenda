package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt


@Composable
fun EventCard(event: AgendaEvent, onEdit: () -> Unit, onDelete: () -> Unit, onAlarm: () -> Unit, todayRecap: Boolean = false) {
    val uiLocale = currentUiLocale()
    val context = LocalContext.current
    val date = remember(event.timeMillis, uiLocale) {
        SimpleDateFormat(if (uiLocale == Locale.UK) "EEEE, MMMM d, yyyy 'at' HH:mm" else "EEEE d MMMM yyyy 'à' HH:mm", uiLocale).format(Date(event.timeMillis))
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Box(Modifier.width(5.dp).height(142.dp).background(event.colorHex?.let { runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull() } ?: MaterialTheme.colorScheme.secondary))
            Row(Modifier.padding(horizontal = 11.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = RoundedCornerShape(12.dp), color = event.colorHex?.let { runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull() } ?: MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    val delayLabel = when {
                        todayRecap -> ""
                        event.reminderMode == "outlook" -> ""
                        event.leadMinutes <= 0 -> ""
                        uiLocale == Locale.UK && event.leadMinutes < 60 -> " · in ${event.leadMinutes} min"
                        uiLocale == Locale.UK && event.leadMinutes % 1440 == 0 -> " · in ${event.leadMinutes / 1440} day(s)"
                        uiLocale == Locale.UK && event.leadMinutes % 60 == 0 -> " · in ${event.leadMinutes / 60} hr"
                        uiLocale == Locale.UK -> " · in ${event.leadMinutes / 60} hr ${event.leadMinutes % 60} min"
                        event.leadMinutes < 60 -> " · dans ${event.leadMinutes} min"
                        event.leadMinutes % 1440 == 0 -> " · dans ${event.leadMinutes / 1440} j"
                        event.leadMinutes % 60 == 0 -> " · dans ${event.leadMinutes / 60} h"
                        else -> " · dans ${event.leadMinutes / 60} h ${event.leadMinutes % 60} min"
                    }
                    Text(event.title + delayLabel, fontSize = 17.sp, lineHeight = 20.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (todayRecap) SimpleDateFormat("HH:mm", uiLocale).format(Date(event.timeMillis))
                            else date.replaceFirstChar { it.uppercase() },
                            fontSize = if (todayRecap) 15.sp else 13.sp,
                            lineHeight = 16.sp,
                            fontWeight = if (todayRecap) FontWeight.SemiBold else FontWeight.Normal,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )
                    }
                    event.endTimeMillis?.let { end ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⏱", fontSize = 15.sp)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "${SimpleDateFormat("HH:mm", uiLocale).format(Date(event.timeMillis))} – ${SimpleDateFormat("HH:mm", uiLocale).format(Date(end))}",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (!todayRecap) Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (event.reminderMode == "alarm") Icons.Default.Alarm else Icons.Default.Notifications, null,
                            modifier = Modifier.size(19.dp), tint = when (event.reminderMode) { "alarm" -> Color(0xFFD52E35); "both" -> Color(0xFF8E44AD); else -> MaterialTheme.colorScheme.primary })
                        Spacer(Modifier.width(6.dp))
                        Text((when (event.reminderMode) {
                            "alarm" -> tr("Alarme Mon Agenda")
                            "both" -> tr("Notification + alarme")
                            "outlook" -> tr("Événement Outlook sans rappel")
                            else -> if (event.outlookEventId != null) tr("Rappel Outlook") else tr("Notification")
                        }) + if (event.reminderMode == "outlook") "" else if (uiLocale == Locale.UK) " · ${event.leadMinutes} min before" else " · ${event.leadMinutes} min avant",
                            fontSize = 13.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    if (!todayRecap && event.attachments.isNotEmpty()) {
                        event.attachments.forEach { attachment ->
                            TextButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(Uri.parse(attachment.uri), attachment.mimeType)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    runCatching { context.startActivity(intent) }
                                },
                                contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)
                            ) {
                                Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(attachment.name, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                    if (!todayRecap) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (event.outlookEventId != null) {
                            OutlinedButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)) {
                                Text(tr("Modifier"), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                            }
                        } else {
                            OutlinedButton(onClick = onAlarm, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)) {
                                Text(tr("Modifier"), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                            }
                        }
                        OutlinedButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                            shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)) {
                            Text(tr("Supprimer"), fontSize = 12.sp, color = MaterialTheme.colorScheme.error, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OutlookReminderEditor(
    event: AgendaEvent,
    onDismiss: () -> Unit,
    onSave: (String, Int, Long, String?, Boolean) -> Unit
) {
    val uiLocale = currentUiLocale()
    var notificationEnabled by remember(event.id) { mutableStateOf(event.reminderMode == "notification" || event.reminderMode == "both") }
    var alarmEnabled by remember(event.id) { mutableStateOf(event.reminderMode == "alarm" || event.reminderMode == "both" || event.reminderMode == "outlook") }
    var alarmTimeMillis by remember(event.id) {
        mutableLongStateOf(event.alarmTimeMillis ?: run {
            val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
            val eventMinute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val alarmMinute = (eventMinute - 15).coerceAtLeast(0)
            c.set(Calendar.HOUR_OF_DAY, alarmMinute / 60)
            c.set(Calendar.MINUTE, alarmMinute % 60)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.timeInMillis
        })
    }
    var error by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var soundUri by remember(event.id) { mutableStateOf(event.alarmSoundUri) }
    var vibrate by remember(event.id) { mutableStateOf(event.vibrate) }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }
    val alarmTimeText = SimpleDateFormat("HH:mm", uiLocale).format(Date(alarmTimeMillis))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Rappel de l’événement Outlook")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(event.title, fontWeight = FontWeight.SemiBold)
                Text(SimpleDateFormat(when (uiLocale.language) {
                    "en" -> "EEEE, MMMM d 'at' HH:mm"
                    "es" -> "EEEE d 'de' MMMM 'a las' HH:mm"
                    "de" -> "EEEE, d. MMMM 'um' HH:mm"
                    else -> "EEEE d MMMM 'à' HH:mm"
                }, uiLocale).format(Date(event.timeMillis)))
                Text(tr("Le jour du rendez-vous reste inchangé. Seule l’heure de l’alarme sera modifiée."), style = MaterialTheme.typography.bodySmall)
                Text(tr("Type de rappel"), fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it })
                    Text(tr("Notification"))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it })
                    Text(tr("Alarme sonore"))
                }
                if (!notificationEnabled && !alarmEnabled) Text(tr("Sélectionne au moins un type de rappel."), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text(tr("Heure de l’alarme"), fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                    TimePickerDialog(
                        context,
                        { _, hour, minute ->
                            val selected = Calendar.getInstance().apply {
                                timeInMillis = event.timeMillis
                                set(Calendar.HOUR_OF_DAY, hour)
                                set(Calendar.MINUTE, minute)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                            alarmTimeMillis = selected.timeInMillis
                            error = false
                        },
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true
                    ).show()
                }) { Text(tr("Choisir : $alarmTimeText")) }
                Text(tr("Sonnerie"), fontWeight = FontWeight.SemiBold)
                Text(soundLabel, style = MaterialTheme.typography.bodySmall)
                val ringtonePickerTitle = tr("Choisir la sonnerie de l’alarme")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, ringtonePickerTitle)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                        }
                        ringtonePicker.launch(picker)
                    }) { Text(tr("Choisir une sonnerie")) }
                    TextButton(onClick = { soundUri = null }) { Text(tr("Par défaut")) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Vibreur"), modifier = Modifier.weight(1f))
                    Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                }
                if (error) Text(tr("Choisis une heure future, le même jour que le rendez-vous."), color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val eventDay = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val alarmDay = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                val sameDay = eventDay.get(Calendar.YEAR) == alarmDay.get(Calendar.YEAR) &&
                    eventDay.get(Calendar.DAY_OF_YEAR) == alarmDay.get(Calendar.DAY_OF_YEAR)
                if (!notificationEnabled && !alarmEnabled) error = true
                else if (alarmEnabled && (!sameDay || alarmTimeMillis <= System.currentTimeMillis())) error = true
                else onSave(when { notificationEnabled && alarmEnabled -> "both"; alarmEnabled -> "alarm"; else -> "notification" }, 0, alarmTimeMillis, soundUri, vibrate)
            }) { Text(tr("Enregistrer")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Annuler")) } }
    )


}

