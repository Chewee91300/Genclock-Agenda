package fr.monagenda.alarmes

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
internal fun HelpGuide(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Aide et mode d'emploi"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HelpSection("Les quatre vues de l'agenda", "Passe d'une vue à l'autre avec les boutons Aujourd'hui, Jour, Semaine et Mois en haut de l'écran.")
                HelpSection("Ajouter un événement", "Aujourd'hui : passe en vue Jour ou Semaine, puis touche deux fois un créneau vide à l'heure souhaitée.\nJour : touche deux fois un emplacement libre de la grille horaire.\nSemaine : touche deux fois une case vide du jour et de l'heure souhaités.\nMois : sélectionne d'abord le jour dans le calendrier, puis utilise le bouton +.")
                HelpSection("Modifier un événement", "Dans les vues Jour et Semaine, touche une fois le bloc de l'événement. Dans les listes d'événements (Aujourd'hui et sous le calendrier du mois), utilise le bouton Modifier. La fiche permet de changer le titre, la date, les heures, la couleur, les rappels, les répétitions et les pièces jointes.")
                HelpSection("Supprimer un événement", "Dans les vues Jour et Semaine, maintiens le doigt sur le bloc de l'événement jusqu'à l'affichage de la confirmation, puis choisis Supprimer. Dans les listes, utilise le bouton Supprimer. Pour une série récurrente, lis attentivement le choix proposé : occurrence, cette occurrence et les suivantes, ou série entière.")
                HelpSection("Naviguer dans les dates", "Dans les vues Jour, Semaine et Mois, utilise les flèches pour avancer ou reculer. Le bouton Aujourd'hui du navigateur revient à la date du jour. Dans la vue Mois, touche une date pour afficher ses événements en dessous.")
                HelpSection("Naviguer dans la vue Semaine", "Fais défiler horizontalement la grille. Lorsque tu atteins une butée, continue le geste vers la gauche pour afficher la semaine suivante ou vers la droite pour afficher la semaine précédente. Appuie sur le bouton Semaine en haut de l'écran pour revenir à la semaine en cours.")
                HelpSection("Créer une alarme ou un rappel", "Dans la fiche événement, choisis Notification, Alarme ou les deux, puis règle le délai avant le rendez-vous. Une alarme nécessite l'autorisation Android Alarmes et rappels. Les notifications nécessitent l'autorisation Notifications.")
                HelpSection("Répéter un événement", "Dans la fiche, active la répétition et choisis la fréquence (quotidienne, hebdomadaire, mensuelle, annuelle ou personnalisée). Selon le type, règle les jours, la date de fin ou le nombre d'occurrences. Vérifie les options avant de modifier ou supprimer une série.")
                HelpSection("Choisir la langue", "Lors de la première ouverture, sélectionne Français, English, Español ou Deutsch avant d'utiliser l'agenda. Seules les langues dont l'interface est traduite sont proposées. Tu peux ensuite modifier la langue dans Paramètres.")
                HelpSection("Personnaliser l'affichage", "Ouvre Paramètres pour choisir la langue, le thème, la vue de démarrage et les préférences d'alarme. Dans la vue Semaine, pince l'écran avec deux doigts pour ajuster le zoom, puis fais glisser un doigt horizontalement, verticalement ou en diagonale pour déplacer la vue.")
                HelpSection("Ajouter rapidement un événement", "Utilise le microphone pour dicter un rendez-vous ou l'appareil photo pour lire un agenda papier. Vérifie et corrige toujours les informations détectées avant de confirmer l'import.")
                HelpSection("Calendrier Outlook", "Le bouton Actualiser en haut de l'écran permet de relire les événements du calendrier Android/Outlook synchronisé sur le téléphone. L'accès au calendrier doit être autorisé. La modification ou suppression d'un événement Outlook agit sur le calendrier source.")
                HelpSection("Pièces jointes", "Depuis la fiche événement, ajoute un document ou une photo. Les pièces jointes sont copiées dans l'espace de sauvegarde de l'application pour les conserver avec les événements.")
                HelpSection("Sauvegarde et restauration", "Au premier démarrage, choisis un dossier de sauvegarde si Android le demande. Conserve ce dossier et son contenu : il permet de retrouver tes événements et pièces jointes lors d'une restauration.")
                HelpSection("Comprendre les symboles", "Le symbole de cloche indique une alarme ; la cloche de notification indique une notification. Les couleurs peuvent différencier tes événements. Dans la vue Mois, la légende sous le calendrier rappelle les principaux types de rappel.")
                HelpSection("Autorisations et dépannage", "Si une alarme ne sonne pas, vérifie dans Paramètres les alarmes exactes, les notifications et le mode Ne pas déranger. Vérifie également le volume des alarmes et les restrictions de batterie du téléphone. Les intitulés des réglages peuvent varier selon le fabricant Android.")
                Spacer(Modifier.height(4.dp))
                Text(tr("Astuce : ouvre cette aide à tout moment avec le bouton ? dans la barre supérieure."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fermer")) } }
    )
}

@Composable
private fun HelpSection(title: String, body: String) {
    Text(tr(title), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    Text(tr(body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
}
