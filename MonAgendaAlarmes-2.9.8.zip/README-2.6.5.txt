Alarenda – version 2.6.5

Ajout d’un bouton Aide dans la barre supérieure. Le guide intégré explique :
- les vues Aujourd’hui, Jour, Semaine et Mois ;
- l’ajout, la modification et la suppression d’événements depuis les différentes vues ;
- les gestes de double-tap et d’appui long ;
- la navigation dans les dates ;
- les alarmes, notifications et récurrences ;
- les thèmes, la dictée vocale, l’import photo et le calendrier Outlook ;
- les pièces jointes, la sauvegarde et les autorisations Android.

Le guide suit la langue française ou anglaise sélectionnée dans l’application.
Identifiant Android conservé : fr.monagenda.alarmes.
Version code : 144.
