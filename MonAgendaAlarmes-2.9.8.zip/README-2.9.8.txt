Mon Agenda & Alarmes — version 2.9.8

Cette archive reprend le projet complet de la version 2.9.8 (versionCode 164).

Paramètres organisés par rubriques :
- Agenda : écran de démarrage, affichage des week-ends et liste des événements du jour.
- Synchronisation : sélection des calendriers de l'appareil.
- Alarmes : seuil de volume et vibration.
- Apparence : thèmes et couleurs.
- Langue : français, anglais, espagnol et allemand.
- Autorisations : état des accès Android et raccourci vers les paramètres système.
- À propos : accessible depuis l'écran principal des paramètres.

Les préférences d'affichage des week-ends et des événements du jour sont mémorisées sur l'appareil.
Aucun changement du numéro de version ni du versionCode n'a été effectué.
