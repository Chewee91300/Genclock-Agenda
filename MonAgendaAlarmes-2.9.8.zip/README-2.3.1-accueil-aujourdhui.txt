Mon Agenda & Alarmes 2.3.1

Nouvelle page d'accueil : Aujourd'hui
- Affiche les événements restant à venir pour la journée courante.
- Les événements sont triés par heure et utilisent les cartes de rendez-vous existantes.
- Les couleurs, les informations d'alarme/notification et les pièces jointes restent visibles.
- Les pièces jointes sont ouvrables depuis la carte de chaque événement, comme dans la liste existante.
- Un état vide est affiché lorsqu'il ne reste aucun événement.

Paramètre « Écran d'accueil » :
- Aujourd'hui (choix par défaut pour les nouvelles installations).
- Dernière vue utilisée (Jour, Semaine ou Mois).
Le choix est conservé dans les préférences locales.

VersionName : 2.3.1
VersionCode : 118

Compilation Android non exécutée dans cet environnement. Vérifier avec GitHub Actions et tester sur appareil.
