Mon Agenda & Alarmes 2.4.1

Corrections d'interface :
- Suppression de l'onglet Papier de la barre des vues.
- Barre des modes Jour/Semaine/Mois/Aujourd'hui défilante horizontalement.
- Horloge avec largeur réservée, sur une seule ligne, sans troncature.
- Bouton + masqué dans la vue Aujourd'hui (ainsi que Jour et Semaine).

VersionCode 120.
Compilation Android à vérifier via GitHub Actions.
