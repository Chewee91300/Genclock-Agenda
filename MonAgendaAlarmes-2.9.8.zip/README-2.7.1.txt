Alarenda 2.7.1

Corrections de compilation après l'ajout de l'espagnol :
- Correction de références dynamiques dans UiTranslations.kt.
- Correction de l'accès aux préférences de langue dans l'initialisation de la reconnaissance vocale.
- Déplacement des scrollBy dans des coroutines dans WeekAgenda.kt afin de respecter les restrictions de suspension de Compose.
- Conservation des langues française, anglaise et espagnole.

Le guide d'aide existant est conservé. La compilation doit être validée par GitHub Actions.
