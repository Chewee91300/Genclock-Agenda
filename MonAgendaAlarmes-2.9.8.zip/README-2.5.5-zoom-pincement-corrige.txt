Mon Agenda & Alarmes 2.5.5
VersionCode : 134

Correction du zoom par pincement du planning hebdomadaire.
Le détecteur multitouch est maintenant placé sur le conteneur de défilement, en passe Initial, avant les détecteurs des cartes d'événements et du scroll vertical. Un geste à deux doigts est donc capturé même si une carte est sous les doigts. Le défilement à un doigt et le double-tap restent gérés par les interactions existantes.

Zoom minimum : 1x (échelle historique). Zoom maximum : 3x.
Aucun bouton ajouté. Zoom mémorisé dans SharedPreferences.

Contrôle effectué : intégrité de l'archive ZIP. Compilation Android et test sur appareil non exécutés.
