Mon Agenda & Alarmes 2.1.14
VersionCode : 112

Nouveauté : détection des chevauchements d'événements.

Lors de l'enregistrement ou de la modification d'un événement, l'application compare sa plage horaire avec les autres événements enregistrés. En cas de chevauchement, une alerte affiche les rendez-vous concernés et propose de revenir à la fiche ou d'enregistrer quand même.

Règles :
- Les événements avec heure de fin sont comparés sur toute leur durée.
- Un événement sans heure de fin est traité comme un instant : il entre en conflit s'il se trouve dans la plage d'un autre événement, ou s'il commence exactement au même instant qu'un autre événement sans durée.
- Deux événements qui se suivent exactement (fin du premier = début du second) ne sont pas considérés comme un chevauchement.
- Les chevauchements qui traversent minuit sont détectés grâce aux horodatages.
- Un événement en cours de modification n'est pas comparé à lui-même.
- L'enregistrement reste possible après avertissement : les chevauchements volontaires ne sont pas bloqués.

Traductions de l'alerte disponibles en français et en anglais.

Compilation Android non exécutée dans cet environnement. Vérifier le workflow GitHub Actions avant installation.
