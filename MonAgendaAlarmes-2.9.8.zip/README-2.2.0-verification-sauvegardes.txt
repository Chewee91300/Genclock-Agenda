MON AGENDA & ALARMES — VERSION 2.2.0

Sécurisation des sauvegardes :
- Validation du JSON et du nombre exact d'événements avant enregistrement.
- Vérification de la copie locale après écriture (relecture et empreinte SHA-256).
- Sauvegarde externe écrite dans un fichier temporaire, puis relue et contrôlée.
- Remplacement du fichier principal uniquement après validation du temporaire.
- Conservation de la sauvegarde externe précédente dans evenements_backup.json.previous.
- Contrôle final après renommage ; restauration de la précédente en cas d'échec.
- Les erreurs sont consignées dans Logcat (EventStore) ; une sauvegarde externe non vérifiée n'est pas annoncée comme réussie.

Version : 2.2.0 (versionCode 114)
Compilation non exécutée dans cet environnement : Gradle n'est pas installé et aucun wrapper Gradle n'est fourni dans le projet.
