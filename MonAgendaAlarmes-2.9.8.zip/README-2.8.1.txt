Alarenda 2.8.1 — contrôle et corrections des traductions

- Révision des traductions de l'interface française, anglaise, espagnole et allemande.
- Complément des textes d'aide pour les quatre langues.
- Correction de plusieurs textes dynamiques : confirmations de suppression, conflits d'import, compteurs, version, volume minimum et choix d'heure.
- Localisation des messages de dictée vocale et des paramètres de thèmes/couleurs.
- Localisation des libellés de calendrier synchronisé sans titre ou sans description.
- Correction des retours à la ligne dans les textes d'aide espagnol et allemand.
- Conservation de l'identifiant Android fr.monagenda.alarmes.

Contrôles effectués :
- Toutes les clés littérales passées à tr() sont présentes dans les trois dictionnaires de traduction.
- Toutes les rubriques et tous les paragraphes de l'aide ont une entrée dans les trois dictionnaires.
- Les messages statiques de l'interface et les messages de retour ont été contrôlés.
- Aucune erreur de syntaxe Kotlin détectée par l'analyse du compilateur Kotlin.

Limite : la compilation Android complète n'a pas été exécutée. L'archive source ne contient pas de Gradle Wrapper et Gradle n'est pas installé dans l'environnement de travail. Vérifier la compilation avec GitHub Actions avant installation.
