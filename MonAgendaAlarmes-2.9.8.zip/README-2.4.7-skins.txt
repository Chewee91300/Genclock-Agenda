Mon Agenda & Alarmes 2.4.7 – Skins premium personnalisables

- 5 skins : Blue Electric, Purple Premium, Sunset Premium, Green Energy, Black Gold.
- Skin Personnalisé avec couleurs hexadécimales pour couleur principale, arrière-plan et surfaces.
- Préférences persistées localement.
- Les couleurs personnalisées des événements ne sont pas modifiées par le changement de skin.
- VersionCode 126.

Compilation Android complète à valider avec GitHub Actions.
