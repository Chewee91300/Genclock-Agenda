Alarenda 2.7.5
VersionCode 154

Correctif de résolution des traductions : les clés absentes en espagnol ou en allemand utilisent désormais la traduction anglaise disponible plutôt que de réafficher silencieusement le texte français. Les traductions spécifiques existantes en français, anglais, espagnol et allemand sont conservées.

Important : cette mesure évite les retours silencieux au français, mais les libellés sans entrée dans les dictionnaires anglais peuvent encore apparaître en français. Une validation écran par écran et une compilation GitHub Actions restent nécessaires.
