Mon Agenda & Alarmes — version 2.6.1 (versionCode 140)

Objectif : poursuivre la modularisation sans modifier volontairement les comportements visibles.

Changements architecturaux :
- AgendaRepository : point d'entrée dédié au chargement, à la sauvegarde, à la programmation et à l'annulation des rappels d'événements.
- AndroidAlarmPermissions : contrôles des autorisations exactes et de l'accès Ne pas déranger centralisés hors de MainActivity.
- MainActivity utilise désormais AgendaRepository pour les opérations de sauvegarde et les opérations courantes de programmation/annulation.
- La logique de traduction reste isolée dans UiTranslations.kt depuis la version précédente.

À vérifier :
- compilation Android complète avec GitHub Actions ;
- création/modification/suppression d'événements ;
- modification et suppression de séries récurrentes ;
- reprogrammation après redémarrage ;
- autorisations Alarmes et rappels / Ne pas déranger.

Limites : cette livraison est une étape de modularisation, pas une refonte totale. Les états Compose, les dialogues et plusieurs flux d'importation restent dans MainActivity. Aucun test sur appareil n'a été exécuté ici.
