Alarenda 2.9.0

Nouvelle fonctionnalité : lors de la suppression d'un événement avec pièces jointes, l'utilisateur peut sélectionner les fichiers à supprimer ou conserver les pièces jointes décochées dans le dossier de sauvegarde.

Version précédente : 2.8.1 (versionCode 156)
Nouvelle version : 2.9.0 (versionCode 157)
Compilation Gradle à valider via GitHub Actions.
