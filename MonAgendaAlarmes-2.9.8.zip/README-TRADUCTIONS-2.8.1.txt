Alarenda 2.8.1 — audit des traductions

Langues de l'interface :
- Français (langue source)
- English
- Español
- Deutsch

Corrections :
- Ajout des traductions espagnole et allemande des états d'autorisation « Activée » et « À vérifier ».
- Complétion des libellés et consignes manquants dans les dictionnaires anglais, espagnol et allemand.
- Traduction des intitulés de dictée vocale, de reconnaissance de rendez-vous, des pièces jointes et des préférences.
- Conservation des traductions dynamiques (dates, heures, compteurs et noms de rendez-vous).

Version de l'application conservée : 2.8.1
versionCode conservé : 156
applicationId conservé : fr.monagenda.alarmes
