Mon Agenda & Alarmes — version 2.4.9

Évolution du moteur de récurrence :
- Conservation d'un identifiant de série et de la date d'origine de chaque occurrence virtuelle.
- Persistance JSON des identifiants de série, dates d'origine et exceptions.
- Exclusion durable des occurrences supprimées ou remplacées individuellement.
- Nouveau gestionnaire métier pour supprimer une occurrence, supprimer la série,
  couper une série à partir d'une occurrence, modifier une occurrence ou modifier
  cette occurrence et les suivantes.
- Compatibilité de lecture avec les anciennes sauvegardes : les nouveaux champs
  sont facultatifs et reçoivent des valeurs par défaut.

La sélection des jours de la semaine déjà présente dans l'éditeur est conservée.

Attention : le moteur et les opérations métier sont ajoutés, mais l'interface de
confirmation du périmètre (cet événement / suivants / série entière) doit encore
être raccordée à tous les points d'édition et de suppression. La compilation
Android et les tests sur appareil restent à effectuer.
