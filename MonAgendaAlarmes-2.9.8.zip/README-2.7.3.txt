Alarenda 2.7.3

Internationalisation : extension des traductions espagnoles des écrans, dialogues, paramètres, messages de dictée et descriptions d’accessibilité. Mise à jour des libellés d’aide concernés. VersionCode 152.

La compilation et la validation exhaustive des écrans doivent être effectuées avec GitHub Actions et sur appareil.
