Mon Agenda & Alarmes 2.4.2 (versionCode 121)

Évolution de l'interface de récurrence :
- Les options de répétition sont désormais regroupées dans une fenêtre dédiée, séparée de la fiche principale de l'événement.
- Choix : aucune, quotidienne, hebdomadaire, mensuelle, annuelle et personnalisée.
- En mode hebdomadaire, sélection des jours de la semaine (Lun à Dim), avec raccourcis Tous, Lun–Ven et Effacer.
- Le résumé de la règle sélectionnée reste visible dans la fiche événement.
- Une règle hebdomadaire ne peut pas être enregistrée sans au moins un jour sélectionné.

La compilation Android et les essais sur appareil doivent être exécutés via GitHub Actions / téléphone avant diffusion.
