Mon Agenda & Alarmes 2.4.6

Refactorisation structurelle : extraction des vues Jour, Semaine, Mois, Papier et navigation calendrier dans des fichiers dédiés ; extraction des composants de thème, des cartes d’événement et de l’éditeur d’événement.

Aucun changement fonctionnel intentionnel. Les modèles, stockage, alarmes, récurrence et sauvegardes sont conservés.

Version Android : versionCode 125, versionName 2.4.6.
Compilation Android complète non exécutée dans cet environnement : lancer le workflow GitHub Actions avant installation.
