Mon Agenda & Alarmes 2.1.13 — English interface completion

Changes:
- Completed English translations for the remaining main-screen, event-editor, reminder-delay, attachment, voice/photo import, and event-card labels.
- Day, week, and month names now follow the selected interface language (French or English), including abbreviated weekday labels and month abbreviations.
- Month-grid weekday initials use M T W T F S S in English and L M M J V S D in French.
- Calendar headings, event date metadata, and weekly paper/day views use the selected language.
- User-entered event titles and descriptions are deliberately preserved exactly as entered; only surrounding interface text and reminder-delay wording are localized.
- French remains the default language.
- Version: 2.1.13, versionCode 111.

Validation:
- Source archive does not include Gradle Wrapper files, and Gradle is not installed in this environment; Android compilation has not been run.
- Run the GitHub Actions workflow to validate Kotlin compilation and APK generation.
- Voice recognition and natural-language date parsing remain French-oriented; this change localizes the interface and date display, not the speech-recognition language or parser.
