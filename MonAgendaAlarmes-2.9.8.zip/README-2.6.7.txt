Alarenda 2.6.7

Correction du déplacement de la vue semaine après zoom : le glissement à un doigt permet maintenant de déplacer simultanément les axes horizontal et vertical, y compris en diagonale. Le pincement à deux doigts conserve le zoom. Les clics et appuis longs restent disponibles tant que le seuil de déplacement n’est pas dépassé.

Version Android : versionCode 146, versionName 2.6.7.
