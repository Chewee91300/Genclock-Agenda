Mon Agenda & Alarmes 2.5.9 (versionCode 138)

Amélioration de l'éditeur de palette personnalisée :
- palettes de couleurs prédéfinies sélectionnables pour chaque couleur ;
- saisie HEX avec aperçu de la couleur ;
- aperçu visuel du rendu de la palette ;
- réinitialisation aux couleurs par défaut ;
- préférences persistées immédiatement.

Compilation Android complète non exécutée dans cet environnement.
