package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt


private val englishUi = mapOf(
    "Paramètres" to "Settings",
    "LANGUE / LANGUAGE" to "LANGUAGE",
    "Langue de l\"application" to "App language",
    "Le français est la langue par défaut. Le choix est mémorisé sur cet appareil." to "French is the default language. Your choice is saved on this device.",
    "APPARENCE" to "APPEARANCE",
    "AUTORISATIONS" to "PERMISSIONS",
    "Ajouter une pièce jointe" to "Add an attachment",
    "Annuler" to "Cancel",
    "Enregistrer" to "Save",
    "Fermer" to "Close",
    "Modifier" to "Edit",
    "Supprimer" to "Delete",
    "À propos" to "About",
    "Aujourd'hui" to "Today",
    "Week-end" to "Weekend",
    "Aucun événement ce jour." to "No events on this day.",
    "Aucune pièce jointe." to "No attachments.",
    "Intitulé" to "Title",
    "Titre" to "Title",
    "Description (facultatif)" to "Description (optional)",
    "Date et heure" to "Date and time",
    "Date et heure (JJ/MM/AAAA HH:mm)" to "Date and time (DD/MM/YYYY HH:mm)",
    "Heure" to "Time",
    "Heure de début : \$voiceStart" to "Start time: \$voiceStart",
    "Heure de fin (JJ/MM/AAAA HH:mm)" to "End time (DD/MM/YYYY HH:mm)",
    "Heure de l’alarme" to "Alarm time",
    "Durée : \$voiceDuration" to "Duration: \$voiceDuration",
    "Durée : non précisée" to "Duration: not specified",
    "Définir une heure de fin" to "Set an end time",
    "Aucune heure de fin ne sera définie pour cet événement." to "No end time will be set for this event.",
    "Fin : " to "End: ",
    "Délai avant l’événement" to "Time before the event",
    "Minutes avant" to "Minutes before",
    "Type de rappel" to "Reminder type",
    "Notification" to "Notification",
    "Alarme" to "Alarm",
    " Les deux" to " Both",
    "Les deux" to "Both",
    "Sonnerie" to "Ringtone",
    "Choisir la sonnerie" to "Choose ringtone",
    "Choisir une sonnerie" to "Choose a ringtone",
    "Vibreur" to "Vibration",
    "Personnaliser l’alarme" to "Customize alarm",
    "Volume minimum des alarmes" to "Minimum alarm volume",
    "VOLUME MINIMUM DES ALARMES" to "MINIMUM ALARM VOLUME",
    "Forcer le vibreur pendant les alarmes" to "Force vibration during alarms",
    "Déclenche la vibration de l’alarme même si le mode silencieux ou le vibreur général est désactivé. Les restrictions Android et Ne pas déranger peuvent toujours s’appliquer." to "Vibrates for alarms even when silent mode or the phone’s general vibration is off. Android restrictions and Do Not Disturb may still apply.",
    "Minimum : \${minimumAlarmVolume.roundToInt()} %" to "Minimum: \${minimumAlarmVolume.roundToInt()}%",
    "Planning hebdomadaire" to "Weekly schedule",
    "AGENDA DE LA SEMAINE" to "WEEKLY AGENDA",
    "Planning horaire · précision 30 min" to "Hourly schedule · 30-minute intervals",
    "Vue agenda papier · ouvrez le plein écran pour afficher les 7 jours simultanément." to "Paper agenda view · open full screen to display all 7 days at once.",
    "Développé par V Da Silva" to "Developed by V Da Silva",
    "Version \$appVersion" to "Version \$appVersion",
    "Votre agenda, vos rappels." to "Your calendar, your reminders.",
    "Organisez vos événements et ne manquez plus aucun rendez-vous." to "Organize your events and never miss an appointment.",
    "Sortir" to "Exit",
    "Plus tard" to "Later",
    "OK" to "OK",
    "Information" to "Information",
    "Attention : le mode Ne pas déranger est actif. Il peut silencier ou limiter les alarmes et notifications de Mon Agenda & Alarmes selon les réglages du téléphone." to "Warning: Do Not Disturb is enabled. Depending on your phone settings, it may silence or limit Mon Agenda & Alarmes alarms and notifications.",
    "Détection du mode Ne pas déranger" to "Do Not Disturb detection",
    "Mode Ne pas déranger activé" to "Do Not Disturb enabled",
    "VÉRIFIER LES PARAMÈTRES" to "CHECK SETTINGS",
    "OUVRIR LES PARAMÈTRES" to "OPEN SETTINGS",
    "Ouvrir les paramètres Android de l’application" to "Open the app’s Android settings",
    "Autoriser les alarmes exactes" to "Allow exact alarms",
    "ACTIVER LES ALARMES EXACTES" to "ENABLE EXACT ALARMS",
    "Pour que les alarmes sonnent à l’heure prévue, Mon Agenda doit être autorisé à utiliser « Alarmes et rappels ». Active cette autorisation dans les paramètres Android." to "To make alarms ring at the scheduled time, Mon Agenda must be allowed to use “Alarms & reminders”. Enable this permission in Android settings.",
    "Pour avertir lorsque le mode Ne pas déranger est activé, Mon Agenda & Alarmes doit pouvoir consulter le mode de concentration du téléphone. Autorise cet accès dans les paramètres Android. L’application ne modifiera pas ce réglage." to "To warn you when Do Not Disturb is enabled, Mon Agenda & Alarmes needs access to your phone’s focus mode. Allow this access in Android settings. The app will not change this setting.",
    "Pièces jointes" to "Attachments",
    "Les fichiers sont copiés dans Documents/MonAgendaAlarmes/Pieces jointes pour être conservés avec la sauvegarde." to "Files are copied to Documents/MonAgendaAlarmes/Attachments so they are kept with your backup.",
    "Importer la sélection" to "Import selection",
    "Les rappels et alarmes restent désactivés après import." to "Reminders and alarms remain disabled after import.",
    "Aucun rendez-vous daté n’a pu être détecté automatiquement. Tu peux corriger la transcription ci-dessous." to "No dated appointments could be detected automatically. You can correct the transcription below.",
    "Vérifier l’événement" to "Review event",
    "Continuer vers la fiche" to "Continue to event details",
    "Recommencer" to "Start over",
    "Recommencer la saisie" to "Start over",
    "Réessayer cette étape" to "Try this step again",
    "Passer sans durée" to "Skip duration",
    "Titre : \$voiceTitle" to "Title: \$voiceTitle",
    "Date : \$voiceDate" to "Date: \$voiceDate",
    "Dernière réponse : \$voiceAnswer" to "Last response: \$voiceAnswer",
    "Choisir : \$alarmTimeText" to "Choose: \$alarmTimeText",
    "Rendez-vous \${index + 1}" to "Appointment \${index + 1}",
    "Voici la fiche de votre événement :" to "Here are your event details:",
    "Supprimer l’événement ?" to "Delete event?",
    "Supprimer du calendrier source ?" to "Delete from source calendar?",
    "Voulez-vous vraiment supprimer « \${event.title} » ?" to "Are you sure you want to delete “\${event.title}”?",
    "Rappel de l’événement Outlook" to "Outlook event reminder",
    "Saisissez un titre, une date future et un délai valide." to "Enter a title, a future date and a valid reminder time.",
    "Sélectionne au moins un type de rappel." to "Select at least one reminder type.",
    "L’heure de fin doit être après l’heure de début." to "The end time must be after the start time.",
    "Le jour du rendez-vous reste inchangé. Seule l’heure de l’alarme sera modifiée." to "The appointment date remains unchanged. Only the alarm time will be changed.",
    "Choisis une heure future, le même jour que le rendez-vous." to "Choose a future time on the same day as the appointment.",
    "Date ou heure à corriger" to "Date or time to correct",
    "Détails du rendez-vous" to "Appointment details",
    "SEM." to "WK",
    "Sem." to "Wk",
    "Mon Agenda & Alarmes" to "My Calendar & Alarms",
    "Mon Agenda & Alarme" to "My Calendar & Alarm",
    "Par défaut" to "Default",
    "Aucun rendez-vous daté n\'a pu être détecté automatiquement. Tu peux corriger la transcription ci-dessous." to "No dated appointments could be detected automatically. You can correct the transcription below.",
    "Vérifier l'événement" to "Review event",
    "Apparence et thèmes" to "Appearance and themes",
    "Alarme sonore" to "Alarm sound",
    "Alarme sonore Mon Agenda" to "My Calendar alarm sound",
    "Délai avant l'événement" to "Time before the event",
    " Notification" to " Notification",
    " Alarme" to " Alarm",
    "Ouvrir les paramètres Android de l'application" to "Open the app's Android settings",
    "Si le volume des alarmes du téléphone est inférieur à ce seuil, l'application l'augmentera temporairement pendant la sonnerie, puis restaurera le volume initial." to "If your phone's alarm volume is below this level, the app will temporarily raise it while the alarm rings, then restore the previous volume.",
    "L'heure de fin doit être après l'heure de début." to "The end time must be after the start time.",
    "Langue enregistrée." to "Language saved.",
    "Jour" to "Day",
    "Semaine" to "Week",
    "Mois" to "Month",
    "Papier" to "Paper",
    "Masquer" to "Hide",
    "Afficher" to "Show",
    "Réduire" to "Collapse",
    "Agrandir" to "Expand",
    "À l'heure" to "At event time",
    "5 min" to "5 min",
    "15 min" to "15 min",
    "30 min" to "30 min",
    "1 h" to "1 hr",
    "La veille" to "The day before",
    "Personnalisé" to "Custom",
    "Notification + alarme" to "Notification + alarm",
    "Alarme Mon Agenda" to "My Calendar alarm",
    "Événement Outlook sans rappel" to "Outlook event without reminder",
    "Rappel Outlook" to "Outlook reminder",
    "Alarme sonore" to "Alarm sound",
    "Sonnerie d’alarme par défaut" to "Default alarm ringtone",
    "Sonnerie personnalisée" to "Custom ringtone",
    "Modifier l’événement" to "Edit event",
    "Programmer un événement" to "Schedule an event",
    "Couleur de l’événement" to "Event color",
    "Couleur sélectionnée" to "Selected color",
    "Définir une heure de fin" to "Set an end time",
    "Délai avant l'événement" to "Time before the event",
    "Aucune heure de fin ne sera définie pour cet événement." to "No end time will be set for this event.",
    "L'heure de fin doit être après l'heure de début." to "The end time must be after the start time.",
    "Sélectionne au moins un type de rappel." to "Select at least one reminder type.",
    "Ajouter une pièce jointe" to "Add an attachment",
    "Aucune pièce jointe." to "No attachments.",
    "Events" to "Events",
    "TITRE" to "TITLE",
    "DATE" to "DATE",
    "HEURE DE DÉBUT" to "START TIME",
    "DURÉE" to "DURATION",
    "Événement" to "Event",
    "ÉCOUTE EN COURS…" to "LISTENING…",
    "PRÊT POUR LA DICTÉE" to "READY TO DICTATE",
    "Relancer la dictée" to "Restart dictation",
    "Démarrer la dictée" to "Start dictation",
    "Vérifier l’événement dicté" to "Review dictated event",
    "Vérifier les rendez-vous détectés" to "Review detected appointments",
    "Vérifie la transcription, la date et l’heure. La reconnaissance vocale peut nécessiter Internet selon le service Android installé. Rien ne sera ajouté sans ta validation." to "Review the transcript, date and time. Speech recognition may require internet depending on the installed Android service. Nothing will be added without your confirmation.",
    "Reconnaissance locale hors ligne. Vérifie chaque date, heure et intitulé : l’écriture manuscrite peut être mal interprétée. Rien ne sera ajouté sans ta validation." to "Offline on-device recognition. Check each date, time and title: handwriting may be misread. Nothing will be added without your confirmation.",
    "Dictée reconnue (modifiable)" to "Recognized dictation (editable)",
    "Transcription complète (modifiable)" to "Full transcript (editable)",
    "Texte dicté" to "Dictated text",
    "Texte extrait de la photo" to "Text extracted from photo",
    "Activée" to "Enabled",
    "À vérifier" to "Needs review",
    "Lecture de la photo impossible. Essaie avec une image plus nette." to "Could not read the photo. Try a sharper image.",
    "Impossible d'ouvrir cette photo." to "Unable to open this photo.",
    "Je n'ai pas compris. Réessaie." to "I didn't understand. Please try again.",
    "Chevauchement détecté" to "Schedule conflict detected",
    "Cet événement chevauche un ou plusieurs rendez-vous déjà programmés :" to "This event overlaps one or more events already scheduled:",
    "Souhaites-tu enregistrer cet événement quand même ?" to "Do you want to save this event anyway?",
    "Enregistrer quand même" to "Save anyway",
    "Revenir à la fiche" to "Back to event details"
)

@Composable
internal fun tr(french: String): String {
    val context = androidx.compose.ui.platform.LocalContext.current
    val language = context.getSharedPreferences("interface", android.content.Context.MODE_PRIVATE)
        .getString("app_language", "fr") ?: "fr"
    if (language != "en") return french
    englishUi[french]?.let { return it }
    // Dynamic labels whose values vary at runtime.
    return when {
        french.startsWith("Titre : ") -> "Title: " + french.removePrefix("Titre : ")
        french.startsWith("Date : ") -> "Date: " + french.removePrefix("Date : ")
        french.startsWith("Heure de début : ") -> "Start time: " + french.removePrefix("Heure de début : ")
        french.startsWith("Heure de fin : ") -> "End time: " + french.removePrefix("Heure de fin : ")
        french.startsWith("Durée : ") -> "Duration: " + french.removePrefix("Durée : ")
        french.startsWith("Dernière réponse : ") -> "Last response: " + french.removePrefix("Dernière réponse : ")
        french.startsWith("Rendez-vous ") -> "Appointment " + french.removePrefix("Rendez-vous ")
        french.startsWith("Événements du ") -> "Events for " + french.removePrefix("Événements du ")
        french.startsWith("Minimum : ") -> "Minimum: " + french.removePrefix("Minimum : ")
        french.startsWith("Fin : ") -> "End: " + french.removePrefix("Fin : ")
        french.startsWith("« ") && french.contains(" » sera supprimé") -> french.replace(" sera supprimé du calendrier synchronisé", " will be deleted from the synced calendar")
        else -> french
    }
}

@Composable
internal fun currentUiLocale(): Locale =
    if (tr("Aujourd'hui") == "Today") Locale.UK else Locale.FRANCE

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen() {
    val uiLocale = currentUiLocale()
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val fabPositionPrefs = remember { context.getSharedPreferences("interface", android.content.Context.MODE_PRIVATE) }
    var fabOffsetX by remember { mutableFloatStateOf(fabPositionPrefs.getFloat("fab_offset_x", 0f)) }
    var fabOffsetY by remember { mutableFloatStateOf(fabPositionPrefs.getFloat("fab_offset_y", 0f)) }
    val store = remember { EventStore(context) }
    var events by remember { mutableStateOf(store.load()) }
    var message by remember { mutableStateOf<String?>(null) }
    var photoOcrText by remember { mutableStateOf("") }
    var showPhotoImport by remember { mutableStateOf(false) }
    var photoCandidates by remember { mutableStateOf(listOf<PhotoEventCandidate>()) }
    var ocrBusy by remember { mutableStateOf(false) }
    var importSource by remember { mutableStateOf("photo") }
    var voiceWizardStep by remember { mutableIntStateOf(-1) }
    var voiceTitle by remember { mutableStateOf("") }
    var voiceDate by remember { mutableStateOf("") }
    var voiceStart by remember { mutableStateOf("") }
    var voiceDuration by remember { mutableStateOf("") }
    var voiceAnswer by remember { mutableStateOf("") }
    var voiceStartMillis by remember { mutableStateOf<Long?>(null) }
    var showVoiceSummary by remember { mutableStateOf(false) }
    var voiceListening by remember { mutableStateOf(false) }
    var voiceAutoAdvance by remember { mutableIntStateOf(0) }
    var selectedDay by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ocrBusy = true
            runCatching {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        photoOcrText = result.text
                        photoCandidates = parsePhotoAgendaText(result.text, selectedDay)
                        showPhotoImport = true
                        ocrBusy = false
                    }.addOnFailureListener {
                        ocrBusy = false
                        message = "Lecture de la photo impossible. Essaie avec une image plus nette."
                    }
            }.onFailure {
                ocrBusy = false
                message = "Impossible d'ouvrir cette photo."
            }
        }
    }
    fun handleVoiceResult(spokenText: String) {
        val spoken = spokenText.trim()
        if (spoken.isBlank()) { message = "Je n'ai pas compris. Réessaie."; voiceListening = false; return }
        voiceAnswer = spoken
        when (voiceWizardStep) {
            0 -> { voiceTitle = spoken; voiceWizardStep = 1; voiceAutoAdvance++ }
            1 -> {
                val parsed = parseVoiceDate(spoken, selectedDay)
                if (parsed == null) message = "Date non reconnue. Dis par exemple : 12 novembre 2026."
                else { voiceDate = SimpleDateFormat("EEEE d MMMM yyyy", uiLocale).format(Date(parsed)); voiceStartMillis = parsed; voiceWizardStep = 2; voiceAutoAdvance++ }
            }
            2 -> {
                val hour = parseVoiceTime(spoken)
                if (hour == null) message = "Heure non reconnue. Dis par exemple : 14 heures 30."
                else {
                    val base = voiceStartMillis ?: selectedDay
                    val cal = Calendar.getInstance().apply { timeInMillis = base; set(Calendar.HOUR_OF_DAY, hour.first); set(Calendar.MINUTE, hour.second); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                    voiceStartMillis = cal.timeInMillis
                    voiceStart = String.format(Locale.FRANCE, "%02d:%02d", hour.first, hour.second)
                    voiceWizardStep = 3
                    voiceAutoAdvance++
                }
            }
            3 -> {
                val minutes = parseVoiceDuration(spoken)
                if (minutes == null) message = "Durée non reconnue. Dis par exemple : 1 heure ou 30 minutes."
                else { voiceDuration = spoken; voiceWizardStep = 4; showVoiceSummary = true }
            }
        }
        voiceListening = false
    }
    // Online recognition is preferred. An on-device recognizer is kept as a fallback
    // for network errors or when the online service takes too long after speech ends.
    val speechRecognizer = remember(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }
    val offlineSpeechRecognizer = remember(context) {
        if (android.os.Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else null
    }
    val voiceRecognitionHandler = remember { Handler(Looper.getMainLooper()) }
    var offlineFallbackAttempted by remember { mutableStateOf(false) }
    var waitingForOnlineResult by remember { mutableStateOf(false) }
    val voiceRecognitionIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
    }
    fun startOfflineVoiceFallback() {
        if (offlineFallbackAttempted) return
        offlineFallbackAttempted = true
        waitingForOnlineResult = false
        voiceRecognitionHandler.removeCallbacksAndMessages(null)
        val localRecognizer = offlineSpeechRecognizer
        if (localRecognizer == null) {
            voiceListening = false
            message = "La dictée vocale ne peut pas démarrer. Vérifie la disponibilité de la reconnaissance vocale sur ton téléphone."
            return
        }
        message = ""
        runCatching { voiceListening = true; localRecognizer.startListening(voiceRecognitionIntent) }
            .onFailure { voiceListening = false; message = "La dictée hors ligne n'a pas pu démarrer. Vérifie que le modèle français est installé." }
    }
    DisposableEffect(speechRecognizer, offlineSpeechRecognizer) {
        val onlineListener = object : RecognitionListener {
            override fun onReadyForSpeech(params: AndroidBundle?) { voiceListening = true }
            override fun onBeginningOfSpeech() { voiceListening = true }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                waitingForOnlineResult = true
                voiceRecognitionHandler.postDelayed({
                    if (waitingForOnlineResult && !offlineFallbackAttempted) startOfflineVoiceFallback()
                }, 4000L)
            }
            override fun onError(error: Int) {
                if (!offlineFallbackAttempted && offlineSpeechRecognizer != null) startOfflineVoiceFallback()
                else { voiceListening = false; message = "Dictée interrompue. Appuie sur Réessayer." }
            }
            override fun onResults(results: AndroidBundle?) {
                waitingForOnlineResult = false
                voiceRecognitionHandler.removeCallbacksAndMessages(null)
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                handleVoiceResult(spoken)
            }
            override fun onPartialResults(partialResults: AndroidBundle?) {}
            override fun onEvent(eventType: Int, params: AndroidBundle?) {}
        }
        val offlineListener = object : RecognitionListener {
            override fun onReadyForSpeech(params: AndroidBundle?) { voiceListening = true }
            override fun onBeginningOfSpeech() { voiceListening = true }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { voiceListening = false }
            override fun onError(error: Int) { voiceListening = false; message = "Dictée hors ligne impossible. Vérifie que le modèle français est installé, puis réessaie." }
            override fun onResults(results: AndroidBundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                handleVoiceResult(spoken)
            }
            override fun onPartialResults(partialResults: AndroidBundle?) {}
            override fun onEvent(eventType: Int, params: AndroidBundle?) {}
        }
        speechRecognizer?.setRecognitionListener(onlineListener)
        offlineSpeechRecognizer?.setRecognitionListener(offlineListener)
        onDispose {
            voiceRecognitionHandler.removeCallbacksAndMessages(null)
            speechRecognizer?.destroy()
            offlineSpeechRecognizer?.destroy()
        }
    }
    fun launchVoiceRecognition() {
        if (speechRecognizer == null) { message = "La reconnaissance vocale n'est pas disponible sur cet appareil."; return }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.ActivityCompat.requestPermissions(context as ComponentActivity, arrayOf(Manifest.permission.RECORD_AUDIO), 701)
            message = "Autorise le microphone, puis appuie sur Démarrer la dictée."
            return
        }
        offlineFallbackAttempted = false
        waitingForOnlineResult = false
        voiceRecognitionHandler.removeCallbacksAndMessages(null)
        runCatching { voiceListening = true; speechRecognizer.startListening(voiceRecognitionIntent) }
            .onFailure { voiceListening = false; startOfflineVoiceFallback() }
    }
    LaunchedEffect(voiceAutoAdvance) {
        if (voiceAutoAdvance > 0) {
            delay(650)
            if (voiceWizardStep in 1..3 && !showVoiceSummary) launchVoiceRecognition()
        }
    }
    val voicePrompts = listOf("Quel est le titre de votre événement ?", "Quelle est la date ?", "À quelle heure commence-t-il ?", "Quelle est la durée de l'événement ?")
    fun startVoiceInput() {
        voiceTitle = ""; voiceDate = ""; voiceStart = ""; voiceDuration = ""; voiceAnswer = ""; voiceStartMillis = null
        showVoiceSummary = false
        voiceAutoAdvance = 0
        voiceWizardStep = 0
    }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                // Restaurer d'abord la sauvegarde existante. Ne jamais l'écraser
                // avec la liste vide chargée avant que l'utilisateur ait choisi le dossier.
                events = store.attachBackupTree(uri, events)
                message = if (events.isNotEmpty()) {
                    "Sauvegarde retrouvée : ${events.size} événement(s) restauré(s)."
                } else {
                    "Sauvegarde automatique activée dans Documents/MonAgendaAlarmes."
                }
            }.onFailure {
                message = "Impossible d'activer la sauvegarde locale. Vérifie que le dossier Documents est accessible."
            }
        }
    }
    LaunchedEffect(Unit) {
        if (store.backupTreeUri() == null) {
            val documentsUri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADocuments")
            backupFolderPicker.launch(documentsUri)
        }
    }
    var showEditor by remember { mutableStateOf(false) }
    var eventBeingEdited by remember { mutableStateOf<AgendaEvent?>(null) }
    var pendingOverlapSave by remember { mutableStateOf<Pair<AgendaEvent, AgendaEvent?>?>(null) }
    var newEventInitialTime by remember { mutableStateOf<Long?>(null) }
    var showExactAlarmDialog by remember { mutableStateOf(false) }
    var showDndAlert by remember { mutableStateOf(false) }
    var showDndAccessDialog by remember { mutableStateOf(false) }
    var dndWasActive by remember { mutableStateOf(false) }
    var showDayEvents by remember { mutableStateOf(true) }
    var showWeekend by rememberSaveable { mutableStateOf(true) }
    var eventsMaximized by remember { mutableStateOf(false) }
    var paperFullScreen by rememberSaveable { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showThemes by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val themePrefs = remember { context.getSharedPreferences("interface", android.content.Context.MODE_PRIVATE) }
    var selectedTheme by remember { mutableStateOf(themePrefs.getString("selected_theme", "elegance") ?: "elegance") }
    val supportedLanguages = listOf(
        "fr" to "🇫🇷 Français", "en" to "🇬🇧 English", "es" to "🇪🇸 Español", "de" to "🇩🇪 Deutsch",
        "pt" to "🇵🇹 Português", "zh" to "🇨🇳 中文", "hi" to "🇮🇳 हिन्दी", "ar" to "🇸🇦 العربية",
        "ru" to "🇷🇺 Русский", "ja" to "🇯🇵 日本語", "bn" to "🇧🇩 বাংলা"
    )
    var selectedLanguage by remember { mutableStateOf(themePrefs.getString("app_language", "fr") ?: "fr") }
    var languageMenuExpanded by remember { mutableStateOf(false) }
    var minimumAlarmVolume by remember { mutableFloatStateOf(themePrefs.getInt("minimum_alarm_volume_percent", 20).toFloat()) }
    var forceAlarmVibration by remember { mutableStateOf(themePrefs.getBoolean("force_alarm_vibration", false)) }
    var outlookDeleteTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var outlookReminderTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val appVersion = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "inconnue" }.getOrDefault("inconnue")
    }
    var startupView by remember { mutableStateOf(themePrefs.getString("startup_view", "Aujourd'hui") ?: "Aujourd'hui") }
    var view by rememberSaveable { mutableStateOf(if (startupView == "Dernière vue") themePrefs.getString("last_view", "Mois") ?: "Mois" else startupView) }
    var outlookEvents by remember { mutableStateOf(emptyList<AgendaEvent>()) }
    val allEvents = remember(events, outlookEvents, clockNow) {
        val start = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val end = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 400) }.timeInMillis
        RecurrenceEngine.expand((events + outlookEvents).distinctBy { it.id }, start, end)
    }

    val calendarPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        } else {
            message = "Autorisation de lecture du calendrier refusée. Active-la dans les paramètres Android pour afficher les événements Outlook."
        }
    }

    val outlookWritePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val target = outlookDeleteTarget
        if (granted && target != null) {
            if (OutlookCalendarReader.deleteEvent(context, target)) {
                ReminderScheduler.cancel(context, target)
                events = events.filterNot { it.id == target.id }
                store.save(events)
                outlookEvents = outlookEvents.filterNot { it.id == target.id }
                message = "Événement supprimé du calendrier synchronisé."
            } else message = "La suppression a échoué. Vérifie les droits du calendrier synchronisé."
        } else if (!granted) message = "Autorisation de modification du calendrier refusée."
        outlookDeleteTarget = null
    }

    var notificationsAllowed by remember {
        mutableStateOf(
            android.os.Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
        )
    }

    // La réponse Android est prise en compte immédiatement, sans redémarrer l'application.
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsAllowed = granted
        if (granted) {
            store.load()
                .filter { it.reminderMode == "notification" || it.reminderMode == "both" }
                .forEach { ReminderScheduler.schedule(context, it) }
            message = "Notifications autorisées. Les rappels enregistrés sont maintenant activés."
        } else {
            message = "Notifications non autorisées. Tu peux les activer dans les paramètres Android."
        }
    }
    fun exactAlarmsAllowed(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) return true
        val manager = context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager
        return manager.canScheduleExactAlarms()
    }
    fun hasDndAccess(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M) return false
        val manager = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
        return manager.isNotificationPolicyAccessGranted
    }

    fun isDndActive(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M || !hasDndAccess()) return false
        val manager = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
        return manager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
            manager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    fun checkDoNotDisturb() {
        if (!hasDndAccess()) return
        val active = isDndActive()
        if (active && !dndWasActive) showDndAlert = true
        dndWasActive = active
    }

    LaunchedEffect(Unit) {
        while (true) {
            clockNow = System.currentTimeMillis()
            checkDoNotDisturb()
            delay(2000)
        }
    }

    LaunchedEffect(Unit) {
        if (!exactAlarmsAllowed()) showExactAlarmDialog = true
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
            !hasDndAccess() && !themePrefs.getBoolean("dnd_access_prompted", false)) {
            themePrefs.edit().putBoolean("dnd_access_prompted", true).apply()
            showDndAccessDialog = true
        }
        // Outlook n'est plus importé automatiquement : l'utilisateur lance la synchronisation
        // depuis le bouton Actualiser du bandeau.
        if (android.os.Build.VERSION.SDK_INT >= 33 && !notificationsAllowed) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Actualisation automatique à chaque retour de l'application au premier plan.
    val lifecycle = (context as? ComponentActivity)?.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (!exactAlarmsAllowed()) showExactAlarmDialog = true
                checkDoNotDisturb()

                // Android peut modifier l'autorisation pendant que l'application est en arrière-plan.
                // On relit son état au retour, puis on restaure les rappels sans fermeture/réouverture.
                notificationsAllowed = android.os.Build.VERSION.SDK_INT < 33 ||
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED

                store.load().forEach { saved ->
                    when (saved.reminderMode) {
                        "alarm" -> if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        "notification" -> if (notificationsAllowed) ReminderScheduler.schedule(context, saved)
                        "both" -> {
                            if (notificationsAllowed) ReminderScheduler.schedule(context, saved)
                            if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        }
                    }
                }
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    val hostActivity = context as? ComponentActivity
    DisposableEffect(paperFullScreen, hostActivity) {
        val window = hostActivity?.window
        if (paperFullScreen) {
            // L'état est sauvegardé : après la recréation de l'activité en paysage,
            // le mode papier reste actif au lieu de revenir à l'écran normal.
            hostActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            hostActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        onDispose {
            // Ne pas rétablir l'ancienne orientation ici : onDispose est aussi
            // appelé lors de la recréation provoquée par le passage en paysage.
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    val theme = appThemePalette(selectedTheme)
    MaterialTheme(colorScheme = if (theme.dark) darkColorScheme(
        primary = theme.primary, onPrimary = theme.onPrimary,
        primaryContainer = theme.primaryContainer, onPrimaryContainer = theme.onPrimaryContainer,
        secondary = theme.secondary, background = theme.background, surface = theme.surface,
        onSurface = theme.onSurface, surfaceVariant = theme.surfaceVariant,
        onSurfaceVariant = theme.onSurfaceVariant
    ) else lightColorScheme(
        primary = theme.primary, onPrimary = theme.onPrimary,
        primaryContainer = theme.primaryContainer, onPrimaryContainer = theme.onPrimaryContainer,
        secondary = theme.secondary, background = theme.background, surface = theme.surface,
        onSurface = theme.onSurface, surfaceVariant = theme.surfaceVariant,
        onSurfaceVariant = theme.onSurfaceVariant
    )) {
        Scaffold(
            containerColor = if (paperFullScreen) Color(0xFFE9DDBD) else theme.background,
            // La barre supérieure gère déjà l'incrustation de la barre d'état.
            // Éviter que Scaffold ajoute une seconde marge système au contenu.
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                if (!paperFullScreen) {
                Box(Modifier.fillMaxWidth().height(78.dp).statusBarsPadding()) {
                    Image(painter = painterResource(id = R.drawable.banner_agenda), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(78.dp), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxWidth().height(78.dp).background(theme.primary.copy(alpha = 0.48f)))
                    Row(Modifier.fillMaxWidth().align(Alignment.Center).padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(tr("Mon Agenda & Alarme"), color = Color.White, fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp, lineHeight = 18.sp, maxLines = 1, softWrap = false,
                            modifier = Modifier.weight(1f))
                        IconButton(onClick = { showSettings = true }, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Default.Settings, contentDescription = "Paramètres", tint = Color.White, modifier = Modifier.size(25.dp))
                        }
                        IconButton(onClick = { startVoiceInput() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Mic, contentDescription = "Dicter un événement", tint = Color.White, modifier = Modifier.size(21.dp))
                        }
                        IconButton(onClick = { photoPicker.launch("image/*"); importSource = "photo" }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = "Importer depuis une photo", tint = Color.White, modifier = Modifier.size(21.dp))
                        }
                        IconButton(onClick = {
                            if (OutlookCalendarReader.hasPermission(context)) {
                                outlookEvents = OutlookCalendarReader.readEvents(context)
                                message = "Calendrier synchronisé actualisé."
                            } else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                        }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Actualiser Outlook", tint = Color.White, modifier = Modifier.size(23.dp))
                        }
                    }
                }
                }
            },
            floatingActionButton = {
                // Le bouton + est masqué en mode semaine : l'ajout se fait directement
                // depuis la grille hebdomadaire, en touchant le créneau souhaité.
                if (!paperFullScreen && view != "Aujourd'hui" && view != "Jour" && view != "Semaine") {
                FloatingActionButton(
                    onClick = { showEditor = true },
                    modifier = Modifier
                        .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
                        .pointerInput(configuration.screenWidthDp, configuration.screenHeightDp) {
                            detectDragGesturesAfterLongPress(
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    val maxLeft = with(density) { (configuration.screenWidthDp - 80).coerceAtLeast(0).dp.toPx() }
                                    val maxUp = with(density) { (configuration.screenHeightDp - 180).coerceAtLeast(0).dp.toPx() }
                                    fabOffsetX = (fabOffsetX + dragAmount.x).coerceIn(-maxLeft, 0f)
                                    fabOffsetY = (fabOffsetY + dragAmount.y).coerceIn(-maxUp, 0f)
                                    fabPositionPrefs.edit()
                                        .putFloat("fab_offset_x", fabOffsetX)
                                        .putFloat("fab_offset_y", fabOffsetY)
                                        .apply()
                                }
                            )
                        },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un événement — maintenir appuyé pour déplacer")
                }
                }
            }
        ) { padding ->
            if (paperFullScreen) {
                Column(Modifier.fillMaxSize().background(Color(0xFFD9D2C6)).padding(5.dp).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth().height(38.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("AGENDA DE LA SEMAINE"), color = Color(0xFF59452B), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { paperFullScreen = false; view = "Semaine" }) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF59452B))
                            Text(tr("Sortir"), color = Color(0xFF59452B), fontWeight = FontWeight.Bold)
                        }
                    }
                    WeeklyPaperAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, onEditEvent = { eventBeingEdited = it; showEditor = true }, fullScreen = true, modifier = Modifier.weight(1f))
                }
            } else Column(Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    // Les modes défilent horizontalement ; l'horloge garde une largeur fixe
                    // et ne peut donc plus être coupée ou passer sur deux lignes.
                    Row(
                        Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("Aujourd'hui", "Jour", "Semaine", "Mois").forEach { label ->
                            Mode3DButton(
                                label = tr(label),
                                selected = view == label,
                                onClick = {
                                    view = label
                                    if (label != "Aujourd'hui") themePrefs.edit().putString("last_view", label).apply()
                                }
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        SimpleDateFormat("HH:mm:ss", uiLocale).format(Date(clockNow)),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.widthIn(min = 68.dp),
                        textAlign = TextAlign.End
                    )
                }
                if (!eventsMaximized) {
                    if (view != "Aujourd'hui") CalendarNavigator(view, selectedDay, onPrevious = { selectedDay = shiftDate(selectedDay, view, -1) },
                        onNext = { selectedDay = shiftDate(selectedDay, view, 1) }, onToday = { selectedDay = System.currentTimeMillis() })
                    when (view) {
                        "Aujourd'hui" -> {
                            val todayStart = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                            val todayEnd = todayStart + 24L * 60L * 60L * 1000L
                            val remainingEvents = allEvents.filter { event ->
                                event.timeMillis in todayStart until todayEnd &&
                                    ((event.endTimeMillis ?: event.timeMillis) > clockNow || event.timeMillis >= clockNow)
                            }.sortedBy { it.timeMillis }
                            Column(Modifier.fillMaxWidth().weight(1f)) {
                                Text(SimpleDateFormat("EEEE d MMMM yyyy", uiLocale).format(Date(todayStart)).replaceFirstChar { it.uppercase() },
                                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 10.dp))
                                Text(tr("Mes événements à venir"), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(8.dp))
                                if (remainingEvents.isEmpty()) {
                                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                        Text(tr("Plus aucun événement prévu aujourd'hui."), Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                } else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                    items(remainingEvents, key = { it.id }) { event ->
                                        EventCard(event, onEdit = {
                                            if (event.outlookEventId != null) {
                                                val editIntent = Intent(Intent.ACTION_EDIT).apply {
                                                    data = android.content.ContentUris.withAppendedId(android.provider.CalendarContract.Events.CONTENT_URI, event.outlookEventId)
                                                    type = "vnd.android.cursor.item/event"
                                                }
                                                runCatching { context.startActivity(editIntent) }.onFailure { message = "Aucune application de calendrier ne permet de modifier cet événement." }
                                            } else { eventBeingEdited = event; showEditor = true }
                                        }, onDelete = {
                                            if (event.outlookEventId != null) outlookDeleteTarget = event else {
                                                ReminderScheduler.cancel(context, event); events = events.filterNot { it.id == event.id }; store.save(events)
                                            }
                                        }, onAlarm = { eventBeingEdited = event; showEditor = true })
                                    }
                                }
                            }
                        }
                        "Jour" -> DayAgenda(
                            selectedDay, allEvents, nowMillis = clockNow,
                            onEditEvent = { event -> eventBeingEdited = event; newEventInitialTime = null; showEditor = true },
                            onAddAtTime = { time -> eventBeingEdited = null; newEventInitialTime = time; showEditor = true },
                            onDeleteEvent = { event -> if (event.outlookEventId != null) outlookDeleteTarget = event else { ReminderScheduler.cancel(context, event); events = events.filterNot { it.id == event.id }; store.save(events) } },
                            expanded = !showDayEvents,
                            modifier = Modifier.weight(1f)
                        )
                        "Semaine" -> WeekAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, onEditEvent = { event -> eventBeingEdited = event; newEventInitialTime = null; showEditor = true }, onAddAtTime = { time -> eventBeingEdited = null; newEventInitialTime = time; showEditor = true }, onDeleteEvent = { event -> if (event.outlookEventId != null) outlookDeleteTarget = event else { ReminderScheduler.cancel(context, event); events = events.filterNot { it.id == event.id }; store.save(events) } }, showWeekend = showWeekend, onToggleWeekend = { showWeekend = it }, modifier = Modifier.weight(1f))
                        "Papier" -> WeeklyPaperAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, onEditEvent = { eventBeingEdited = it; showEditor = true })
                        else -> MonthAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                    }
                }
                val dayEvents = allEvents.filter { sameDay(it.timeMillis, selectedDay) }.sortedBy { it.timeMillis }
                if (view == "Mois" || view == "Papier") {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 7.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp)).padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Événements du ${SimpleDateFormat("EEEE d MMMM", uiLocale).format(Date(selectedDay))}"),
                        fontSize = 15.sp, lineHeight = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
                        modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                    if (!eventsMaximized) {
                        TextButton(onClick = { showDayEvents = !showDayEvents }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) {
                            Text(tr(if (showDayEvents) "Masquer" else "Afficher"), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (showDayEvents) {
                        TextButton(onClick = { eventsMaximized = !eventsMaximized }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) {
                            Text(tr(if (eventsMaximized) "Réduire" else "Agrandir"), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (showDayEvents) {
                    if (dayEvents.isEmpty()) Text(tr("Aucun événement ce jour."), Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(dayEvents, key = { it.id }) { event ->
                            EventCard(event, onEdit = {
                                if (event.outlookEventId != null) {
                                    val editIntent = Intent(Intent.ACTION_EDIT).apply {
                                        data = android.content.ContentUris.withAppendedId(
                                            android.provider.CalendarContract.Events.CONTENT_URI, event.outlookEventId
                                        )
                                        type = "vnd.android.cursor.item/event"
                                    }
                                    runCatching { context.startActivity(editIntent) }
                                        .onFailure { message = "Aucune application de calendrier ne permet de modifier cet événement." }
                                }
                            }, onDelete = {
                                if (event.outlookEventId != null) {
                                    outlookDeleteTarget = event
                                } else {
                                    ReminderScheduler.cancel(context, event)
                                    events = events.filterNot { it.id == event.id }
                                    store.save(events)
                                }
                            }, onAlarm = {
                                if (event.outlookEventId != null) outlookReminderTarget = event
                                else {
                                    eventBeingEdited = event
                                    showEditor = true
                                }
                            })
                        }
                    }
                }
                }
            }
        }
    }

    if (voiceWizardStep in 0..3 && !showVoiceSummary) {
        val promptIcon = when (voiceWizardStep) {
            0 -> Icons.Default.Title
            1 -> Icons.Default.CalendarToday
            2 -> Icons.Default.AccessTime
            else -> Icons.Default.Timelapse
        }
        AlertDialog(
            onDismissRequest = { voiceWizardStep = -1 },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(promptIcon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                    Text(tr(listOf("TITRE", "DATE", "HEURE DE DÉBUT", "DURÉE")[voiceWizardStep]), fontSize = 25.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                }
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(22.dp)) {
                        Icon(promptIcon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.padding(14.dp).size(48.dp))
                    }
                    Text(voicePrompts[voiceWizardStep], fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
                    Surface(color = if (voiceListening) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Mic, contentDescription = "Dictée", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
                            Text(tr(if (voiceListening) "ÉCOUTE EN COURS…" else "PRÊT POUR LA DICTÉE"), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
                            Button(onClick = { launchVoiceRecognition() }, modifier = Modifier.fillMaxWidth()) { Text(tr(if (voiceListening) "Relancer la dictée" else "Démarrer la dictée"), fontSize = 16.sp) }
                        }
                    }
                    if (voiceAnswer.isNotBlank()) Text(tr("Dernière réponse : $voiceAnswer"), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    if (voiceWizardStep == 3) {
                        OutlinedButton(
                            onClick = {
                                voiceDuration = ""
                                voiceWizardStep = 4
                                showVoiceSummary = true
                                voiceListening = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(tr("Passer sans durée")) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { launchVoiceRecognition() }) { Text(tr("Réessayer cette étape")) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { startVoiceInput() }) { Text(tr("Recommencer")) }
                    TextButton(onClick = { voiceWizardStep = -1 }) { Text(tr("Annuler")) }
                }
            }
        )
    }
    if (showVoiceSummary) {
        val start = voiceStartMillis
        val durationMinutes = parseVoiceDuration(voiceDuration)
        AlertDialog(
            onDismissRequest = { showVoiceSummary = false; voiceWizardStep = -1 },
            title = { Text(tr("Vérifier l'événement")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("Voici la fiche de votre événement :"), fontWeight = FontWeight.SemiBold)
                    Text(tr("Titre : $voiceTitle"))
                    Text(tr("Date : $voiceDate"))
                    Text(tr("Heure de début : $voiceStart"))
                    if (voiceDuration.isNotBlank() && durationMinutes != null) {
                        Text(tr("Durée : $voiceDuration"))
                        if (start != null) Text(tr("Heure de fin : ${SimpleDateFormat("HH:mm", uiLocale).format(Date(start + durationMinutes * 60_000L))}"))
                    } else {
                        Text(tr("Durée : non précisée"), fontWeight = FontWeight.Medium)
                        Text(tr("Aucune heure de fin ne sera définie pour cet événement."), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            confirmButton = { TextButton(onClick = {
                if (start != null && voiceTitle.isNotBlank()) {
                    val endTime = if (durationMinutes != null) start + durationMinutes * 60_000L else null
                    val event = AgendaEvent(System.currentTimeMillis(), voiceTitle.trim(), "Ajouté par assistant vocal", start, "none", 15, endTimeMillis = endTime)
                    eventBeingEdited = event; newEventInitialTime = null; showEditor = true
                }
                showVoiceSummary = false; voiceWizardStep = -1
            }) { Text(tr("Continuer vers la fiche")) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { startVoiceInput() }) { Text(tr("Recommencer la saisie")) }
                    TextButton(onClick = { showVoiceSummary = false; voiceWizardStep = -1 }) { Text(tr("Annuler")) }
                }
            }
        )
    }
    if (showPhotoImport) {
        AlertDialog(
            onDismissRequest = { showPhotoImport = false },
            title = { Text(tr(if (importSource == "voix") "Vérifier l’événement dicté" else "Vérifier les rendez-vous détectés")) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(tr(if (importSource == "voix") "Vérifie la transcription, la date et l’heure. La reconnaissance vocale peut nécessiter Internet selon le service Android installé. Rien ne sera ajouté sans ta validation." else "Reconnaissance locale hors ligne. Vérifie chaque date, heure et intitulé : l’écriture manuscrite peut être mal interprétée. Rien ne sera ajouté sans ta validation."), fontSize = 12.sp)
                    if (photoCandidates.isEmpty()) {
                        Text(tr("Aucun rendez-vous daté n'a pu être détecté automatiquement. Tu peux corriger la transcription ci-dessous."), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    } else {
                        Text(tr("${photoCandidates.size} rendez-vous potentiel(s). Les doublons avec ton agenda seront ignorés."), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        photoCandidates.forEachIndexed { index, candidate ->
                            val candidateTime = parsePhotoDateTime(candidate.dateTimeText)
                            val conflict = candidateTime?.let { proposed ->
                                events.firstOrNull { existing -> sameCalendarHour(existing.timeMillis, proposed) }
                            }
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = candidate.selected, onCheckedChange = { checked -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(selected = checked) } })
                                        Text(tr("Rendez-vous ${index + 1}"), fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedTextField(value = candidate.title, onValueChange = { value -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(title = value) } }, label = { Text(tr("Intitulé")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(value = candidate.dateTimeText, onValueChange = { value -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(dateTimeText = value) } }, label = { Text(tr("Date et heure (JJ/MM/AAAA HH:mm)")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    if (candidate.endDateTimeText.isNotBlank() || importSource == "voix") {
                                        OutlinedTextField(
                                            value = candidate.endDateTimeText,
                                            onValueChange = { value -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(endDateTimeText = value) } },
                                            label = { Text(tr("Heure de fin (JJ/MM/AAAA HH:mm)")) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true
                                        )
                                    }
                                    if (candidate.dateTimeText.isNotBlank() && candidateTime == null) Text(tr("Date ou heure à corriger"), color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                                    if (conflict != null) Text(tr("⚠ Un événement existe déjà dans ton agenda à cette heure : ${conflict.title}. Ce rendez-vous ne sera pas importé tant que le conflit n'est pas résolu."), color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Text(tr(if (importSource == "voix") "Dictée reconnue (modifiable)" else "Transcription complète (modifiable)"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(value = photoOcrText, onValueChange = { photoOcrText = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp, max = 180.dp), label = { Text(tr(if (importSource == "voix") "Texte dicté" else "Texte extrait de la photo")) })
                    Text(tr("Les rappels et alarmes restent désactivés après import."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val selected = photoCandidates.filter { it.selected && it.title.isNotBlank() }
                    val valid = selected.mapNotNull { candidate -> parsePhotoDateTime(candidate.dateTimeText)?.let { candidate to it } }
                    val invalidCount = selected.size - valid.size
                    val existingKeys = events.map { photoDuplicateKey(it.title, it.timeMillis) }.toSet()
                    val additions = valid.filter { (candidate, time) ->
                        photoDuplicateKey(candidate.title, time) !in existingKeys &&
                            events.none { existing -> sameCalendarHour(existing.timeMillis, time) }
                    }.mapIndexed { idx, pair ->
                        val endTime = parsePhotoDateTime(pair.first.endDateTimeText)?.takeIf { it > pair.second }
                        AgendaEvent(
                            System.currentTimeMillis() + idx,
                            pair.first.title.trim(),
                            if (importSource == "voix") "Ajouté par dictée vocale" else "Importé depuis une photo d’agenda",
                            pair.second, "none", 15,
                            endTimeMillis = endTime
                        )
                    }
                    val conflictCount = valid.count { (_, time) -> events.any { existing -> sameCalendarHour(existing.timeMillis, time) } }
                    events = (events + additions).distinctBy { it.id }.sortedBy { it.timeMillis }
                    store.save(events)
                    showPhotoImport = false
                    message = when {
                        additions.isEmpty() && conflictCount > 0 -> "Aucun rendez-vous importé : $conflictCount conflit(s) avec un événement déjà prévu à la même heure."
                        additions.isEmpty() -> "Aucun nouveau rendez-vous importé. Vérifie les dates ou les doublons."
                        conflictCount > 0 -> "${additions.size} rendez-vous importé(s). $conflictCount conflit(s) horaire(s) ignoré(s)."
                        invalidCount > 0 -> "${additions.size} rendez-vous importé(s). $invalidCount entrée(s) ignorée(s) car la date ou l'heure est invalide."
                        else -> "${additions.size} rendez-vous importé(s), sans rappel ni alarme."
                    }
                }) { Text(tr("Importer la sélection")) }
            },
            dismissButton = { TextButton(onClick = { showPhotoImport = false }) { Text(tr("Annuler")) } }
        )
    }
    outlookDeleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { outlookDeleteTarget = null },
            title = { Text(tr("Supprimer du calendrier source ?")) },
            text = { Text(tr("« ${target.title} » sera supprimé du calendrier synchronisé et la suppression pourra être répercutée dans Outlook ou Google après synchronisation. Attention : si ce rendez-vous appartient à une série récurrente, la série entière peut être supprimée.")) },
            confirmButton = {
                TextButton(onClick = {
                    if (OutlookCalendarReader.hasWritePermission(context)) {
                        if (OutlookCalendarReader.deleteEvent(context, target)) {
                            ReminderScheduler.cancel(context, target)
                            events = events.filterNot { it.id == target.id }
                            store.save(events)
                            outlookEvents = outlookEvents.filterNot { it.id == target.id }
                            message = "Événement supprimé du calendrier synchronisé."
                        } else message = "Impossible de supprimer cet événement."
                        outlookDeleteTarget = null
                    } else {
                        outlookWritePermission.launch(Manifest.permission.WRITE_CALENDAR)
                    }
                }) { Text(tr("Supprimer")) }
            },
            dismissButton = { TextButton(onClick = { outlookDeleteTarget = null }) { Text(tr("Annuler")) } }
        )
    }

    outlookReminderTarget?.let { target ->
        OutlookReminderEditor(
            event = target,
            onDismiss = { outlookReminderTarget = null },
            onSave = { mode, lead, alarmTime, soundUri, vibrate ->
                val updated = target.copy(reminderMode = mode, leadMinutes = lead, alarmTimeMillis = alarmTime, alarmSoundUri = soundUri, vibrate = vibrate)
                ReminderScheduler.cancel(context, target)
                events = (events.filterNot { it.id == target.id } + updated).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = when (mode) {
                    "alarm" -> ReminderScheduler.scheduleAlarm(context, updated)
                    "both" -> {
                        val notificationOk = ReminderScheduler.schedule(context, updated)
                        val alarmOk = ReminderScheduler.scheduleAlarm(context, updated)
                        notificationOk && alarmOk
                    }
                    else -> ReminderScheduler.schedule(context, updated)
                }
                outlookReminderTarget = null
                if (scheduled) message = when (mode) {
                    "alarm" -> "Alarme sonore ajoutée à l’événement Outlook."
                    "both" -> "Notification et alarme ajoutées à l’événement Outlook."
                    else -> "Notification ajoutée à l’événement Outlook."
                }
                else {
                    message = "Le rappel est enregistré, mais n’a pas pu être programmé. ${ReminderScheduler.lastError ?: "Vérifie les autorisations de notification et d'alarme."}"
                    if ((mode == "alarm" || mode == "both") && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }

    val persistAgendaEvent: (AgendaEvent, AgendaEvent?) -> Unit = { event, editing ->
        if (editing != null) ReminderScheduler.cancelSeries(context, editing)
        events = (events.filterNot { it.id == event.id } + event).sortedBy { it.timeMillis }
        store.save(events)
        val scheduled = ReminderScheduler.scheduleSeries(context, event)
        showEditor = false
        eventBeingEdited = null
        newEventInitialTime = null
        pendingOverlapSave = null
        selectedDay = event.timeMillis
        if (scheduled) message = if (editing != null) "Événement modifié et rappel reprogrammé." else "Événement enregistré."
        else {
            message = "L'événement est enregistré, mais le rappel n'a pas pu être programmé. ${ReminderScheduler.lastError ?: "Vérifie les autorisations de notification et d'alarme."}"
            if ((event.reminderMode == "alarm" || event.reminderMode == "both") && !exactAlarmsAllowed()) showExactAlarmDialog = true
        }
    }

    if (showEditor) {
        val editing = eventBeingEdited
        EventEditor(
            initialDateMillis = editing?.timeMillis ?: selectedDay,
            initialTimeMillis = if (editing == null) newEventInitialTime else null,
            initialEvent = editing,
            eventStore = store,
            onDismiss = { showEditor = false; eventBeingEdited = null; newEventInitialTime = null },
            onSave = { title, desc, time, endTime, mode, lead, soundUri, vibrate, attachments, colorHex, recurrenceType, recurrenceInterval, recurrenceDays, recurrenceEnd, recurrenceCount ->
                val event = if (editing != null) editing.copy(
                    title = title, description = desc, timeMillis = time, endTimeMillis = endTime,
                    reminderMode = mode, leadMinutes = lead, alarmTimeMillis = null,
                    alarmSoundUri = soundUri, vibrate = vibrate, attachments = attachments, colorHex = colorHex, recurrenceType = recurrenceType, recurrenceInterval = recurrenceInterval, recurrenceDays = recurrenceDays, recurrenceEndMillis = recurrenceEnd, recurrenceCount = recurrenceCount
                ) else AgendaEvent(System.currentTimeMillis(), title, desc, time, mode, lead, endTimeMillis = endTime, alarmSoundUri = soundUri, vibrate = vibrate, attachments = attachments, colorHex = colorHex, recurrenceType = recurrenceType, recurrenceInterval = recurrenceInterval, recurrenceDays = recurrenceDays, recurrenceEndMillis = recurrenceEnd, recurrenceCount = recurrenceCount)
                val overlaps = findOverlappingEvents(event, events)
                if (overlaps.isNotEmpty()) {
                    pendingOverlapSave = event to editing
                } else {
                    persistAgendaEvent(event, editing)
                }
            }
        )
    }
    pendingOverlapSave?.let { (candidate, editing) ->
        val conflicts = findOverlappingEvents(candidate, events)
        AlertDialog(
            onDismissRequest = { pendingOverlapSave = null },
            title = { Text(tr("Chevauchement détecté"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("Cet événement chevauche un ou plusieurs rendez-vous déjà programmés :"))
                    conflicts.forEach { conflict ->
                        val start = SimpleDateFormat("EEE HH:mm", uiLocale).format(Date(conflict.timeMillis))
                        val end = conflict.endTimeMillis?.takeIf { it > conflict.timeMillis }
                            ?.let { " – " + SimpleDateFormat("HH:mm", uiLocale).format(Date(it)) } ?: ""
                        Text("• ${conflict.title} ($start$end)", fontWeight = FontWeight.SemiBold)
                    }
                    Text(tr("Souhaites-tu enregistrer cet événement quand même ?"))
                }
            },
            confirmButton = {
                TextButton(onClick = { persistAgendaEvent(candidate, editing) }) {
                    Text(tr("Enregistrer quand même"))
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingOverlapSave = null }) {
                    Text(tr("Revenir à la fiche"))
                }
            }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(tr("Paramètres"), fontWeight = FontWeight.Bold)
            } },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Text(tr("ÉCRAN D'ACCUEIL"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    listOf("Aujourd'hui" to tr("Aujourd'hui"), "Dernière vue" to tr("Dernière vue utilisée")).forEach { option ->
                        Row(Modifier.fillMaxWidth().clickable {
                            startupView = option.first
                            themePrefs.edit().putString("startup_view", option.first).apply()
                        }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = startupView == option.first,
                                onClick = { startupView = option.first; themePrefs.edit().putString("startup_view", option.first).apply() })
                            Text(option.second)
                        }
                    }
                    Text(tr("Choisis l'écran affiché à chaque ouverture de l'application."), style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider()
                    Text(tr("LANGUE / LANGUAGE"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    ExposedDropdownMenuBox(expanded = languageMenuExpanded, onExpandedChange = { languageMenuExpanded = !languageMenuExpanded }) {
                        OutlinedTextField(
                            value = supportedLanguages.firstOrNull { it.first == selectedLanguage }?.second ?: "🇫🇷 Français",
                            onValueChange = {}, readOnly = true, label = { Text(tr("Langue de l'application")) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = languageMenuExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = languageMenuExpanded, onDismissRequest = { languageMenuExpanded = false }) {
                            supportedLanguages.forEach { language ->
                                DropdownMenuItem(text = { Text(language.second) }, onClick = {
                                    selectedLanguage = language.first
                                    themePrefs.edit().putString("app_language", language.first).apply()
                                    languageMenuExpanded = false
                                    message = if (selectedLanguage == "en") "Language set to English." else "Langue enregistrée."
                                })
                            }
                        }
                    }
                    Text(tr("Le français est la langue par défaut. Le choix est mémorisé sur cet appareil."), style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider()
                    Text(tr("APPARENCE"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    appThemeOptions().forEach { option ->
                        val colors = appThemePalette(option.first)
                        Surface(onClick = {
                            selectedTheme = option.first
                            themePrefs.edit().putString("selected_theme", option.first).apply()
                        }, shape = RoundedCornerShape(13.dp), color = colors.surface,
                            border = androidx.compose.foundation.BorderStroke(if (selectedTheme == option.first) 2.dp else 1.dp,
                                if (selectedTheme == option.first) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    listOf(colors.primary, colors.secondary, colors.primaryContainer).forEach { swatch ->
                                        Box(Modifier.size(18.dp, 30.dp).background(swatch, RoundedCornerShape(5.dp)))
                                    }
                                }
                                Text(option.second, modifier = Modifier.weight(1f), color = colors.onSurface, fontWeight = FontWeight.SemiBold)
                                if (selectedTheme == option.first) Icon(Icons.Default.Palette, contentDescription = "Sélectionné", tint = colors.primary)
                            }
                        }
                    }
                    HorizontalDivider()
                    Text(tr("VOLUME MINIMUM DES ALARMES"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Text(tr("Si le volume des alarmes du téléphone est inférieur à ce seuil, l'application l'augmentera temporairement pendant la sonnerie, puis restaurera le volume initial."), style = MaterialTheme.typography.bodySmall)
                    Text(tr("Minimum : ${minimumAlarmVolume.roundToInt()} %"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Slider(value = minimumAlarmVolume, onValueChange = { value ->
                        minimumAlarmVolume = value
                        themePrefs.edit().putInt("minimum_alarm_volume_percent", value.roundToInt()).apply()
                    }, valueRange = 5f..100f, steps = 18)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(tr("Forcer le vibreur pendant les alarmes"), fontWeight = FontWeight.SemiBold)
                            Text(
                                tr("Déclenche la vibration de l’alarme même si le mode silencieux ou le vibreur général est désactivé. Les restrictions Android et Ne pas déranger peuvent toujours s’appliquer."),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = forceAlarmVibration,
                            onCheckedChange = { enabled ->
                                forceAlarmVibration = enabled
                                themePrefs.edit().putBoolean("force_alarm_vibration", enabled).apply()
                            }
                        )
                    }
                    HorizontalDivider()
                    Text(tr("AUTORISATIONS"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    @Composable fun PermissionLine(label: String, granted: Boolean) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (granted) Icons.Default.CheckCircle else Icons.Default.Warning, contentDescription = null,
                                tint = if (granted) Color(0xFF27834A) else MaterialTheme.colorScheme.error, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            Text(tr(if (granted) "Activée" else "À vérifier"), color = if (granted) Color(0xFF27834A) else MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    PermissionLine("Lecture du calendrier Outlook", ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED)
                    PermissionLine("Notifications", android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
                    PermissionLine("Alarmes et rappels exacts", exactAlarmsAllowed())
                    PermissionLine("Accès au mode Ne pas déranger", hasDndAccess())
                    OutlinedButton(onClick = { showSettings = false; context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("Ouvrir les paramètres Android de l'application"))
                    }
                    HorizontalDivider()
                    OutlinedButton(onClick = { showSettings = false; showAbout = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Info, contentDescription = null); Spacer(Modifier.width(8.dp)); Text(tr("À propos"))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text(tr("Fermer")) } }
        )
    }

    if (showThemes) {
        AlertDialog(
            onDismissRequest = { showThemes = false },
            title = { Text(tr("Apparence et thèmes"), fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    appThemeOptions().forEach { option ->
                        val colors = appThemePalette(option.first)
                        Surface(
                            onClick = {
                                selectedTheme = option.first
                                themePrefs.edit().putString("selected_theme", option.first).apply()
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = colors.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                if (selectedTheme == option.first) 2.dp else 1.dp,
                                if (selectedTheme == option.first) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(colors.primary, colors.secondary, colors.primaryContainer).forEach { swatch ->
                                        Box(Modifier.size(width = 22.dp, height = 38.dp).background(swatch, RoundedCornerShape(7.dp)))
                                    }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(option.second, color = colors.onSurface, fontWeight = FontWeight.Bold)
                                    Text(option.third, color = colors.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                                if (selectedTheme == option.first) Icon(Icons.Default.Palette, contentDescription = "Thème sélectionné", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    Divider()
                    Text(tr("Volume minimum des alarmes"), fontWeight = FontWeight.Bold)
                    Text(tr("Si le volume des alarmes du téléphone est inférieur à ce seuil, l'application l'augmentera temporairement pendant la sonnerie, puis restaurera le volume initial."), style = MaterialTheme.typography.bodySmall)
                    Text(tr("Minimum : ${minimumAlarmVolume.roundToInt()} %"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Slider(
                        value = minimumAlarmVolume,
                        onValueChange = { value ->
                            minimumAlarmVolume = value
                            themePrefs.edit().putInt("minimum_alarm_volume_percent", value.roundToInt()).apply()
                        },
                        valueRange = 5f..100f,
                        steps = 18
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showThemes = false }) { Text(tr("Fermer")) } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text(tr("Mon Agenda & Alarmes"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(38.dp))
                            Text(tr("Votre agenda, vos rappels."), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(tr("Organisez vos événements et ne manquez plus aucun rendez-vous."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Text(tr("Développé par V Da Silva"), fontWeight = FontWeight.SemiBold)
                    Text(tr("Version $appVersion"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text(tr("Fermer")) } }
        )
    }

    if (showDndAccessDialog) {
        AlertDialog(
            onDismissRequest = { showDndAccessDialog = false },
            title = { Text(tr("Détection du mode Ne pas déranger")) },
            text = { Text(tr("Pour avertir lorsque le mode Ne pas déranger est activé, Mon Agenda & Alarmes doit pouvoir consulter le mode de concentration du téléphone. Autorise cet accès dans les paramètres Android. L'application ne modifiera pas ce réglage.")) },
            confirmButton = {
                TextButton(onClick = {
                    showDndAccessDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }
                }) { Text(tr("OUVRIR LES PARAMÈTRES")) }
            },
            dismissButton = { TextButton(onClick = { showDndAccessDialog = false }) { Text(tr("Plus tard")) } }
        )
    }

    if (showDndAlert) {
        AlertDialog(
            onDismissRequest = { showDndAlert = false },
            title = { Text(tr("Mode Ne pas déranger activé"), fontWeight = FontWeight.Bold) },
            text = { Text(tr("Attention : le mode Ne pas déranger est actif. Il peut silencier ou limiter les alarmes et notifications de Mon Agenda & Alarmes selon les réglages du téléphone.")) },
            confirmButton = {
                TextButton(onClick = {
                    showDndAlert = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)) }
                    }
                }) { Text(tr("VÉRIFIER LES PARAMÈTRES")) }
            },
            dismissButton = { TextButton(onClick = { showDndAlert = false }) { Text(tr("Fermer")) } }
        )
    }

    if (showExactAlarmDialog) {
        AlertDialog(
            onDismissRequest = { showExactAlarmDialog = false },
            title = { Text(tr("Autoriser les alarmes exactes")) },
            text = { Text(tr("Pour que les alarmes sonnent à l'heure prévue, Mon Agenda doit être autorisé à utiliser « Alarmes et rappels ». Active cette autorisation dans les paramètres Android.")) },
            confirmButton = {
                TextButton(onClick = {
                    showExactAlarmDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:" + context.packageName)
                        }
                        context.startActivity(intent)
                    }
                }) { Text(tr("ACTIVER LES ALARMES EXACTES")) }
            },
            dismissButton = {
                TextButton(onClick = { showExactAlarmDialog = false }) { Text(tr("Plus tard")) }
            }
        )
    }

    message?.let {
        AlertDialog(onDismissRequest = { message = null }, confirmButton = {
            TextButton(onClick = { message = null }) { Text(tr("OK")) }
        }, title = { Text(tr("Information")) }, text = { Text(tr(it)) })
    }
}

internal fun parseEventColor(hex: String?): Color? = hex?.let {
    runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull()
}

/** Choisit automatiquement le noir ou le blanc selon le meilleur contraste WCAG. */
internal fun eventTextColor(background: Color): Color {
    fun linear(channel: Float): Float = if (channel <= 0.04045f) channel / 12.92f else
        ((channel + 0.055f) / 1.055f).pow(2.4f)
    val luminance = 0.2126f * linear(background.red) +
        0.7152f * linear(background.green) + 0.0722f * linear(background.blue)
    val blackContrast = (luminance + 0.05f) / 0.05f
    val whiteContrast = 1.05f / (luminance + 0.05f)
    return if (whiteContrast > blackContrast) Color.White else Color(0xFF101010)
}

