package fr.bellendar

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Opens SAF-backed attachments through a temporary cache file and a grantable FileProvider URI. */
object AttachmentOpener {
    fun open(context: Context, attachment: EventAttachment) {
        try {
            val source = Uri.parse(attachment.uri)
            val resolver = context.contentResolver
            val input = resolver.openInputStream(source)
                ?: throw IllegalStateException("Le document enregistré est introuvable ou inaccessible.")
            val cacheDir = File(context.cacheDir, "event-attachments").apply { mkdirs() }
            val safeName = attachment.name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "document" }
            val extension = safeName.substringAfterLast('.', "").takeIf { it.isNotBlank() }?.let { ".$it" } ?: ".bin"
            val target = File.createTempFile("attachment_", extension, cacheDir)
            input.use { sourceStream -> target.outputStream().use { output -> sourceStream.copyTo(output) } }
            if (!target.exists() || target.length() == 0L) throw IllegalStateException("Le document est vide ou n'a pas pu être copié.")
            val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", target)
            val mime = attachment.mimeType.takeIf { it.isNotBlank() && it != "application/octet-stream" }
                ?: resolver.getType(source) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Ouvrir avec"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "Aucune application ne peut ouvrir ce type de fichier.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Ouverture impossible : ${e.localizedMessage ?: "erreur d'accès au document"}", Toast.LENGTH_LONG).show()
        }
    }
}
