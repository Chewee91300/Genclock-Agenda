package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt


@Composable
internal fun Mode3DButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(13.dp)
    val top = if (selected) colors.primary else colors.surface
    val bottom = if (selected) colors.primary.copy(alpha = 0.78f) else colors.surfaceVariant
    val textColor = if (selected) colors.onPrimary else colors.onSurface

    Surface(
        onClick = onClick,
        shape = shape,
        color = Color.Transparent,
        shadowElevation = if (selected) 2.dp else 6.dp,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 1.5.dp else 1.dp,
            if (selected) colors.primary.copy(alpha = 0.95f) else colors.outline.copy(alpha = 0.42f)
        ),
        modifier = modifier.height(36.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(top, bottom)))
                .then(if (selected) Modifier else Modifier.background(Color.White.copy(alpha = 0.08f)))
                 .padding(horizontal = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = textColor, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, softWrap = false)
        }
    }
}

internal data class AppThemePalette(
    val primary: Color, val onPrimary: Color, val primaryContainer: Color, val onPrimaryContainer: Color,
    val secondary: Color, val background: Color, val surface: Color, val onSurface: Color,
    val surfaceVariant: Color, val onSurfaceVariant: Color, val dark: Boolean = false
)

internal fun appThemeOptions() = listOf(
    Triple("blueelectric", "Blue Electric", "Bleu nuit, bleu acier et accents lumineux"),
    Triple("purple", "Purple Premium", "Prune profonde et lavande élégante"),
    Triple("sunset", "Sunset Premium", "Terracotta, cuivre et ivoire"),
    Triple("greenenergy", "Green Energy", "Émeraude, sauge et pierre claire"),
    Triple("blackgold", "Black Gold", "Graphite, or doux et champagne"),
    Triple("custom", "Personnalisé", "Choisissez vos propres couleurs")
)

internal fun appThemePalette(id: String): AppThemePalette = when (id) {
    "purple" -> AppThemePalette(Color(0xFF7653A6), Color.White, Color(0xFFECE3F5), Color(0xFF38234F), Color(0xFFB28BCB), Color(0xFFF7F3FA), Color(0xFFFFFDFF), Color(0xFF292231), Color(0xFFECE6F1), Color(0xFF665C70))
    "sunset" -> AppThemePalette(Color(0xFFB65F45), Color.White, Color(0xFFF6E2D9), Color(0xFF653323), Color(0xFFD49A68), Color(0xFFFAF5F0), Color(0xFFFFFEFC), Color(0xFF332720), Color(0xFFF0E7DE), Color(0xFF75675C))
    "greenenergy" -> AppThemePalette(Color(0xFF287765), Color.White, Color(0xFFDDEFE9), Color(0xFF194B40), Color(0xFF78A99A), Color(0xFFF2F7F4), Color(0xFFFFFEFC), Color(0xFF20342E), Color(0xFFE3ECE7), Color(0xFF61736A))
    "blackgold" -> AppThemePalette(Color(0xFF9A7A3D), Color(0xFF17140E), Color(0xFFEDE3CC), Color(0xFF46371C), Color(0xFFC5A66A), Color(0xFF171819), Color(0xFF242526), Color(0xFFF2EFE8), Color(0xFF353638), Color(0xFFC8C2B6), true)
    "midnight" -> AppThemePalette(Color(0xFFB99AFF), Color(0xFF24143D), Color(0xFF49336A), Color(0xFFE9DDFF), Color(0xFFCFB7FF), Color(0xFF12121A), Color(0xFF1D1C28), Color(0xFFF0EDF7), Color(0xFF302D3C), Color(0xFFC5BED2), true)
    "pastel" -> AppThemePalette(Color(0xFF8876C7), Color.White, Color(0xFFE9E1FA), Color(0xFF40345F), Color(0xFF70A99A), Color(0xFFFFFAF5), Color(0xFFFFFEFC), Color(0xFF40394A), Color(0xFFF4EAF1), Color(0xFF756B7B))
    "glass" -> AppThemePalette(Color(0xFF356BD6), Color.White, Color(0xFFDCE9FF), Color(0xFF19396F), Color(0xFF7856D8), Color(0xFFF1F5FF), Color.White, Color(0xFF1D2B45), Color(0xFFE4EBF8), Color(0xFF5D6B83))
    "nature" -> AppThemePalette(Color(0xFF477B5A), Color.White, Color(0xFFDDEBDD), Color(0xFF23452E), Color(0xFF91A987), Color(0xFFF7F6EF), Color(0xFFFFFEF8), Color(0xFF29372B), Color(0xFFEAEBDD), Color(0xFF687360))
    else -> AppThemePalette(Color(0xFF245A9B), Color.White, Color(0xFFDCEBFA), Color(0xFF173A63), Color(0xFF4E83B9), Color(0xFFF5F8FC), Color.White, Color(0xFF202B39), Color(0xFFE8EFF7), Color(0xFF637184))
}

internal fun parseThemeHex(value: String, fallback: Color): Color = runCatching {
    val clean = value.trim().removePrefix("#")
    require(clean.length == 6)
    Color(android.graphics.Color.parseColor("#$clean"))
}.getOrDefault(fallback)

internal fun dayStart(time: Long): Calendar = Calendar.getInstance().apply {
    timeInMillis = time
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}
internal fun sameDay(a: Long, b: Long): Boolean {
    val x = dayStart(a); val y = dayStart(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}
internal fun shiftDate(time: Long, view: String, amount: Int): Long = Calendar.getInstance().apply {
    timeInMillis = time
    add(when(view) { "Jour" -> Calendar.DAY_OF_MONTH; "Semaine", "Papier" -> Calendar.WEEK_OF_YEAR; else -> Calendar.MONTH }, amount)
}.timeInMillis

