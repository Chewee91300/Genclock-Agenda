package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    @Volatile var lastError: String? = null
        private set

    private fun pending(context: Context, event: AgendaEvent, receiver: Class<*>): PendingIntent {
        val intent = Intent(context, receiver).apply {
            putExtra("eventId", event.id)
            putExtra("title", event.title)
            putExtra("description", event.description)
            putExtra("alarmSoundUri", event.alarmSoundUri)
            putExtra("vibrate", event.vibrate)
        }
        return PendingIntent.getBroadcast(
            context, event.id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, event: AgendaEvent): Boolean = scheduleAt(
        context, event, event.alarmTimeMillis ?: (event.timeMillis - event.leadMinutes * 60_000L), ReminderReceiver::class.java, false
    )

    fun scheduleAlarm(context: Context, event: AgendaEvent, timeMillis: Long = event.timeMillis): Boolean =
        scheduleAt(context, event, event.alarmTimeMillis ?: (timeMillis - event.leadMinutes * 60_000L), AlarmReceiver::class.java, true)

    private fun scheduleAt(context: Context, event: AgendaEvent, triggerAt: Long, receiver: Class<*>, exactRequired: Boolean): Boolean {
        lastError = null
        if (triggerAt <= System.currentTimeMillis()) {
            lastError = "L'heure du rappel est déjà passée. Vérifie l'heure de l'événement et le délai du rappel."
            return false
        }
        return try {
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pending(context, event, receiver)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                if (exactRequired) {
                    lastError = "Android indique que l'autorisation « Alarmes et rappels » n'est pas accordée."
                    return false
                }
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                try {
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                } catch (security: SecurityException) {
                    if (exactRequired) {
                        lastError = "Android a refusé la programmation exacte : ${security.message ?: "autorisation système"}."
                        return false
                    }
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            }
            true
        } catch (error: Exception) {
            lastError = "Erreur Android (${error.javaClass.simpleName}) : ${error.message ?: "détail indisponible"}"
            false
        }
    }

    /** Programme les occurrences de la série dans une fenêtre glissante de 180 jours. */
    fun scheduleSeries(context: Context, event: AgendaEvent): Boolean {
        val now = System.currentTimeMillis()
        val until = now + 180L * 24L * 60L * 60L * 1000L
        val occurrences = RecurrenceEngine.expand(listOf(event), now - 60_000L, until)
        var ok = true
        occurrences.forEach { occurrence ->
            if (occurrence.reminderMode == "notification" || occurrence.reminderMode == "both") {
                ok = schedule(context, occurrence) && ok
            }
            if (occurrence.reminderMode == "alarm" || occurrence.reminderMode == "both") {
                ok = scheduleAlarm(context, occurrence) && ok
            }
        }
        return ok
    }

    fun cancelSeries(context: Context, event: AgendaEvent) {
        val until = System.currentTimeMillis() + 180L * 24L * 60L * 60L * 1000L
        RecurrenceEngine.expand(listOf(event), event.timeMillis - 60_000L, until).forEach { cancel(context, it) }
        cancel(context, event)
    }

    fun cancel(context: Context, event: AgendaEvent) {
        try {
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            manager.cancel(pending(context, event, ReminderReceiver::class.java))
            manager.cancel(pending(context, event, AlarmReceiver::class.java))
        } catch (_: Exception) { }
    }
}
