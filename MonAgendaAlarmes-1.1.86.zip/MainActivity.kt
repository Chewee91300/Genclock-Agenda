package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen() {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val fabPositionPrefs = remember { context.getSharedPreferences("interface", android.content.Context.MODE_PRIVATE) }
    var fabOffsetX by remember { mutableFloatStateOf(fabPositionPrefs.getFloat("fab_offset_x", 0f)) }
    var fabOffsetY by remember { mutableFloatStateOf(fabPositionPrefs.getFloat("fab_offset_y", 0f)) }
    val store = remember { EventStore(context) }
    var events by remember { mutableStateOf(store.load()) }
    var message by remember { mutableStateOf<String?>(null) }
    var photoOcrText by remember { mutableStateOf("") }
    var showPhotoImport by remember { mutableStateOf(false) }
    var photoCandidates by remember { mutableStateOf(listOf<PhotoEventCandidate>()) }
    var ocrBusy by remember { mutableStateOf(false) }
    var importSource by remember { mutableStateOf("photo") }
    var voiceWizardStep by remember { mutableIntStateOf(-1) }
    var voiceTitle by remember { mutableStateOf("") }
    var voiceDate by remember { mutableStateOf("") }
    var voiceStart by remember { mutableStateOf("") }
    var voiceDuration by remember { mutableStateOf("") }
    var voiceAnswer by remember { mutableStateOf("") }
    var voiceStartMillis by remember { mutableStateOf<Long?>(null) }
    var showVoiceSummary by remember { mutableStateOf(false) }
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember { TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS } }
    var selectedDay by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ocrBusy = true
            runCatching {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        photoOcrText = result.text
                        photoCandidates = parsePhotoAgendaText(result.text, selectedDay)
                        showPhotoImport = true
                        ocrBusy = false
                    }.addOnFailureListener {
                        ocrBusy = false
                        message = "Lecture de la photo impossible. Essaie avec une image plus nette."
                    }
            }.onFailure {
                ocrBusy = false
                message = "Impossible d'ouvrir cette photo."
            }
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty().trim()
        if (result.resultCode == android.app.Activity.RESULT_OK && spoken.isNotBlank()) {
            voiceAnswer = spoken
            val answeredStep = voiceWizardStep
            when (voiceWizardStep) {
                0 -> { voiceTitle = spoken; voiceWizardStep = 1 }
                1 -> {
                    val parsed = parseVoiceDate(spoken, selectedDay)
                    if (parsed == null) { message = "Date non reconnue. Recommence en disant par exemple : 12 novembre 2026."; voiceWizardStep = -1; Handler(Looper.getMainLooper()).postDelayed({ voiceWizardStep = answeredStep }, 900) }
                    else { voiceDate = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date(parsed)); voiceStartMillis = parsed; voiceWizardStep = 2 }
                }
                2 -> {
                    val hour = parseVoiceTime(spoken)
                    if (hour == null) { message = "Heure non reconnue. Dis par exemple : 14 heures 30."; voiceWizardStep = -1; Handler(Looper.getMainLooper()).postDelayed({ voiceWizardStep = answeredStep }, 900) }
                    else {
                        val base = voiceStartMillis ?: selectedDay
                        val cal = Calendar.getInstance().apply { timeInMillis = base; set(Calendar.HOUR_OF_DAY, hour.first); set(Calendar.MINUTE, hour.second); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                        voiceStartMillis = cal.timeInMillis
                        voiceStart = String.format(Locale.FRANCE, "%02d:%02d", hour.first, hour.second)
                        voiceWizardStep = 3
                    }
                }
                3 -> {
                    val minutes = parseVoiceDuration(spoken)
                    if (minutes == null) { message = "Durée non reconnue. Dis par exemple : 1 heure ou 30 minutes."; voiceWizardStep = -1; Handler(Looper.getMainLooper()).postDelayed({ voiceWizardStep = answeredStep }, 900) }
                    else { voiceDuration = spoken; voiceWizardStep = 4; showVoiceSummary = true }
                }
            }
        } else if (result.resultCode == android.app.Activity.RESULT_OK) {
            message = "Je n'ai pas compris. Tu peux recommencer cette étape."
        } else {
            voiceWizardStep = -1
        }
    }
    fun launchVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        runCatching { speechLauncher.launch(intent) }.onFailure { message = "La reconnaissance vocale n'est pas disponible sur cet appareil." }
    }
    val voicePrompts = listOf("Quel est le titre de votre événement ?", "Quelle est la date ?", "À quelle heure commence-t-il ?", "Quelle est la durée de l'événement ?")
    LaunchedEffect(voiceWizardStep, ttsReady) {
        if (voiceWizardStep in 0..3 && ttsReady) {
            tts.language = Locale.FRANCE
            tts.setSpeechRate(0.92f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) { Handler(Looper.getMainLooper()).post { launchVoiceRecognition() } }
                override fun onDone(utteranceId: String?) { Handler(Looper.getMainLooper()).post { launchVoiceRecognition() } }
            })
            tts.speak(voicePrompts[voiceWizardStep], TextToSpeech.QUEUE_FLUSH, null, "voice_step_$voiceWizardStep")
        }
    }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }
    fun startVoiceInput() {
        voiceTitle = ""; voiceDate = ""; voiceStart = ""; voiceDuration = ""; voiceAnswer = ""; voiceStartMillis = null
        showVoiceSummary = false
        voiceWizardStep = 0
    }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                // Restaurer d'abord la sauvegarde existante. Ne jamais l'écraser
                // avec la liste vide chargée avant que l'utilisateur ait choisi le dossier.
                events = store.attachBackupTree(uri, events)
                message = if (events.isNotEmpty()) {
                    "Sauvegarde retrouvée : ${events.size} événement(s) restauré(s)."
                } else {
                    "Sauvegarde automatique activée dans Documents/MonAgendaAlarmes."
                }
            }.onFailure {
                message = "Impossible d'activer la sauvegarde locale. Vérifie que le dossier Documents est accessible."
            }
        }
    }
    LaunchedEffect(Unit) {
        if (store.backupTreeUri() == null) {
            val documentsUri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADocuments")
            backupFolderPicker.launch(documentsUri)
        }
    }
    var showEditor by remember { mutableStateOf(false) }
    var eventBeingEdited by remember { mutableStateOf<AgendaEvent?>(null) }
    var newEventInitialTime by remember { mutableStateOf<Long?>(null) }
    var showExactAlarmDialog by remember { mutableStateOf(false) }
    var showDndAlert by remember { mutableStateOf(false) }
    var showDndAccessDialog by remember { mutableStateOf(false) }
    var dndWasActive by remember { mutableStateOf(false) }
    var showDayEvents by remember { mutableStateOf(true) }
    var showWeekend by rememberSaveable { mutableStateOf(true) }
    var eventsMaximized by remember { mutableStateOf(false) }
    var paperFullScreen by rememberSaveable { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showThemes by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val themePrefs = remember { context.getSharedPreferences("interface", android.content.Context.MODE_PRIVATE) }
    var selectedTheme by remember { mutableStateOf(themePrefs.getString("selected_theme", "elegance") ?: "elegance") }
    var minimumAlarmVolume by remember { mutableFloatStateOf(themePrefs.getInt("minimum_alarm_volume_percent", 20).toFloat()) }
    var outlookDeleteTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var outlookReminderTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val appVersion = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "inconnue" }.getOrDefault("inconnue")
    }
    var view by rememberSaveable { mutableStateOf("Mois") }
    var outlookEvents by remember { mutableStateOf(emptyList<AgendaEvent>()) }
    val allEvents = remember(events, outlookEvents) { (events + outlookEvents).distinctBy { it.id }.sortedBy { it.timeMillis } }

    val calendarPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        } else {
            message = "Autorisation de lecture du calendrier refusée. Active-la dans les paramètres Android pour afficher les événements Outlook."
        }
    }

    val outlookWritePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val target = outlookDeleteTarget
        if (granted && target != null) {
            if (OutlookCalendarReader.deleteEvent(context, target)) {
                ReminderScheduler.cancel(context, target)
                events = events.filterNot { it.id == target.id }
                store.save(events)
                outlookEvents = outlookEvents.filterNot { it.id == target.id }
                message = "Événement supprimé du calendrier synchronisé."
            } else message = "La suppression a échoué. Vérifie les droits du calendrier synchronisé."
        } else if (!granted) message = "Autorisation de modification du calendrier refusée."
        outlookDeleteTarget = null
    }

    var notificationsAllowed by remember {
        mutableStateOf(
            android.os.Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
        )
    }

    // La réponse Android est prise en compte immédiatement, sans redémarrer l'application.
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsAllowed = granted
        if (granted) {
            store.load()
                .filter { it.reminderMode == "notification" || it.reminderMode == "both" }
                .forEach { ReminderScheduler.schedule(context, it) }
            message = "Notifications autorisées. Les rappels enregistrés sont maintenant activés."
        } else {
            message = "Notifications non autorisées. Tu peux les activer dans les paramètres Android."
        }
    }
    fun exactAlarmsAllowed(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) return true
        val manager = context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager
        return manager.canScheduleExactAlarms()
    }
    fun hasDndAccess(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M) return false
        val manager = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
        return manager.isNotificationPolicyAccessGranted
    }

    fun isDndActive(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M || !hasDndAccess()) return false
        val manager = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
        return manager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
            manager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    fun checkDoNotDisturb() {
        if (!hasDndAccess()) return
        val active = isDndActive()
        if (active && !dndWasActive) showDndAlert = true
        dndWasActive = active
    }

    LaunchedEffect(Unit) {
        while (true) {
            clockNow = System.currentTimeMillis()
            checkDoNotDisturb()
            delay(2000)
        }
    }

    LaunchedEffect(Unit) {
        if (!exactAlarmsAllowed()) showExactAlarmDialog = true
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
            !hasDndAccess() && !themePrefs.getBoolean("dnd_access_prompted", false)) {
            themePrefs.edit().putBoolean("dnd_access_prompted", true).apply()
            showDndAccessDialog = true
        }
        // Outlook n'est plus importé automatiquement : l'utilisateur lance la synchronisation
        // depuis le bouton Actualiser du bandeau.
        if (android.os.Build.VERSION.SDK_INT >= 33 && !notificationsAllowed) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Actualisation automatique à chaque retour de l'application au premier plan.
    val lifecycle = (context as? ComponentActivity)?.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (!exactAlarmsAllowed()) showExactAlarmDialog = true
                checkDoNotDisturb()

                // Android peut modifier l'autorisation pendant que l'application est en arrière-plan.
                // On relit son état au retour, puis on restaure les rappels sans fermeture/réouverture.
                notificationsAllowed = android.os.Build.VERSION.SDK_INT < 33 ||
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED

                store.load().forEach { saved ->
                    when (saved.reminderMode) {
                        "alarm" -> if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        "notification" -> if (notificationsAllowed) ReminderScheduler.schedule(context, saved)
                        "both" -> {
                            if (notificationsAllowed) ReminderScheduler.schedule(context, saved)
                            if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        }
                    }
                }
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    val hostActivity = context as? ComponentActivity
    DisposableEffect(paperFullScreen, hostActivity) {
        val window = hostActivity?.window
        if (paperFullScreen) {
            // L'état est sauvegardé : après la recréation de l'activité en paysage,
            // le mode papier reste actif au lieu de revenir à l'écran normal.
            hostActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            hostActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        onDispose {
            // Ne pas rétablir l'ancienne orientation ici : onDispose est aussi
            // appelé lors de la recréation provoquée par le passage en paysage.
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    val theme = appThemePalette(selectedTheme)
    MaterialTheme(colorScheme = if (theme.dark) darkColorScheme(
        primary = theme.primary, onPrimary = theme.onPrimary,
        primaryContainer = theme.primaryContainer, onPrimaryContainer = theme.onPrimaryContainer,
        secondary = theme.secondary, background = theme.background, surface = theme.surface,
        onSurface = theme.onSurface, surfaceVariant = theme.surfaceVariant,
        onSurfaceVariant = theme.onSurfaceVariant
    ) else lightColorScheme(
        primary = theme.primary, onPrimary = theme.onPrimary,
        primaryContainer = theme.primaryContainer, onPrimaryContainer = theme.onPrimaryContainer,
        secondary = theme.secondary, background = theme.background, surface = theme.surface,
        onSurface = theme.onSurface, surfaceVariant = theme.surfaceVariant,
        onSurfaceVariant = theme.onSurfaceVariant
    )) {
        Scaffold(
            containerColor = if (paperFullScreen) Color(0xFFE9DDBD) else theme.background,
            topBar = {
                if (!paperFullScreen) {
                Box(Modifier.fillMaxWidth().height(78.dp).statusBarsPadding()) {
                    Image(painter = painterResource(id = R.drawable.banner_agenda), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(78.dp), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxWidth().height(78.dp).background(theme.primary.copy(alpha = 0.48f)))
                    Row(Modifier.fillMaxWidth().align(Alignment.Center).padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(7.dp))
                        Text("Mon Agenda & Alarme", color = Color.White, fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp, lineHeight = 18.sp, maxLines = 1, softWrap = false,
                            modifier = Modifier.weight(1f))
                        IconButton(onClick = { showSettings = true }, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Default.Settings, contentDescription = "Paramètres", tint = Color.White, modifier = Modifier.size(25.dp))
                        }
                        IconButton(onClick = { startVoiceInput() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Mic, contentDescription = "Dicter un événement", tint = Color.White, modifier = Modifier.size(21.dp))
                        }
                        IconButton(onClick = { photoPicker.launch("image/*"); importSource = "photo" }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = "Importer depuis une photo", tint = Color.White, modifier = Modifier.size(21.dp))
                        }
                        IconButton(onClick = {
                            if (OutlookCalendarReader.hasPermission(context)) {
                                outlookEvents = OutlookCalendarReader.readEvents(context)
                                message = "Calendrier synchronisé actualisé."
                            } else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                        }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Actualiser Outlook", tint = Color.White, modifier = Modifier.size(23.dp))
                        }
                    }
                }
                }
            },
            floatingActionButton = {
                if (!paperFullScreen) {
                FloatingActionButton(
                    onClick = { showEditor = true },
                    modifier = Modifier
                        .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
                        .pointerInput(configuration.screenWidthDp, configuration.screenHeightDp) {
                            detectDragGesturesAfterLongPress(
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    val maxLeft = with(density) { (configuration.screenWidthDp - 80).coerceAtLeast(0).dp.toPx() }
                                    val maxUp = with(density) { (configuration.screenHeightDp - 180).coerceAtLeast(0).dp.toPx() }
                                    fabOffsetX = (fabOffsetX + dragAmount.x).coerceIn(-maxLeft, 0f)
                                    fabOffsetY = (fabOffsetY + dragAmount.y).coerceIn(-maxUp, 0f)
                                    fabPositionPrefs.edit()
                                        .putFloat("fab_offset_x", fabOffsetX)
                                        .putFloat("fab_offset_y", fabOffsetY)
                                        .apply()
                                }
                            )
                        },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un événement — maintenir appuyé pour déplacer")
                }
                }
            }
        ) { padding ->
            if (paperFullScreen) {
                Column(Modifier.fillMaxSize().background(Color(0xFFD9D2C6)).padding(5.dp).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth().height(38.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("AGENDA DE LA SEMAINE", color = Color(0xFF59452B), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { paperFullScreen = false; view = "Semaine" }) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF59452B))
                            Text("Sortir", color = Color(0xFF59452B), fontWeight = FontWeight.Bold)
                        }
                    }
                    WeeklyPaperAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, onEditEvent = { eventBeingEdited = it; showEditor = true }, fullScreen = true, modifier = Modifier.weight(1f))
                }
            } else Column(Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (listOf("Jour", "Semaine") + (if (view == "Semaine") listOf("Papier") else emptyList()) + listOf("Mois")).forEach { label ->
                            Mode3DButton(
                                label = label,
                                selected = view == label,
                                onClick = {
                                    view = label
                                    if (label == "Papier") paperFullScreen = true
                                }
                            )
                        }
                    }
                    Text(SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date(clockNow)), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                if (!eventsMaximized) {
                    CalendarNavigator(view, selectedDay, onPrevious = { selectedDay = shiftDate(selectedDay, view, -1) },
                        onNext = { selectedDay = shiftDate(selectedDay, view, 1) }, onToday = { selectedDay = System.currentTimeMillis() })
                    when (view) {
                        "Jour" -> DayAgenda(
                            selectedDay, allEvents, nowMillis = clockNow,
                            onEditEvent = { event -> eventBeingEdited = event; newEventInitialTime = null; showEditor = true },
                            onAddAtTime = { time -> eventBeingEdited = null; newEventInitialTime = time; showEditor = true },
                            onDeleteEvent = { event -> if (event.outlookEventId != null) outlookDeleteTarget = event else { ReminderScheduler.cancel(context, event); events = events.filterNot { it.id == event.id }; store.save(events) } },
                            expanded = !showDayEvents,
                            modifier = Modifier.weight(1f)
                        )
                        "Semaine" -> WeekAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, onEditEvent = { event -> eventBeingEdited = event; newEventInitialTime = null; showEditor = true }, onAddAtTime = { time -> eventBeingEdited = null; newEventInitialTime = time; showEditor = true }, onDeleteEvent = { event -> if (event.outlookEventId != null) outlookDeleteTarget = event else { ReminderScheduler.cancel(context, event); events = events.filterNot { it.id == event.id }; store.save(events) } }, showWeekend = showWeekend, onToggleWeekend = { showWeekend = it }, modifier = Modifier.weight(1f))
                        "Papier" -> WeeklyPaperAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, onEditEvent = { eventBeingEdited = it; showEditor = true })
                        else -> MonthAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                    }
                }
                val dayEvents = allEvents.filter { sameDay(it.timeMillis, selectedDay) }.sortedBy { it.timeMillis }
                if (view == "Mois" || view == "Papier") {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 7.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp)).padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Événements du ${SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(selectedDay))}",
                        fontSize = 15.sp, lineHeight = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
                        modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                    if (!eventsMaximized) {
                        TextButton(onClick = { showDayEvents = !showDayEvents }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) {
                            Text(if (showDayEvents) "Masquer" else "Afficher", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (showDayEvents) {
                        TextButton(onClick = { eventsMaximized = !eventsMaximized }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) {
                            Text(if (eventsMaximized) "Réduire" else "Agrandir", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (showDayEvents) {
                    if (dayEvents.isEmpty()) Text("Aucun événement ce jour.", Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(dayEvents, key = { it.id }) { event ->
                            EventCard(event, onEdit = {
                                if (event.outlookEventId != null) {
                                    val editIntent = Intent(Intent.ACTION_EDIT).apply {
                                        data = android.content.ContentUris.withAppendedId(
                                            android.provider.CalendarContract.Events.CONTENT_URI, event.outlookEventId
                                        )
                                        type = "vnd.android.cursor.item/event"
                                    }
                                    runCatching { context.startActivity(editIntent) }
                                        .onFailure { message = "Aucune application de calendrier ne permet de modifier cet événement." }
                                }
                            }, onDelete = {
                                if (event.outlookEventId != null) {
                                    outlookDeleteTarget = event
                                } else {
                                    ReminderScheduler.cancel(context, event)
                                    events = events.filterNot { it.id == event.id }
                                    store.save(events)
                                }
                            }, onAlarm = {
                                if (event.outlookEventId != null) outlookReminderTarget = event
                                else {
                                    eventBeingEdited = event
                                    showEditor = true
                                }
                            })
                        }
                    }
                }
                }
            }
        }
    }

    if (voiceWizardStep in 0..3 && !showVoiceSummary) {
        AlertDialog(
            onDismissRequest = { voiceWizardStep = -1 },
            title = { Text(listOf("Titre", "Date", "Heure de début", "Durée")[voiceWizardStep]) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(voicePrompts[voiceWizardStep], fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Icon(Icons.Default.Mic, contentDescription = "Écoute vocale", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                    Text("Écoute en cours…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (voiceAnswer.isNotBlank()) Text("Dernière réponse : $voiceAnswer", fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { launchVoiceRecognition() }) { Text("Réessayer cette étape") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { startVoiceInput() }) { Text("Recommencer") }
                    TextButton(onClick = { voiceWizardStep = -1 }) { Text("Annuler") }
                }
            }
        )
    }
    if (showVoiceSummary) {
        val start = voiceStartMillis
        val durationMinutes = parseVoiceDuration(voiceDuration)
        AlertDialog(
            onDismissRequest = { showVoiceSummary = false; voiceWizardStep = -1 },
            title = { Text("Vérifier l'événement") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Voici la fiche de votre événement :", fontWeight = FontWeight.SemiBold)
                    Text("Titre : $voiceTitle")
                    Text("Date : $voiceDate")
                    Text("Heure de début : $voiceStart")
                    Text("Durée : $voiceDuration")
                    if (start != null && durationMinutes != null) Text("Heure de fin : ${SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(start + durationMinutes * 60_000L))}")
                }
            },
            confirmButton = { TextButton(onClick = {
                if (start != null && durationMinutes != null && voiceTitle.isNotBlank()) {
                    val event = AgendaEvent(System.currentTimeMillis(), voiceTitle.trim(), "Ajouté par assistant vocal", start, "none", 15, endTimeMillis = start + durationMinutes * 60_000L)
                    eventBeingEdited = event; newEventInitialTime = null; showEditor = true
                }
                showVoiceSummary = false; voiceWizardStep = -1
            }) { Text("Continuer vers la fiche") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { startVoiceInput() }) { Text("Recommencer la saisie") }
                    TextButton(onClick = { showVoiceSummary = false; voiceWizardStep = -1 }) { Text("Annuler") }
                }
            }
        )
    }
    if (showPhotoImport) {
        AlertDialog(
            onDismissRequest = { showPhotoImport = false },
            title = { Text(if (importSource == "voix") "Vérifier l’événement dicté" else "Vérifier les rendez-vous détectés") },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (importSource == "voix") "Vérifie la transcription, la date et l’heure. La reconnaissance vocale peut nécessiter Internet selon le service Android installé. Rien ne sera ajouté sans ta validation." else "Reconnaissance locale hors ligne. Vérifie chaque date, heure et intitulé : l’écriture manuscrite peut être mal interprétée. Rien ne sera ajouté sans ta validation.", fontSize = 12.sp)
                    if (photoCandidates.isEmpty()) {
                        Text("Aucun rendez-vous daté n'a pu être détecté automatiquement. Tu peux corriger la transcription ci-dessous.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    } else {
                        Text("${photoCandidates.size} rendez-vous potentiel(s). Les doublons avec ton agenda seront ignorés.", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        photoCandidates.forEachIndexed { index, candidate ->
                            val candidateTime = parsePhotoDateTime(candidate.dateTimeText)
                            val conflict = candidateTime?.let { proposed ->
                                events.firstOrNull { existing -> sameCalendarHour(existing.timeMillis, proposed) }
                            }
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = candidate.selected, onCheckedChange = { checked -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(selected = checked) } })
                                        Text("Rendez-vous ${index + 1}", fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedTextField(value = candidate.title, onValueChange = { value -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(title = value) } }, label = { Text("Intitulé") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(value = candidate.dateTimeText, onValueChange = { value -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(dateTimeText = value) } }, label = { Text("Date et heure (JJ/MM/AAAA HH:mm)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    if (candidate.endDateTimeText.isNotBlank() || importSource == "voix") {
                                        OutlinedTextField(
                                            value = candidate.endDateTimeText,
                                            onValueChange = { value -> photoCandidates = photoCandidates.toMutableList().also { it[index] = candidate.copy(endDateTimeText = value) } },
                                            label = { Text("Heure de fin (JJ/MM/AAAA HH:mm)") },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true
                                        )
                                    }
                                    if (candidate.dateTimeText.isNotBlank() && candidateTime == null) Text("Date ou heure à corriger", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                                    if (conflict != null) Text("⚠ Un événement existe déjà dans ton agenda à cette heure : ${conflict.title}. Ce rendez-vous ne sera pas importé tant que le conflit n'est pas résolu.", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Text(if (importSource == "voix") "Dictée reconnue (modifiable)" else "Transcription complète (modifiable)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(value = photoOcrText, onValueChange = { photoOcrText = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp, max = 180.dp), label = { Text(if (importSource == "voix") "Texte dicté" else "Texte extrait de la photo") })
                    Text("Les rappels et alarmes restent désactivés après import.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val selected = photoCandidates.filter { it.selected && it.title.isNotBlank() }
                    val valid = selected.mapNotNull { candidate -> parsePhotoDateTime(candidate.dateTimeText)?.let { candidate to it } }
                    val invalidCount = selected.size - valid.size
                    val existingKeys = events.map { photoDuplicateKey(it.title, it.timeMillis) }.toSet()
                    val additions = valid.filter { (candidate, time) ->
                        photoDuplicateKey(candidate.title, time) !in existingKeys &&
                            events.none { existing -> sameCalendarHour(existing.timeMillis, time) }
                    }.mapIndexed { idx, pair ->
                        val endTime = parsePhotoDateTime(pair.first.endDateTimeText)?.takeIf { it > pair.second }
                        AgendaEvent(
                            System.currentTimeMillis() + idx,
                            pair.first.title.trim(),
                            if (importSource == "voix") "Ajouté par dictée vocale" else "Importé depuis une photo d’agenda",
                            pair.second, "none", 15,
                            endTimeMillis = endTime
                        )
                    }
                    val conflictCount = valid.count { (_, time) -> events.any { existing -> sameCalendarHour(existing.timeMillis, time) } }
                    events = (events + additions).distinctBy { it.id }.sortedBy { it.timeMillis }
                    store.save(events)
                    showPhotoImport = false
                    message = when {
                        additions.isEmpty() && conflictCount > 0 -> "Aucun rendez-vous importé : $conflictCount conflit(s) avec un événement déjà prévu à la même heure."
                        additions.isEmpty() -> "Aucun nouveau rendez-vous importé. Vérifie les dates ou les doublons."
                        conflictCount > 0 -> "${additions.size} rendez-vous importé(s). $conflictCount conflit(s) horaire(s) ignoré(s)."
                        invalidCount > 0 -> "${additions.size} rendez-vous importé(s). $invalidCount entrée(s) ignorée(s) car la date ou l'heure est invalide."
                        else -> "${additions.size} rendez-vous importé(s), sans rappel ni alarme."
                    }
                }) { Text("Importer la sélection") }
            },
            dismissButton = { TextButton(onClick = { showPhotoImport = false }) { Text("Annuler") } }
        )
    }
    outlookDeleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { outlookDeleteTarget = null },
            title = { Text("Supprimer du calendrier source ?") },
            text = { Text("« ${target.title} » sera supprimé du calendrier synchronisé et la suppression pourra être répercutée dans Outlook ou Google après synchronisation. Attention : si ce rendez-vous appartient à une série récurrente, la série entière peut être supprimée.") },
            confirmButton = {
                TextButton(onClick = {
                    if (OutlookCalendarReader.hasWritePermission(context)) {
                        if (OutlookCalendarReader.deleteEvent(context, target)) {
                            ReminderScheduler.cancel(context, target)
                            events = events.filterNot { it.id == target.id }
                            store.save(events)
                            outlookEvents = outlookEvents.filterNot { it.id == target.id }
                            message = "Événement supprimé du calendrier synchronisé."
                        } else message = "Impossible de supprimer cet événement."
                        outlookDeleteTarget = null
                    } else {
                        outlookWritePermission.launch(Manifest.permission.WRITE_CALENDAR)
                    }
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { outlookDeleteTarget = null }) { Text("Annuler") } }
        )
    }

    outlookReminderTarget?.let { target ->
        OutlookReminderEditor(
            event = target,
            onDismiss = { outlookReminderTarget = null },
            onSave = { mode, lead, alarmTime, soundUri, vibrate ->
                val updated = target.copy(reminderMode = mode, leadMinutes = lead, alarmTimeMillis = alarmTime, alarmSoundUri = soundUri, vibrate = vibrate)
                ReminderScheduler.cancel(context, target)
                events = (events.filterNot { it.id == target.id } + updated).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = when (mode) {
                    "alarm" -> ReminderScheduler.scheduleAlarm(context, updated)
                    "both" -> {
                        val notificationOk = ReminderScheduler.schedule(context, updated)
                        val alarmOk = ReminderScheduler.scheduleAlarm(context, updated)
                        notificationOk && alarmOk
                    }
                    else -> ReminderScheduler.schedule(context, updated)
                }
                outlookReminderTarget = null
                if (scheduled) message = when (mode) {
                    "alarm" -> "Alarme sonore ajoutée à l’événement Outlook."
                    "both" -> "Notification et alarme ajoutées à l’événement Outlook."
                    else -> "Notification ajoutée à l’événement Outlook."
                }
                else {
                    message = "Le rappel est enregistré, mais n’a pas pu être programmé. ${ReminderScheduler.lastError ?: "Vérifie les autorisations de notification et d'alarme."}"
                    if ((mode == "alarm" || mode == "both") && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }

    if (showEditor) {
        val editing = eventBeingEdited
        EventEditor(
            initialDateMillis = editing?.timeMillis ?: selectedDay,
            initialTimeMillis = if (editing == null) newEventInitialTime else null,
            initialEvent = editing,
            eventStore = store,
            onDismiss = { showEditor = false; eventBeingEdited = null; newEventInitialTime = null },
            onSave = { title, desc, time, endTime, mode, lead, soundUri, vibrate, attachments ->
                val event = if (editing != null) editing.copy(
                    title = title, description = desc, timeMillis = time, endTimeMillis = endTime,
                    reminderMode = mode, leadMinutes = lead, alarmTimeMillis = null,
                    alarmSoundUri = soundUri, vibrate = vibrate, attachments = attachments
                ) else AgendaEvent(System.currentTimeMillis(), title, desc, time, mode, lead, endTimeMillis = endTime, alarmSoundUri = soundUri, vibrate = vibrate, attachments = attachments)
                if (editing != null) ReminderScheduler.cancel(context, editing)
                events = (events.filterNot { it.id == event.id } + event).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = when (mode) {
                    "notification" -> ReminderScheduler.schedule(context, event)
                    "alarm" -> ReminderScheduler.scheduleAlarm(context, event)
                    "both" -> {
                        val notificationOk = ReminderScheduler.schedule(context, event)
                        val alarmOk = ReminderScheduler.scheduleAlarm(context, event)
                        notificationOk && alarmOk
                    }
                    else -> false
                }
                showEditor = false
                eventBeingEdited = null
                newEventInitialTime = null
                selectedDay = time
                if (scheduled) message = if (editing != null) "Événement modifié et rappel reprogrammé." else "Événement enregistré."
                else {
                    message = "L'événement est enregistré, mais le rappel n'a pas pu être programmé. ${ReminderScheduler.lastError ?: "Vérifie les autorisations de notification et d'alarme."}"
                    if ((mode == "alarm" || mode == "both") && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }
    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Paramètres", fontWeight = FontWeight.Bold)
            } },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Text("APPARENCE", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    appThemeOptions().forEach { option ->
                        val colors = appThemePalette(option.first)
                        Surface(onClick = {
                            selectedTheme = option.first
                            themePrefs.edit().putString("selected_theme", option.first).apply()
                        }, shape = RoundedCornerShape(13.dp), color = colors.surface,
                            border = androidx.compose.foundation.BorderStroke(if (selectedTheme == option.first) 2.dp else 1.dp,
                                if (selectedTheme == option.first) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    listOf(colors.primary, colors.secondary, colors.primaryContainer).forEach { swatch ->
                                        Box(Modifier.size(18.dp, 30.dp).background(swatch, RoundedCornerShape(5.dp)))
                                    }
                                }
                                Text(option.second, modifier = Modifier.weight(1f), color = colors.onSurface, fontWeight = FontWeight.SemiBold)
                                if (selectedTheme == option.first) Icon(Icons.Default.Palette, contentDescription = "Sélectionné", tint = colors.primary)
                            }
                        }
                    }
                    HorizontalDivider()
                    Text("VOLUME MINIMUM DES ALARMES", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Text("Si le volume des alarmes du téléphone est inférieur à ce seuil, l'application l'augmentera temporairement pendant la sonnerie, puis restaurera le volume initial.", style = MaterialTheme.typography.bodySmall)
                    Text("Minimum : ${minimumAlarmVolume.roundToInt()} %", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Slider(value = minimumAlarmVolume, onValueChange = { value ->
                        minimumAlarmVolume = value
                        themePrefs.edit().putInt("minimum_alarm_volume_percent", value.roundToInt()).apply()
                    }, valueRange = 5f..50f, steps = 8)
                    HorizontalDivider()
                    Text("AUTORISATIONS", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    @Composable fun PermissionLine(label: String, granted: Boolean) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (granted) Icons.Default.CheckCircle else Icons.Default.Warning, contentDescription = null,
                                tint = if (granted) Color(0xFF27834A) else MaterialTheme.colorScheme.error, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            Text(if (granted) "Activée" else "À vérifier", color = if (granted) Color(0xFF27834A) else MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    PermissionLine("Lecture du calendrier Outlook", ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED)
                    PermissionLine("Notifications", android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
                    PermissionLine("Alarmes et rappels exacts", exactAlarmsAllowed())
                    PermissionLine("Accès au mode Ne pas déranger", hasDndAccess())
                    OutlinedButton(onClick = { showSettings = false; context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Ouvrir les paramètres Android de l'application")
                    }
                    HorizontalDivider()
                    OutlinedButton(onClick = { showSettings = false; showAbout = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Info, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("À propos")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Fermer") } }
        )
    }

    if (showThemes) {
        AlertDialog(
            onDismissRequest = { showThemes = false },
            title = { Text("Apparence et thèmes", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    appThemeOptions().forEach { option ->
                        val colors = appThemePalette(option.first)
                        Surface(
                            onClick = {
                                selectedTheme = option.first
                                themePrefs.edit().putString("selected_theme", option.first).apply()
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = colors.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                if (selectedTheme == option.first) 2.dp else 1.dp,
                                if (selectedTheme == option.first) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(colors.primary, colors.secondary, colors.primaryContainer).forEach { swatch ->
                                        Box(Modifier.size(width = 22.dp, height = 38.dp).background(swatch, RoundedCornerShape(7.dp)))
                                    }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(option.second, color = colors.onSurface, fontWeight = FontWeight.Bold)
                                    Text(option.third, color = colors.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                                if (selectedTheme == option.first) Icon(Icons.Default.Palette, contentDescription = "Thème sélectionné", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    Divider()
                    Text("Volume minimum des alarmes", fontWeight = FontWeight.Bold)
                    Text("Si le volume des alarmes du téléphone est inférieur à ce seuil, l'application l'augmentera temporairement pendant la sonnerie, puis restaurera le volume initial.", style = MaterialTheme.typography.bodySmall)
                    Text("Minimum : ${minimumAlarmVolume.roundToInt()} %", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Slider(
                        value = minimumAlarmVolume,
                        onValueChange = { value ->
                            minimumAlarmVolume = value
                            themePrefs.edit().putInt("minimum_alarm_volume_percent", value.roundToInt()).apply()
                        },
                        valueRange = 5f..50f,
                        steps = 8
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showThemes = false }) { Text("Fermer") } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Mon Agenda & Alarmes", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(38.dp))
                            Text("Votre agenda, vos rappels.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Organisez vos événements et ne manquez plus aucun rendez-vous.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Text("Développé par V Da Silva", fontWeight = FontWeight.SemiBold)
                    Text("Version $appVersion", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Fermer") } }
        )
    }

    if (showDndAccessDialog) {
        AlertDialog(
            onDismissRequest = { showDndAccessDialog = false },
            title = { Text("Détection du mode Ne pas déranger") },
            text = { Text("Pour avertir lorsque le mode Ne pas déranger est activé, Mon Agenda & Alarmes doit pouvoir consulter le mode de concentration du téléphone. Autorise cet accès dans les paramètres Android. L'application ne modifiera pas ce réglage.") },
            confirmButton = {
                TextButton(onClick = {
                    showDndAccessDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }
                }) { Text("OUVRIR LES PARAMÈTRES") }
            },
            dismissButton = { TextButton(onClick = { showDndAccessDialog = false }) { Text("Plus tard") } }
        )
    }

    if (showDndAlert) {
        AlertDialog(
            onDismissRequest = { showDndAlert = false },
            title = { Text("Mode Ne pas déranger activé", fontWeight = FontWeight.Bold) },
            text = { Text("Attention : le mode Ne pas déranger est actif. Il peut silencier ou limiter les alarmes et notifications de Mon Agenda & Alarmes selon les réglages du téléphone.") },
            confirmButton = {
                TextButton(onClick = {
                    showDndAlert = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)) }
                    }
                }) { Text("VÉRIFIER LES PARAMÈTRES") }
            },
            dismissButton = { TextButton(onClick = { showDndAlert = false }) { Text("Fermer") } }
        )
    }

    if (showExactAlarmDialog) {
        AlertDialog(
            onDismissRequest = { showExactAlarmDialog = false },
            title = { Text("Autoriser les alarmes exactes") },
            text = { Text("Pour que les alarmes sonnent à l'heure prévue, Mon Agenda doit être autorisé à utiliser « Alarmes et rappels ». Active cette autorisation dans les paramètres Android.") },
            confirmButton = {
                TextButton(onClick = {
                    showExactAlarmDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:" + context.packageName)
                        }
                        context.startActivity(intent)
                    }
                }) { Text("ACTIVER LES ALARMES EXACTES") }
            },
            dismissButton = {
                TextButton(onClick = { showExactAlarmDialog = false }) { Text("Plus tard") }
            }
        )
    }

    message?.let {
        AlertDialog(onDismissRequest = { message = null }, confirmButton = {
            TextButton(onClick = { message = null }) { Text("OK") }
        }, title = { Text("Information") }, text = { Text(it) })
    }
}

@Composable
private fun Mode3DButton(label: String, selected: Boolean, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(13.dp)
    val top = if (selected) colors.primary else colors.surface
    val bottom = if (selected) colors.primary.copy(alpha = 0.78f) else colors.surfaceVariant
    val textColor = if (selected) colors.onPrimary else colors.onSurface

    Surface(
        onClick = onClick,
        shape = shape,
        color = Color.Transparent,
        shadowElevation = if (selected) 2.dp else 6.dp,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 1.5.dp else 1.dp,
            if (selected) colors.primary.copy(alpha = 0.95f) else colors.outline.copy(alpha = 0.42f)
        ),
        modifier = Modifier.height(36.dp)
    ) {
        Box(
            modifier = Modifier
                .background(Brush.verticalGradient(listOf(top, bottom)))
                .then(if (selected) Modifier else Modifier.background(Color.White.copy(alpha = 0.08f)))
                .padding(horizontal = 11.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = textColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

private data class AppThemePalette(
    val primary: Color, val onPrimary: Color, val primaryContainer: Color, val onPrimaryContainer: Color,
    val secondary: Color, val background: Color, val surface: Color, val onSurface: Color,
    val surfaceVariant: Color, val onSurfaceVariant: Color, val dark: Boolean = false
)

private fun appThemeOptions() = listOf(
    Triple("elegance", "Élégance – Bleu & Blanc", "Clair, épuré et professionnel"),
    Triple("midnight", "Midnight – Noir & Violet", "Sombre, confortable le soir"),
    Triple("pastel", "Pastel – Douceur & Couleurs", "Tons doux et chaleureux"),
    Triple("glass", "Glass – Moderne & Translucide", "Bleu et violet contemporains"),
    Triple("nature", "Nature – Vert & Sable", "Vert sauge et tons naturels")
)

private fun appThemePalette(id: String): AppThemePalette = when (id) {
    "midnight" -> AppThemePalette(Color(0xFFB99AFF), Color(0xFF24143D), Color(0xFF49336A), Color(0xFFE9DDFF), Color(0xFFCFB7FF), Color(0xFF12121A), Color(0xFF1D1C28), Color(0xFFF0EDF7), Color(0xFF302D3C), Color(0xFFC5BED2), true)
    "pastel" -> AppThemePalette(Color(0xFF8876C7), Color.White, Color(0xFFE9E1FA), Color(0xFF40345F), Color(0xFF70A99A), Color(0xFFFFFAF5), Color(0xFFFFFEFC), Color(0xFF40394A), Color(0xFFF4EAF1), Color(0xFF756B7B))
    "glass" -> AppThemePalette(Color(0xFF356BD6), Color.White, Color(0xFFDCE9FF), Color(0xFF19396F), Color(0xFF7856D8), Color(0xFFF1F5FF), Color(0xFFFFFFFF), Color(0xFF1D2B45), Color(0xFFE4EBF8), Color(0xFF5D6B83))
    "nature" -> AppThemePalette(Color(0xFF477B5A), Color.White, Color(0xFFDDEBDD), Color(0xFF23452E), Color(0xFF91A987), Color(0xFFF7F6EF), Color(0xFFFFFEF8), Color(0xFF29372B), Color(0xFFEAEBDD), Color(0xFF687360))
    else -> AppThemePalette(Color(0xFF245A9B), Color.White, Color(0xFFDCEBFA), Color(0xFF173A63), Color(0xFF4E83B9), Color(0xFFF5F8FC), Color.White, Color(0xFF202B39), Color(0xFFE8EFF7), Color(0xFF637184))
}

private fun dayStart(time: Long): Calendar = Calendar.getInstance().apply {
    timeInMillis = time
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}
private fun sameDay(a: Long, b: Long): Boolean {
    val x = dayStart(a); val y = dayStart(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}
private fun shiftDate(time: Long, view: String, amount: Int): Long = Calendar.getInstance().apply {
    timeInMillis = time
    add(when(view) { "Jour" -> Calendar.DAY_OF_MONTH; "Semaine", "Papier" -> Calendar.WEEK_OF_YEAR; else -> Calendar.MONTH }, amount)
}.timeInMillis

@Composable
private fun CalendarNavigator(view: String, selected: Long, onPrevious: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    val title = when(view) {
        "Jour" -> SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date(selected))
        "Semaine", "Papier" -> {
            val c = dayStart(selected); c.firstDayOfWeek = Calendar.MONDAY; c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            val first = c.timeInMillis; c.add(Calendar.DAY_OF_MONTH, 6)
            SimpleDateFormat("d MMM", Locale.FRANCE).format(Date(first)) + " – " + SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(c.time)
        }
        else -> SimpleDateFormat("MMMM yyyy", Locale.FRANCE).format(Date(selected))
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(onClick = onPrevious, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(38.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronLeft, "Période précédente", tint = MaterialTheme.colorScheme.onSurface) }
        }
        Spacer(Modifier.width(8.dp))
        Text(title.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface,
            fontSize = 20.sp, maxLines = 1, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Spacer(Modifier.width(6.dp))
        TextButton(onClick = onToday, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 3.dp)) {
            Text("Aujourd'hui", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Surface(onClick = onNext, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(38.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronRight, "Période suivante", tint = MaterialTheme.colorScheme.onSurface) }
        }
    }
}

private data class PhotoEventCandidate(
    val title: String,
    val dateTimeText: String,
    val endDateTimeText: String = "",
    val selected: Boolean = true
)

private fun parseDictatedAgendaText(text: String, referenceDay: Long): List<PhotoEventCandidate> {
    val normalized = text.lowercase(Locale.FRANCE).replace('’', '\'').trim()
    if (normalized.isBlank()) return emptyList()
    val calendar = Calendar.getInstance().apply {
        timeInMillis = referenceDay
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val weekdays = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
    val weekday = weekdays.firstOrNull { Regex("\\b$it\\b").containsMatchIn(normalized) }
    if (weekday != null) {
        val target = weekdays.indexOf(weekday)
        val today = (calendar.get(Calendar.DAY_OF_WEEK) + 5) % 7
        var delta = target - today
        if (normalized.contains("prochain") || normalized.contains("semaine prochaine")) { if (delta <= 0) delta += 7 }
        else if (delta < 0) delta += 7
        calendar.add(Calendar.DAY_OF_MONTH, delta)
    } else if (normalized.contains("demain")) calendar.add(Calendar.DAY_OF_MONTH, 1)
    else if (normalized.contains("après-demain") || normalized.contains("apres-demain")) calendar.add(Calendar.DAY_OF_MONTH, 2)

    val months = mapOf("janvier" to 1, "février" to 2, "fevrier" to 2, "mars" to 3, "avril" to 4, "mai" to 5, "juin" to 6, "juillet" to 7, "août" to 8, "aout" to 8, "septembre" to 9, "octobre" to 10, "novembre" to 11, "décembre" to 12, "decembre" to 12)
    val dateMatch = Regex("\\b([0-3]?\\d)\\s+(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)(?:\\s+(20\\d{2}))?").find(normalized)
    if (dateMatch != null) {
        val day = dateMatch.groupValues[1].toIntOrNull() ?: return emptyList()
        val month = months[dateMatch.groupValues[2]] ?: return emptyList()
        var year = dateMatch.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
        val candidate = Calendar.getInstance().apply { clear(); set(year, month - 1, day, 0, 0, 0) }
        if (dateMatch.groupValues[3].isBlank() && candidate.timeInMillis < referenceDay - 24L * 60 * 60 * 1000) year++
        calendar.set(year, month - 1, day)
        if (calendar.get(Calendar.MONTH) != month - 1 || calendar.get(Calendar.DAY_OF_MONTH) != day) return emptyList()
    }

    // Reconnaître les plages horaires en français :
    // « entre 15 et 16h », « de 15h à 16h », « 15h30-16h30 ».
    val rangeMatch = Regex(
        "\\b(?:entre\\s+|de\\s*)?([01]?\\d|2[0-3])(?:\\s*h\\s*([0-5]\\d)?)?\\s*(?:et|à|a|jusqu['’]?\\s*à|-)\\s*([01]?\\d|2[0-3])(?:\\s*h\\s*([0-5]\\d)?)?\\b"
    ).find(normalized)
    val timeToken = Regex("\\b(midi|minuit)\\b").find(normalized)
    val numericTime = if (rangeMatch == null) {
        Regex("\\b(?:à|a)\\s*([01]?\\d|2[0-3])(?:\\s*h\\s*([0-5]\\d)?)?\\b").find(normalized)
            ?: Regex("\\b([01]?\\d|2[0-3])\\s*h\\s*([0-5]\\d)?\\b").find(normalized)
    } else null

    val hour: Int
    val minute: Int
    when {
        rangeMatch != null -> {
            hour = rangeMatch.groupValues[1].toInt()
            minute = rangeMatch.groupValues[2].toIntOrNull() ?: 0
        }
        timeToken?.value == "midi" -> { hour = 12; minute = 0 }
        timeToken?.value == "minuit" -> { hour = 0; minute = 0 }
        numericTime != null -> {
            hour = numericTime.groupValues[1].toIntOrNull() ?: return emptyList()
            minute = numericTime.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        }
        else -> return emptyList()
    }

    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, minute)
    val startText = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(calendar.time)
    val endText = if (rangeMatch != null) {
        val endCalendar = calendar.clone() as Calendar
        endCalendar.set(Calendar.HOUR_OF_DAY, rangeMatch.groupValues[3].toInt())
        endCalendar.set(Calendar.MINUTE, rangeMatch.groupValues[4].toIntOrNull() ?: 0)
        if (endCalendar.timeInMillis <= calendar.timeInMillis) endCalendar.add(Calendar.DAY_OF_MONTH, 1)
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(endCalendar.time)
    } else ""

    // Nettoyage effectué sur le texte d'origine normalisé, sans séparer les lettres.
    var title = normalized
        .replace(dateMatch?.value ?: "", " ")
        .replace(rangeMatch?.value ?: "", " ")
        .replace(timeToken?.value ?: numericTime?.value.orEmpty(), " ")
        .replace(Regex("\\b(aujourd'hui|demain|après-demain|apres-demain|prochain|semaine prochaine)\\b"), " ")
        .replace(Regex("\\b(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\\b"), " ")
        .replace(Regex("\\b(le|pour|rendez-vous|rdv|de|entre)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', ',', '.', '-', ':')
    if (title.isBlank()) return emptyList()
    return listOf(PhotoEventCandidate(title.trim().replaceFirstChar { it.uppercase(Locale.FRANCE) }, startText, endText))
}

private fun parseVoiceDate(value: String, referenceDay: Long): Long? {
    val normalized = value.lowercase(Locale.FRANCE).replace('’', '\'').trim()
    val months = mapOf("janvier" to 1, "février" to 2, "fevrier" to 2, "mars" to 3, "avril" to 4, "mai" to 5, "juin" to 6, "juillet" to 7, "août" to 8, "aout" to 8, "septembre" to 9, "octobre" to 10, "novembre" to 11, "décembre" to 12, "decembre" to 12)
    val match = Regex("\\b([0-3]?\\d)\\s+(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)(?:\\s+(20\\d{2}))?").find(normalized)
    if (match != null) {
        val day = match.groupValues[1].toIntOrNull() ?: return null
        val month = months[match.groupValues[2]] ?: return null
        var year = match.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
        val cal = Calendar.getInstance().apply { clear(); set(year, month - 1, day, 9, 0, 0) }
        if (cal.get(Calendar.MONTH) != month - 1 || cal.get(Calendar.DAY_OF_MONTH) != day) return null
        if (match.groupValues[3].isBlank() && cal.timeInMillis < referenceDay - 86_400_000L) { year++; cal.set(Calendar.YEAR, year) }
        return cal.timeInMillis
    }
    if (normalized.contains("aujourd'hui") || normalized == "aujourd'hui") return Calendar.getInstance().apply { timeInMillis = referenceDay; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    if (normalized.contains("demain")) return Calendar.getInstance().apply { timeInMillis = referenceDay; add(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val weekdayNames = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
    weekdayNames.firstOrNull { normalized.contains(it) }?.let { dayName ->
        val cal = Calendar.getInstance().apply { timeInMillis = referenceDay; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val target = weekdayNames.indexOf(dayName) + 2
        var delta = target - cal.get(Calendar.DAY_OF_WEEK)
        if (delta <= 0 || normalized.contains("prochain")) { if (delta <= 0) delta += 7 }
        cal.add(Calendar.DAY_OF_MONTH, delta)
        return cal.timeInMillis
    }
    val numeric = Regex("\\b([0-3]?\\d)[/.-]([01]?\\d)(?:[/.-](20\\d{2}))?\\b").find(normalized) ?: return null
    val day = numeric.groupValues[1].toInt(); val month = numeric.groupValues[2].toInt(); val year = numeric.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
    return runCatching { Calendar.getInstance().apply { clear(); set(year, month - 1, day, 9, 0, 0); if (get(Calendar.MONTH) != month - 1 || get(Calendar.DAY_OF_MONTH) != day) throw IllegalArgumentException() }.timeInMillis }.getOrNull()
}

private fun parseVoiceTime(value: String): Pair<Int, Int>? {
    val n = value.lowercase(Locale.FRANCE).replace("heures", "h").replace("heure", "h").replace(" et ", " ").trim()
    if (n.contains("midi")) return 12 to 0
    if (n.contains("minuit")) return 0 to 0
    val m = Regex("\\b([01]?\\d|2[0-3])\\s*(?:h|:| )\\s*([0-5]\\d)?\\b").find(n) ?: Regex("\\b([01]?\\d|2[0-3])\\b").find(n) ?: return null
    val h = m.groupValues[1].toIntOrNull() ?: return null; val min = m.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
    return if (h in 0..23 && min in 0..59) h to min else null
}

private fun parseVoiceDuration(value: String): Int? {
    val n = value.lowercase(Locale.FRANCE).trim()
    val h = Regex("(\\d+)\\s*(?:h|heure|heures)").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: if (n.contains("une heure") || n.contains("1 heure")) 1 else 0
    val m = Regex("(\\d+)\\s*(?:min|minute|minutes)").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    val words = mapOf("demi-heure" to 30, "une demi-heure" to 30, "une heure" to 60, "deux heures" to 120, "trois heures" to 180, "quart d'heure" to 15)
    val total = if (h == 0 && m == 0) words.entries.firstOrNull { n.contains(it.key) }?.value ?: return null else h * 60 + m
    return total.takeIf { it in 5..1440 }
}

private fun parsePhotoDateTime(value: String): Long? = runCatching {
    val formatter = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).apply { isLenient = false }
    formatter.parse(value.trim())?.time
}.getOrNull()

private fun sameCalendarHour(first: Long, second: Long): Boolean {
    val a = Calendar.getInstance().apply { timeInMillis = first }
    val b = Calendar.getInstance().apply { timeInMillis = second }
    return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR) &&
        a.get(Calendar.HOUR_OF_DAY) == b.get(Calendar.HOUR_OF_DAY)
}

private fun photoDuplicateKey(title: String, time: Long): String {
    val cal = Calendar.getInstance().apply { timeInMillis = time }
    return title.trim().lowercase(Locale.FRANCE).replace(Regex("\\s+"), " ") + "|" +
        cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.DAY_OF_YEAR) + "-" + cal.get(Calendar.HOUR_OF_DAY) + "-" + cal.get(Calendar.MINUTE)
}

private fun parsePhotoAgendaText(text: String, referenceDay: Long): List<PhotoEventCandidate> {
    val lines = text.lines().map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }
    val weekdayNames = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
    val timeRegex = Regex("(?<!\\d)([01]?\\d|2[0-3])\\s*[hH:]\\s*([0-5]\\d)?(?!\\d)")
    val dateRegex = Regex("(?<!\\d)([0-3]?\\d)[/.\\-]([01]?\\d)(?:[/.\\-](20\\d{2}))?(?!\\d)")
    val base = Calendar.getInstance().apply { timeInMillis = referenceDay; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val mondayOffset = (base.get(Calendar.DAY_OF_WEEK) + 5) % 7
    base.add(Calendar.DAY_OF_MONTH, -mondayOffset)
    var activeDay: Calendar? = null
    val output = mutableListOf<PhotoEventCandidate>()
    lines.forEach { line ->
        val lower = line.lowercase(Locale.FRANCE)
        val weekdayIndex = weekdayNames.indexOfFirst { lower.startsWith(it) || lower.contains(" $it ") || lower == it }
        val dateMatch = dateRegex.find(line)
        if (weekdayIndex >= 0) activeDay = (base.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, weekdayIndex) }
        if (dateMatch != null) {
            val day = dateMatch.groupValues[1].toIntOrNull()
            val month = dateMatch.groupValues[2].toIntOrNull()
            val year = dateMatch.groupValues[3].toIntOrNull() ?: base.get(Calendar.YEAR)
            if (day != null && month != null) activeDay = Calendar.getInstance().apply {
                isLenient = false
                set(year, month - 1, day, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }.takeIf { runCatching { it.time }.isSuccess }
        }
        val timeMatch = timeRegex.find(line) ?: return@forEach
        val hour = timeMatch.groupValues[1].toIntOrNull() ?: return@forEach
        val minute = timeMatch.groupValues[2].takeIf { it.isNotBlank() }?.toIntOrNull() ?: 0
        val dayCal = (activeDay ?: (base.clone() as Calendar)).clone() as Calendar
        dayCal.set(Calendar.HOUR_OF_DAY, hour); dayCal.set(Calendar.MINUTE, minute)
        val title = line.removeRange(timeMatch.range).replace(dateRegex, " ").replace(Regex("(?i)lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche"), " ").trim(' ', '-', ':', '·', '|')
        if (title.isNotBlank()) output.add(PhotoEventCandidate(title, SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(dayCal.time)))
    }
    return output.distinctBy { it.title.lowercase(Locale.FRANCE) + it.dateTimeText }
}

@Composable
private fun DayAgenda(selected: Long, events: List<AgendaEvent>, nowMillis: Long, onEditEvent: (AgendaEvent) -> Unit, onAddAtTime: (Long) -> Unit, onDeleteEvent: (AgendaEvent) -> Unit, expanded: Boolean, modifier: Modifier = Modifier) {
    val dayEvents = events.filter { sameDay(it.timeMillis, selected) }.sortedBy { it.timeMillis }
    val context = LocalContext.current
    var attachmentTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var eventPendingDeletion by remember { mutableStateOf<AgendaEvent?>(null) }
    val density = LocalDensity.current.density
    val scrollState = rememberScrollState()
    // Échelle compacte : 36 dp par tranche de 30 minutes (72 dp/heure).
    // Les événements utilisent exactement cette même échelle, à la minute près.
    val rowHeight = 36.dp
    val minuteHeight = 1.2f
    Column(
        modifier.fillMaxWidth()
            .padding(bottom = 6.dp)
    ) {
        Text("Planning horaire · précision 30 min", style = MaterialTheme.typography.labelLarge)
        BoxWithConstraints(
            Modifier.fillMaxWidth()
                .weight(1f)
                .verticalScroll(scrollState)
        ) {
            // Capturer la largeur depuis BoxWithConstraints avant les lambdas imbriquées.
            val timelineWidth = this.maxWidth
            // Par défaut, afficher 07:00–22:00. Étendre à la journée complète
            // uniquement si un événement touche la plage nocturne (00:00–07:00
            // ou 22:00–23:59), en tenant compte de son heure de fin.
            // Les deux extensions nocturnes sont indépendantes : un événement
            // tôt le matin n'ouvre pas la plage du soir, et inversement.
            val hasEarlyEvent = dayEvents.any { event ->
                val startCal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val startMinute = startCal.get(Calendar.HOUR_OF_DAY) * 60 + startCal.get(Calendar.MINUTE)
                val endMillis = event.endTimeMillis?.takeIf { it > event.timeMillis }
                val endMinute = endMillis?.let {
                    val endCal = Calendar.getInstance().apply { timeInMillis = it }
                    endCal.get(Calendar.HOUR_OF_DAY) * 60 + endCal.get(Calendar.MINUTE)
                } ?: startMinute
                startMinute < 7 * 60 || (endMillis != null && startMinute < 7 * 60 && endMinute > 0)
            }
            val hasLateEvent = dayEvents.any { event ->
                val startCal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val startMinute = startCal.get(Calendar.HOUR_OF_DAY) * 60 + startCal.get(Calendar.MINUTE)
                val endMillis = event.endTimeMillis?.takeIf { it > event.timeMillis }
                val endMinute = endMillis?.let {
                    val endCal = Calendar.getInstance().apply { timeInMillis = it }
                    endCal.get(Calendar.HOUR_OF_DAY) * 60 + endCal.get(Calendar.MINUTE)
                } ?: startMinute
                startMinute >= 22 * 60 || (endMillis != null && endMinute > 22 * 60)
            }
            val visibleStartHour = if (hasEarlyEvent) 0 else 7
            val visibleEndHour = if (hasLateEvent) 24 else 22
            // Graduation toutes les 30 minutes ; la position des événements
            // reste calculée à la minute près sur la même échelle verticale.
            val firstHalfHour = visibleStartHour * 2
            val halfHourCount = (visibleEndHour - visibleStartHour) * 2
            val timelineHeight = rowHeight * halfHourCount
            // Grille et événements partagent la même origine temporelle.
            Box(
                Modifier.fillMaxWidth().height(timelineHeight)
                    .pointerInput(selected, visibleStartHour, visibleEndHour) {
                        detectTapGestures(onDoubleTap = { offset ->
                            val rawMinutes = visibleStartHour * 60 + (offset.y / density / minuteHeight).toInt()
                            val snappedMinutes = ((rawMinutes.coerceIn(0, 1439) + 2) / 5) * 5
                            val day = Calendar.getInstance().apply { timeInMillis = selected }
                            day.set(Calendar.HOUR_OF_DAY, (snappedMinutes / 60).coerceAtMost(23))
                            day.set(Calendar.MINUTE, snappedMinutes % 60)
                            day.set(Calendar.SECOND, 0)
                            day.set(Calendar.MILLISECOND, 0)
                            onAddAtTime(day.timeInMillis)
                        })
                    }
            ) {
                Column(Modifier.fillMaxWidth()) {
                    repeat(halfHourCount) { index ->
                        val halfHour = firstHalfHour + index
                        val hour = halfHour / 2
                        val minute = (halfHour % 2) * 30
                        // Chaque graduation est placée au début exact de son intervalle
                        // de 30 minutes ; les événements gardent leur placement à la minute.
                        Box(Modifier.fillMaxWidth().height(rowHeight)) {
                            Text(
                                String.format(Locale.FRANCE, "%02d:%02d", hour, minute),
                                modifier = Modifier.width(52.dp).align(Alignment.TopStart),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelSmall
                            )
                            HorizontalDivider(
                                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                        }
                    }
                }
                // Curseur de l'heure actuelle, uniquement sur la journée d'aujourd'hui.
                if (sameDay(selected, nowMillis)) {
                    val nowCal = Calendar.getInstance().apply { timeInMillis = nowMillis }
                    val nowMinutes = nowCal.get(Calendar.HOUR_OF_DAY) * 60 + nowCal.get(Calendar.MINUTE)
                    val cursorY = ((nowMinutes - visibleStartHour * 60).coerceAtLeast(0) * minuteHeight).dp
                    if (nowMinutes in (visibleStartHour * 60)..(visibleEndHour * 60)) {
                        Row(
                            Modifier.offset(y = cursorY - 1.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(9.dp).background(MaterialTheme.colorScheme.error, RoundedCornerShape(50)))
                            Box(Modifier.weight(1f).height(2.dp).background(MaterialTheme.colorScheme.error))
                        }
                    }
                }
                dayEvents.forEach { event ->
                    val cal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                    val startMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                    val end = event.endTimeMillis?.takeIf { it > event.timeMillis }
                    val durationMinutes = end?.let { ((it - event.timeMillis) / 60000L).toInt() } ?: 12
                    val y = ((startMinutes - visibleStartHour * 60).coerceAtLeast(0) * minuteHeight).dp
                    val h = (durationMinutes * minuteHeight).coerceAtLeast(34f).dp
                    val startLabel = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
                    val endLabel = end?.let { SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(it)) }
                    Surface(
                        modifier = Modifier
                            .offset(x = 56.dp, y = y)
                            .width((timelineWidth - 60.dp).coerceAtLeast(80.dp))
                            .height(h)
                            .pointerInput(event.id, y, visibleStartHour) {
                                detectTapGestures(
                                    onPress = {
                                        val released = withTimeoutOrNull(3_000L) { tryAwaitRelease() }
                                        if (released == null) eventPendingDeletion = event
                                    },
                                    onTap = { onEditEvent(event) },
                                    onDoubleTap = { tapOffset ->
                                        val absoluteY = y.value * density + tapOffset.y
                                        val rawMinutes = visibleStartHour * 60 + (absoluteY / (density * minuteHeight)).toInt()
                                        val snappedMinutes = ((rawMinutes.coerceIn(0, 1439) + 2) / 5) * 5
                                        val day = Calendar.getInstance().apply { timeInMillis = selected }
                                        day.set(Calendar.HOUR_OF_DAY, (snappedMinutes / 60).coerceAtMost(23))
                                        day.set(Calendar.MINUTE, snappedMinutes % 60)
                                        day.set(Calendar.SECOND, 0)
                                        day.set(Calendar.MILLISECOND, 0)
                                        onAddAtTime(day.timeInMillis)
                                    }
                                )
                            },
                        shape = RoundedCornerShape(7.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 2.dp),
                            verticalArrangement = Arrangement.spacedBy(1.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "$startLabel  ${event.title}",
                                    modifier = Modifier.weight(1f),
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (event.attachments.isNotEmpty()) {
                                    Icon(
                                        Icons.Default.AttachFile,
                                        contentDescription = "Ouvrir les pièces jointes",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(19.dp).clickable { attachmentTarget = event }
                                    )
                                }
                                if (event.reminderMode == "alarm") {
                                    Icon(Icons.Default.Alarm, contentDescription = "Alarme programmée",
                                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 5.dp).size(18.dp))
                                } else if (event.reminderMode == "notification") {
                                    Icon(Icons.Default.Notifications, contentDescription = "Notification programmée",
                                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 5.dp).size(18.dp))
                                }
                            }
                            if (end != null) {
                                Text(
                                    "$startLabel – $endLabel  ·  ${durationMinutes / 60} h ${durationMinutes % 60} min",
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    attachmentTarget?.let { event ->
        AlertDialog(
            onDismissRequest = { attachmentTarget = null },
            title = { Text("Pièces jointes") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    event.attachments.forEach { attachment ->
                        TextButton(onClick = {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(attachment.uri), attachment.mimeType.ifBlank { "*/*" })
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            runCatching { context.startActivity(intent) }
                            attachmentTarget = null
                        }) {
                            Icon(Icons.Default.InsertDriveFile, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(attachment.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { attachmentTarget = null }) { Text("Fermer") } }
        )
    }
    eventPendingDeletion?.let { event ->
        AlertDialog(
            onDismissRequest = { eventPendingDeletion = null },
            title = { Text("Supprimer l’événement ?") },
            text = { Text("Voulez-vous vraiment supprimer « ${event.title} » ?") },
            confirmButton = {
                TextButton(onClick = { onDeleteEvent(event); eventPendingDeletion = null }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { eventPendingDeletion = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun WeekAgenda(
    selected: Long,
    events: List<AgendaEvent>,
    onSelectDay: (Long) -> Unit,
    onEditEvent: (AgendaEvent) -> Unit,
    onAddAtTime: (Long) -> Unit,
    onDeleteEvent: (AgendaEvent) -> Unit,
    showWeekend: Boolean,
    onToggleWeekend: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var eventPendingDeletion by remember { mutableStateOf<AgendaEvent?>(null) }
    var attachmentTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    val context = LocalContext.current
    val weekStart = dayStart(selected).apply {
        firstDayOfWeek = Calendar.MONDAY
        minimalDaysInFirstWeek = 4
        set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    }
    val days = (0 until if (showWeekend) 7 else 5).map { index ->
        Calendar.getInstance().apply { timeInMillis = weekStart.timeInMillis; add(Calendar.DAY_OF_MONTH, index) }
    }
    val weekEvents = events.filter { event -> days.any { sameDay(event.timeMillis, it.timeInMillis) } }
    val hasEarly = weekEvents.any { event ->
        val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
        c.get(Calendar.HOUR_OF_DAY) < 7
    }
    val hasLate = weekEvents.any { event ->
        val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
        c.get(Calendar.HOUR_OF_DAY) >= 22 || event.endTimeMillis?.let { end ->
            val ec = Calendar.getInstance().apply { timeInMillis = end }
            ec.get(Calendar.HOUR_OF_DAY) >= 22
        } == true
    }
    val firstHour = if (hasEarly) 0 else 7
    val lastHour = if (hasLate) 24 else 22
    val minuteHeight = 1.2f
    val density = LocalDensity.current.density
    val rowHeight = 36.dp
    val labelWidth = 43.dp
    val timelineHeight = ((lastHour - firstHour) * 60 * minuteHeight).dp
    Column(modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Planning hebdomadaire", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
            Text("Week-end", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(5.dp))
            Switch(checked = showWeekend, onCheckedChange = onToggleWeekend)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
            // Numéro ISO de la semaine dans la marge horaire, aligné sur les cases des jours.
            Surface(
                modifier = Modifier.width(labelWidth),
                shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Column(Modifier.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SEM.", fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(String.format(Locale.FRANCE, "%02d", weekStart.get(Calendar.WEEK_OF_YEAR)),
                        fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                }
            }
            days.forEach { day ->
                val isSelected = sameDay(day.timeInMillis, selected)
                Surface(
                    modifier = Modifier.weight(1f).clickable { onSelectDay(day.timeInMillis) },
                    shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                ) {
                    // En-tête compact : plus de place pour la grille hebdomadaire.
                    Column(Modifier.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(SimpleDateFormat("EEE", Locale.FRANCE).format(day.time).replaceFirstChar { it.uppercase() },
                            fontSize = 9.sp, lineHeight = 10.sp, fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(day.get(Calendar.DAY_OF_MONTH).toString(), fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
            val columnWidth = ((maxWidth - labelWidth - 2.dp * (days.size - 1).toFloat()) / days.size.toFloat()).coerceAtLeast(1.dp)
            Box(Modifier.fillMaxWidth().height(timelineHeight).pointerInput(selected, firstHour, lastHour, showWeekend) {
                detectTapGestures(onDoubleTap = { offset ->
                    val xDp = offset.x / density
                    val colW = (size.width / density - labelWidth.value - 2f * (days.size - 1)) / days.size
                    val index = (((xDp - labelWidth.value) / (colW + 2f)).toInt()).coerceIn(0, days.lastIndex)
                    val minutes = (firstHour * 60 + (offset.y / density / minuteHeight).toInt()).coerceIn(0, 1439)
                    val snapped = ((minutes + 2) / 5) * 5
                    val target = (days[index].clone() as Calendar).apply {
                        set(Calendar.HOUR_OF_DAY, (snapped / 60).coerceAtMost(23)); set(Calendar.MINUTE, snapped % 60)
                        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    }
                    onAddAtTime(target.timeInMillis)
                })
            }) {
                Row(Modifier.fillMaxWidth()) {
                    Column(Modifier.width(labelWidth)) {
                        repeat(lastHour - firstHour) { index ->
                            Box(Modifier.height(rowHeight).fillMaxWidth()) {
                                Text(String.format(Locale.FRANCE, "%02d:00", firstHour + index),
                                    fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.align(Alignment.TopStart))
                            }
                            Box(Modifier.height(rowHeight).fillMaxWidth()) {
                                Text(String.format(Locale.FRANCE, "%02d:30", firstHour + index),
                                    fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.align(Alignment.TopStart))
                            }
                        }
                    }
                    days.forEach { day ->
                        Box(Modifier.width(columnWidth).height(timelineHeight)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.22f))) {
                            Column(Modifier.fillMaxWidth()) {
                                repeat((lastHour - firstHour) * 2) {
                                    Box(Modifier.fillMaxWidth().height(rowHeight)) {
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.75f))
                                    }
                                }
                            }
                            weekEvents.filter { sameDay(it.timeMillis, day.timeInMillis) }.forEach { event ->
                                val cal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                                val startMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                                val end = event.endTimeMillis?.takeIf { it > event.timeMillis }
                                val duration = end?.let { ((it - event.timeMillis) / 60000L).toInt() } ?: 30
                                val y = ((startMinutes - firstHour * 60).coerceAtLeast(0) * minuteHeight).dp
                                val h = (duration * minuteHeight).coerceAtLeast(28f).dp
                                Surface(
                                    modifier = Modifier.offset(y = y).fillMaxWidth().height(h)
                                        .padding(horizontal = 1.dp, vertical = 1.dp)
                                        .pointerInput(event.id, y, firstHour) {
                                            detectTapGestures(
                                                onPress = {
                                                    val released = withTimeoutOrNull(3_000L) { tryAwaitRelease() }
                                                    if (released == null) eventPendingDeletion = event
                                                },
                                                onTap = { onEditEvent(event) },
                                                onDoubleTap = { tap ->
                                                    val absoluteY = y.value * density + tap.y
                                                    val minutes = (firstHour * 60 + (absoluteY / (density * minuteHeight)).toInt()).coerceIn(0, 1439)
                                                    val snapped = ((minutes + 2) / 5) * 5
                                                    val target = (day.clone() as Calendar).apply {
                                                        set(Calendar.HOUR_OF_DAY, (snapped / 60).coerceAtMost(23)); set(Calendar.MINUTE, snapped % 60)
                                                        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                                                    }
                                                    onAddAtTime(target.timeInMillis)
                                                }
                                            )
                                        },
                                    shape = RoundedCornerShape(5.dp),
                                    color = when (event.reminderMode.lowercase()) {
                                        "alarm" -> Color(0xFFFFDAD6)
                                        "both" -> Color(0xFFE6D9F5)
                                        "notification" -> Color(0xFFD7E8FF)
                                        else -> MaterialTheme.colorScheme.secondaryContainer
                                    }
                                ) {
                                    Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 1.dp), verticalArrangement = Arrangement.Top) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(event.title, modifier = Modifier.weight(1f), fontSize = 10.sp, lineHeight = 11.sp,
                                                color = when (event.reminderMode.lowercase()) { "alarm" -> Color(0xFF8B1A13); "both" -> Color(0xFF49306D); "notification" -> Color(0xFF173B68); else -> MaterialTheme.colorScheme.onSecondaryContainer },
                                                maxLines = 4, overflow = TextOverflow.Ellipsis)
                                            if (event.attachments.isNotEmpty()) {
                                                Icon(Icons.Default.AttachFile, contentDescription = "Ouvrir les pièces jointes",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(14.dp).clickable { attachmentTarget = event })
                                            }
                                        }
                                        Text(SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(event.timeMillis)),
                                            fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.Bold,
                                            color = when (event.reminderMode.lowercase()) { "alarm" -> Color(0xFF8B1A13); "both" -> Color(0xFF49306D); "notification" -> Color(0xFF173B68); else -> MaterialTheme.colorScheme.onSecondaryContainer }, maxLines = 1)
                                    }
                                }
                            }
                        }
                        if (day != days.last()) Spacer(Modifier.width(2.dp))
                    }
                }
            }
        }
    }
    eventPendingDeletion?.let { event ->
        AlertDialog(
            onDismissRequest = { eventPendingDeletion = null },
            title = { Text("Supprimer l’événement ?") },
            text = { Text("Voulez-vous vraiment supprimer « ${event.title} » ?") },
            confirmButton = {
                TextButton(onClick = { onDeleteEvent(event); eventPendingDeletion = null }) { Text("Supprimer") }
            },
            dismissButton = {
                TextButton(onClick = { eventPendingDeletion = null }) { Text("Annuler") }
            }
        )
    }
    attachmentTarget?.let { event ->
        AlertDialog(
            onDismissRequest = { attachmentTarget = null },
            title = { Text("Pièces jointes") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    event.attachments.forEach { attachment ->
                        TextButton(onClick = {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(attachment.uri), attachment.mimeType.ifBlank { "*/*" })
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            runCatching { context.startActivity(intent) }
                            attachmentTarget = null
                        }) {
                            Icon(Icons.Default.InsertDriveFile, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(attachment.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { attachmentTarget = null }) { Text("Fermer") } }
        )
    }
}

@Composable
private fun WeeklyPaperAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, onEditEvent: (AgendaEvent) -> Unit, fullScreen: Boolean = false, modifier: Modifier = Modifier) {
    val weekStart = Calendar.getInstance().apply {
        timeInMillis = dayStart(selected).timeInMillis
        firstDayOfWeek = Calendar.MONDAY
        minimalDaysInFirstWeek = 4
        set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    }
    val days = (0..6).map { offset -> Calendar.getInstance().apply { timeInMillis = weekStart.timeInMillis; add(Calendar.DAY_OF_MONTH, offset) } }
    BoxWithConstraints(modifier.fillMaxWidth().then(if (fullScreen) Modifier.fillMaxHeight() else Modifier.heightIn(max = 560.dp))) {
        val columnWidth = if (fullScreen || maxWidth >= 700.dp) (maxWidth - 68.dp) / 7 else 116.dp
        val paper = Color.Transparent
        val ink = Color(0xFF142B45)
        val grid = Color(0xFF71879B)
        // Pastels suffisamment soutenus pour rester visibles sur le papier clair.
        val eventPalette = listOf(Color(0xFF8FC5F2), Color(0xFFF2D477), Color(0xFFF0A0A8), Color(0xFFA6D99A), Color(0xFFC2AFE9), Color(0xFF91D8D4))
        // Échelle uniforme : chaque heure possède exactement la même hauteur.
        // Les événements seront positionnés à la minute près sur cette échelle.
        val hourHeight = 72.dp
        val hourHeights = (6..20).associateWith { hourHeight }
        val horizontalModifier = if (fullScreen) Modifier else Modifier.horizontalScroll(rememberScrollState())
        // Aspect véritable agenda papier : couverture cuir, page ivoire texturée et reliure centrale.
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF6B3824), Color(0xFF321A13))), RoundedCornerShape(16.dp)).border(2.dp, Color(0xFF8B5638), RoundedCornerShape(16.dp)).padding(10.dp)) {
            Image(
                painter = painterResource(id = R.drawable.paper_texture),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)).border(1.dp, Color(0xFFD8C5A5), RoundedCornerShape(10.dp))
            )
            Row(Modifier.fillMaxSize().then(horizontalModifier).verticalScroll(rememberScrollState()).padding(5.dp)) {
            Column(Modifier.width(48.dp)) {
                Box(Modifier.height(if (fullScreen) 26.dp else 30.dp).fillMaxWidth().background(Color(0x55FFF9EC)), contentAlignment = Alignment.Center) {
                    Text("Heure", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ink, fontFamily = FontFamily.Serif)
                }
                Column {
                    (6..20).forEach { hour ->
                        Box(Modifier.height(hourHeights.getValue(hour)).fillMaxWidth().background(Color(0x55FFF9EC)).border(0.5.dp, grid), contentAlignment = Alignment.TopCenter) {
                            Text(String.format(Locale.FRANCE, "%02d:00", hour), fontSize = if (fullScreen) 12.sp else 11.sp, fontWeight = FontWeight.SemiBold, color = ink, modifier = Modifier.padding(top = 3.dp))
                        }
                    }
                }
            }
            days.forEach { day ->
                val dayEvents = events.filter { sameDay(it.timeMillis, day.timeInMillis) }.sortedBy { it.timeMillis }
                Column(Modifier.width(columnWidth).background(paper).border(0.7.dp, grid)) {
                    Box(
                        Modifier.fillMaxWidth()
                            .height(if (fullScreen) 26.dp else 30.dp)
                            .background(if (sameDay(day.timeInMillis, selected)) Color(0x88DCE9F7) else Color(0x66FFF9EC))
                            .clickable { onSelectDay(day.timeInMillis) },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            val dayName = SimpleDateFormat("EEEE", Locale.FRANCE).format(day.time).replaceFirstChar { it.uppercase() }
                            val dayNumber = SimpleDateFormat("d MMM", Locale.FRANCE).format(day.time)
                            val dayColor = when (day.get(Calendar.DAY_OF_WEEK)) {
                                Calendar.SUNDAY -> Color(0xFFD94B50)
                                Calendar.SATURDAY -> Color(0xFF2878C8)
                                else -> ink
                            }
                            Text(dayName, fontSize = if (fullScreen) 12.sp else 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, color = dayColor, fontFamily = FontFamily.Serif)
                            Text(dayNumber, fontSize = if (fullScreen) 11.sp else 10.sp, fontWeight = FontWeight.SemiBold, color = dayColor, fontFamily = FontFamily.Serif)
                        }
                    }
                    Box(
                        Modifier.fillMaxWidth().height(hourHeight * 15)
                            .background(paper)
                    ) {
                        // Lignes horaires : une heure = 72 dp, identique à la colonne de gauche.
                        Column(Modifier.fillMaxSize()) {
                            (6..20).forEach { hour ->
                                Box(
                                    Modifier.fillMaxWidth().height(hourHeight)
                                        .background(Color.Transparent)
                                        .border(0.5.dp, grid.copy(alpha = 0.95f))
                                )
                            }
                        }
                        // Les blocs sont positionnés selon l'heure ET les minutes de début.
                        dayEvents.forEachIndexed { eventIndex, event ->
                            val startCal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                            val startHour = startCal.get(Calendar.HOUR_OF_DAY)
                            val startMinute = startCal.get(Calendar.MINUTE)
                            if (startHour in 6..20) {
                                val minutesFromTop = (startHour - 6) * 60 + startMinute
                                val yPosition = hourHeight * (minutesFromTop / 60f)
                                val durationMinutes = event.endTimeMillis
                                    ?.takeIf { it > event.timeMillis }
                                    ?.let { ((it - event.timeMillis) / 60000L).toInt() }
                                    ?: 0
                                val remainingMinutes = 15 * 60 - minutesFromTop
                                val visibleMinutes = if (durationMinutes > 0) minOf(durationMinutes, remainingMinutes) else 45
                                val eventHeight = if (durationMinutes > 0) {
                                    (hourHeight * (visibleMinutes / 60f)).coerceAtLeast(18.dp)
                                } else 52.dp
                                val eventColor = eventPalette[eventIndex.mod(eventPalette.size)]
                                Surface(
                                    onClick = { onEditEvent(event) },
                                    color = eventColor.copy(alpha = 0.97f),
                                    contentColor = Color(0xFF10243A),
                                    shape = RoundedCornerShape(5.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .offset(y = yPosition)
                                        .height(eventHeight)
                                        .padding(horizontal = 2.dp, vertical = 1.dp)
                                        .border(1.dp, Color(0xFF536B83), RoundedCornerShape(5.dp))
                                ) {
                                    Column(
                                        Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 2.dp),
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            event.title.ifBlank { "Événement" },
                                            fontSize = if (fullScreen) 11.sp else 10.sp,
                                            lineHeight = if (fullScreen) 12.sp else 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF10243A),
                                            fontFamily = FontFamily.Serif,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        val startLabel = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
                                        val endMillis = event.endTimeMillis?.takeIf { it > event.timeMillis }
                                        if (endMillis != null) {
                                            Text(
                                                "$startLabel – ${SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(endMillis))}",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF10243A),
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        } else {
                                            Text(startLabel, fontSize = 9.sp, color = Color(0xFF10243A), maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }
            // Reliure centrale avec anneaux métalliques, dans l'esprit du modèle validé.
            if (fullScreen) {
                val spineX = 48.dp + columnWidth * 3
                Box(Modifier.offset(x = spineX - 5.dp).fillMaxHeight().width(10.dp).background(Brush.horizontalGradient(listOf(Color(0x55301810), Color(0xCC6E4934), Color(0x55301810)))))
                Column(Modifier.offset(x = spineX - 9.dp).fillMaxHeight().padding(vertical = 34.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                    repeat(6) {
                        Box(Modifier.size(width = 18.dp, height = 8.dp).background(Brush.verticalGradient(listOf(Color(0xFFE6E0D4), Color(0xFF4B4A46), Color(0xFFD8D1C4))), RoundedCornerShape(5.dp)).border(0.7.dp, Color(0xFF51463B), RoundedCornerShape(5.dp)))
                    }
                }
            }
        }
    }
    if (!fullScreen) Text("Vue agenda papier · ouvrez le plein écran pour afficher les 7 jours simultanément.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
}

// Jours fériés légaux en France métropolitaine, calculés pour chaque année.
private fun isFrenchPublicHoliday(date: Calendar): Boolean {
    val year = date.get(Calendar.YEAR)
    val month = date.get(Calendar.MONTH) + 1
    val day = date.get(Calendar.DAY_OF_MONTH)
    val fixed = setOf("1-1", "5-1", "5-8", "7-14", "8-15", "11-1", "11-11", "12-25")
    if ("$month-$day" in fixed) return true
    val easter = easterSunday(year)
    val easterMonday = easter.plusDays(1)
    val ascension = easter.plusDays(39)
    val whitMonday = easter.plusDays(50)
    val current = java.time.LocalDate.of(year, month, day)
    return current == easterMonday || current == ascension || current == whitMonday
}

private fun easterSunday(year: Int): java.time.LocalDate {
    val a = year % 19
    val b = year / 100
    val c = year % 100
    val d = b / 4
    val e = b % 4
    val f = (b + 8) / 25
    val g = (b - f + 1) / 3
    val h = (19 * a + b - d - g + 15) % 30
    val i = c / 4
    val k = c % 4
    val l = (32 + 2 * e + 2 * i - h - k) % 7
    val m = (a + 11 * h + 22 * l) / 451
    val month = (h + l - 7 * m + 114) / 31
    val day = (h + l - 7 * m + 114) % 31 + 1
    return java.time.LocalDate.of(year, month, day)
}

@Composable
private fun MonthAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, expanded: Boolean) {
    val month = Calendar.getInstance().apply { timeInMillis = selected; set(Calendar.DAY_OF_MONTH, 1); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
    val offset = (month.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY + 7) % 7
    val days = (0 until offset).map { 0 } + (1..month.getActualMaximum(Calendar.DAY_OF_MONTH)).toList()
    val weeks = days.chunked(7)
    Card(Modifier.fillMaxWidth().padding(top = 1.dp, bottom = 3.dp), shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(5.dp)) {
        Column(Modifier.padding(horizontal = 5.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp)).padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Sem.", Modifier.width(48.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                listOf("L", "M", "M", "J", "V", "S", "D").forEachIndexed { i, label ->
                    Text(label, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold,
                        color = when(i) { 5 -> Color(0xFF1769D2); 6 -> Color(0xFFD52E2E); else -> MaterialTheme.colorScheme.onSurface })
                }
            }
            weeks.forEachIndexed { wi, week ->
                Row(Modifier.fillMaxWidth().height(if (expanded) 43.dp else 38.dp), verticalAlignment = Alignment.CenterVertically) {
                    val weekStart = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; add(Calendar.DAY_OF_MONTH, wi * 7 - offset); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
                    Box(Modifier.width(48.dp).fillMaxHeight().padding(vertical = 3.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text(weekStart.get(Calendar.WEEK_OF_YEAR).toString(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                    week.forEach { n ->
                        Box(Modifier.weight(1f).fillMaxHeight().padding(2.dp), contentAlignment = Alignment.Center) {
                            if (n > 0) {
                                val date = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; set(Calendar.DAY_OF_MONTH, n) }
                                val hasNotification = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "notification" }
                                val hasAlarm = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "alarm" }
                                val hasBoth = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "both" }
                                val selectedDate = sameDay(date.timeInMillis, selected)
                                val dayColor = when { isFrenchPublicHoliday(date) || date.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY -> Color(0xFFD52E35); date.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY -> Color(0xFF1769D2); else -> MaterialTheme.colorScheme.onSurface }
                                Surface(
                                    onClick = { onSelectDay(date.timeInMillis) },
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .then(if (selectedDate) Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp)) else Modifier),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Transparent
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = dayColor, fontWeight = if (selectedDate || isFrenchPublicHoliday(date)) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp, lineHeight = 16.sp)
                                        // Réserve toujours la même hauteur sous le numéro :
                                        // l'apparition des points ne déplace jamais le chiffre.
                                        Box(Modifier.height(10.dp), contentAlignment = Alignment.Center) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                                if (hasNotification) Text("•", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                                if (hasAlarm) Text("•", color = Color(0xFFD52E35), style = MaterialTheme.typography.labelSmall)
                                                if (hasBoth) Text("•", color = Color(0xFF8E44AD), style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                }
                if (wi < weeks.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.7.dp)
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(start = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("●", color = MaterialTheme.colorScheme.primary); Text(" Notification", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.width(18.dp)); Text("●", color = Color(0xFFD52E35)); Text(" Alarme", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.width(18.dp)); Text("●", color = Color(0xFF8E44AD)); Text(" Les deux", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun EventCard(event: AgendaEvent, onEdit: () -> Unit, onDelete: () -> Unit, onAlarm: () -> Unit) {
    val context = LocalContext.current
    val date = remember(event.timeMillis) {
        SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Box(Modifier.width(5.dp).height(142.dp).background(MaterialTheme.colorScheme.secondary))
            Row(Modifier.padding(horizontal = 11.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    val delayLabel = when {
                        event.reminderMode == "outlook" -> ""
                        event.leadMinutes <= 0 -> ""
                        event.leadMinutes < 60 -> " · dans ${event.leadMinutes} min"
                        event.leadMinutes % 1440 == 0 -> " · dans ${event.leadMinutes / 1440} j"
                        event.leadMinutes % 60 == 0 -> " · dans ${event.leadMinutes / 60} h"
                        else -> " · dans ${event.leadMinutes / 60} h ${event.leadMinutes % 60} min"
                    }
                    Text(event.title + delayLabel, fontSize = 17.sp, lineHeight = 20.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.width(6.dp))
                        Text(date.replaceFirstChar { it.uppercase() }, fontSize = 13.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    event.endTimeMillis?.let { end ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⏱", fontSize = 15.sp)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "${SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(event.timeMillis))} – ${SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(end))}",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (event.reminderMode == "alarm") Icons.Default.Alarm else Icons.Default.Notifications, null,
                            modifier = Modifier.size(19.dp), tint = when (event.reminderMode) { "alarm" -> Color(0xFFD52E35); "both" -> Color(0xFF8E44AD); else -> MaterialTheme.colorScheme.primary })
                        Spacer(Modifier.width(6.dp))
                        Text((when (event.reminderMode) {
                            "alarm" -> "Alarme Mon Agenda"
                            "both" -> "Notification + alarme"
                            "outlook" -> "Événement Outlook sans rappel"
                            else -> if (event.outlookEventId != null) "Rappel Outlook" else "Notification"
                        }) + if (event.reminderMode == "outlook") "" else " · ${event.leadMinutes} min avant",
                            fontSize = 13.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    if (event.attachments.isNotEmpty()) {
                        event.attachments.forEach { attachment ->
                            TextButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(Uri.parse(attachment.uri), attachment.mimeType)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    runCatching { context.startActivity(intent) }
                                },
                                contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)
                            ) {
                                Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(attachment.name, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (event.outlookEventId != null) {
                            OutlinedButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)) {
                                Text("Modifier", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                            }
                        } else {
                            OutlinedButton(onClick = onAlarm, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)) {
                                Text("Modifier", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                            }
                        }
                        OutlinedButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                            shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)) {
                            Text("Supprimer", fontSize = 12.sp, color = MaterialTheme.colorScheme.error, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OutlookReminderEditor(
    event: AgendaEvent,
    onDismiss: () -> Unit,
    onSave: (String, Int, Long, String?, Boolean) -> Unit
) {
    var notificationEnabled by remember(event.id) { mutableStateOf(event.reminderMode == "notification" || event.reminderMode == "both") }
    var alarmEnabled by remember(event.id) { mutableStateOf(event.reminderMode == "alarm" || event.reminderMode == "both" || event.reminderMode == "outlook") }
    var alarmTimeMillis by remember(event.id) {
        mutableLongStateOf(event.alarmTimeMillis ?: run {
            val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
            val eventMinute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val alarmMinute = (eventMinute - 15).coerceAtLeast(0)
            c.set(Calendar.HOUR_OF_DAY, alarmMinute / 60)
            c.set(Calendar.MINUTE, alarmMinute % 60)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.timeInMillis
        })
    }
    var error by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var soundUri by remember(event.id) { mutableStateOf(event.alarmSoundUri) }
    var vibrate by remember(event.id) { mutableStateOf(event.vibrate) }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }
    val alarmTimeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(alarmTimeMillis))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rappel de l’événement Outlook") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(event.title, fontWeight = FontWeight.SemiBold)
                Text(SimpleDateFormat("EEEE d MMMM 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis)))
                Text("Le jour du rendez-vous reste inchangé. Seule l’heure de l’alarme sera modifiée.", style = MaterialTheme.typography.bodySmall)
                Text("Type de rappel", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it })
                    Text("Alarme sonore")
                }
                if (!notificationEnabled && !alarmEnabled) Text("Sélectionne au moins un type de rappel.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("Heure de l’alarme", fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                    TimePickerDialog(
                        context,
                        { _, hour, minute ->
                            val selected = Calendar.getInstance().apply {
                                timeInMillis = event.timeMillis
                                set(Calendar.HOUR_OF_DAY, hour)
                                set(Calendar.MINUTE, minute)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                            alarmTimeMillis = selected.timeInMillis
                            error = false
                        },
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true
                    ).show()
                }) { Text("Choisir : $alarmTimeText") }
                Text("Sonnerie", fontWeight = FontWeight.SemiBold)
                Text(soundLabel, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                        }
                        ringtonePicker.launch(picker)
                    }) { Text("Choisir une sonnerie") }
                    TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Vibreur", modifier = Modifier.weight(1f))
                    Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                }
                if (error) Text("Choisis une heure future, le même jour que le rendez-vous.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val eventDay = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val alarmDay = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                val sameDay = eventDay.get(Calendar.YEAR) == alarmDay.get(Calendar.YEAR) &&
                    eventDay.get(Calendar.DAY_OF_YEAR) == alarmDay.get(Calendar.DAY_OF_YEAR)
                if (!notificationEnabled && !alarmEnabled) error = true
                else if (alarmEnabled && (!sameDay || alarmTimeMillis <= System.currentTimeMillis())) error = true
                else onSave(when { notificationEnabled && alarmEnabled -> "both"; alarmEnabled -> "alarm"; else -> "notification" }, 0, alarmTimeMillis, soundUri, vibrate)
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun EventEditor(
    initialDateMillis: Long,
    initialTimeMillis: Long? = null,
    initialEvent: AgendaEvent? = null,
    onDismiss: () -> Unit,
    eventStore: EventStore,
    onSave: (String, String, Long, Long?, String, Int, String?, Boolean, List<EventAttachment>) -> Unit
) {
    val context = LocalContext.current
    var title by remember(initialEvent?.id) { mutableStateOf(initialEvent?.title ?: "") }
    var description by remember(initialEvent?.id) { mutableStateOf(initialEvent?.description ?: "") }
    var notificationEnabled by remember(initialEvent?.id) { mutableStateOf(initialEvent?.reminderMode != "alarm") }
    var alarmEnabled by remember(initialEvent?.id) { mutableStateOf(initialEvent?.reminderMode == "alarm" || initialEvent?.reminderMode == "both") }
    var lead by remember(initialEvent?.id) { mutableStateOf((initialEvent?.leadMinutes ?: 15).toString()) }
    var customLead by remember(initialEvent?.id) { mutableStateOf("45") }
    var selectedTime by remember(initialEvent?.id, initialDateMillis) {
        mutableLongStateOf(
            initialEvent?.timeMillis ?: initialTimeMillis ?: Calendar.getInstance().run {
                val now = System.currentTimeMillis()
                val chosenDay = Calendar.getInstance().apply { timeInMillis = initialDateMillis }
                val today = Calendar.getInstance()
                if (chosenDay.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    chosenDay.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                    timeInMillis = now + 3_600_000L
                } else {
                    timeInMillis = initialDateMillis
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                timeInMillis
            }
        )
    }
    var endTime by remember(initialEvent?.id, initialDateMillis) {
        mutableStateOf(initialEvent?.endTimeMillis ?: (selectedTime + 60L * 60L * 1000L))
    }
    var hasEndTime by remember(initialEvent?.id) { mutableStateOf(initialEvent?.endTimeMillis != null) }
    var error by remember { mutableStateOf(false) }
    var soundUri by remember(initialEvent?.id) { mutableStateOf(initialEvent?.alarmSoundUri) }
    var vibrate by remember(initialEvent?.id) { mutableStateOf(initialEvent?.vibrate ?: true) }
    var attachments by remember(initialEvent?.id) { mutableStateOf(initialEvent?.attachments ?: emptyList()) }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val copied = eventStore.copyAttachment(uri, initialEvent?.id ?: System.currentTimeMillis())
            if (copied != null) attachments = attachments + copied
        }
    }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedTime }
    val dateText = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(selectedTime))
    val timeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(selectedTime))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialEvent == null) "Programmer un événement" else "Modifier l’événement", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Détails du rendez-vous", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        OutlinedTextField(title, { title = it }, label = { Text("Titre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(description, { description = it }, label = { Text("Description (facultatif)") }, modifier = Modifier.fillMaxWidth())
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Date et heure", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(y, m, d)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text(dateText) }
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(Calendar.HOUR_OF_DAY, h)
                                set(Calendar.MINUTE, m)
                                set(Calendar.SECOND, 0)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    }) { Text(timeText) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Définir une heure de fin", modifier = Modifier.weight(1f))
                            Switch(checked = hasEndTime, onCheckedChange = { enabled ->
                                hasEndTime = enabled
                                if (enabled && endTime <= selectedTime) endTime = selectedTime + 60L * 60L * 1000L
                            })
                        }
                        if (hasEndTime) {
                            val endCalendar = Calendar.getInstance().apply { timeInMillis = endTime }
                            OutlinedButton(onClick = {
                                TimePickerDialog(context, { _, h, m ->
                                    val c = Calendar.getInstance().apply {
                                        timeInMillis = selectedTime
                                        set(Calendar.HOUR_OF_DAY, h)
                                        set(Calendar.MINUTE, m)
                                        set(Calendar.SECOND, 0)
                                        set(Calendar.MILLISECOND, 0)
                                    }
                                    endTime = c.timeInMillis
                                }, endCalendar.get(Calendar.HOUR_OF_DAY), endCalendar.get(Calendar.MINUTE), true).show()
                            }) {
                                Text("Fin : " + SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(endTime)))
                            }
                            if (endTime <= selectedTime) {
                                Text("L'heure de fin doit être après l'heure de début.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Type de rappel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it })
                    Text("Alarme sonore Mon Agenda")
                }
                if (!notificationEnabled && !alarmEnabled) Text("Sélectionne au moins un type de rappel.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("Délai avant l'événement", fontWeight = FontWeight.SemiBold)
                val choices = listOf("0" to "À l'heure", "5" to "5 min", "15" to "15 min", "30" to "30 min", "60" to "1 h", "1440" to "La veille", "custom" to "Personnalisé")
                choices.chunked(3).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { (value, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(lead == value, { lead = value })
                                Text(label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (lead == "custom") {
                    OutlinedTextField(
                        customLead, { customLead = it.filter(Char::isDigit).take(5) },
                        label = { Text("Minutes avant") },
                        singleLine = true
                    )
                }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Personnaliser l’alarme", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(soundLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                }
                                ringtonePicker.launch(picker)
                            }) { Text("Choisir la sonnerie") }
                            TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vibreur", modifier = Modifier.weight(1f))
                            Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pièces jointes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text("Les fichiers sont copiés dans Documents/MonAgendaAlarmes/Pieces jointes pour être conservés avec la sauvegarde.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = {
                            attachmentPicker.launch(arrayOf("application/pdf", "image/*", "text/*", "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                        }) {
                            Icon(Icons.Default.AttachFile, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Ajouter une pièce jointe")
                        }
                        if (attachments.isEmpty()) {
                            Text("Aucune pièce jointe.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            attachments.forEach { attachment ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text(attachment.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                    IconButton(onClick = { attachments = attachments.filterNot { it.id == attachment.id } }) {
                                        Icon(Icons.Default.Close, contentDescription = "Retirer la pièce jointe")
                                    }
                                }
                            }
                        }
                    }
                }
                if (error) Text("Saisissez un titre, une date future et un délai valide.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val minutes = if (lead == "custom") customLead.toIntOrNull() else lead.toIntOrNull()
                if (title.isBlank() || (initialEvent == null && selectedTime <= System.currentTimeMillis()) || minutes == null || minutes < 0 ||
                    (hasEndTime && endTime <= selectedTime) || (!notificationEnabled && !alarmEnabled)) {
                    error = true
                } else {
                    val mode = when { notificationEnabled && alarmEnabled -> "both"; alarmEnabled -> "alarm"; else -> "notification" }
                    onSave(title.trim(), description.trim(), selectedTime, if (hasEndTime) endTime else null, mode, minutes, soundUri, vibrate, attachments)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

