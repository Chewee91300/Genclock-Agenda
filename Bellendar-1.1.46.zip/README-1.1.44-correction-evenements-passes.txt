Bellendar 1.1.44

Correction de l'affichage des événements des semaines précédentes.
La période utilisée pour développer les événements commençait à minuit la veille du jour courant. Les événements plus anciens restaient enregistrés mais n'étaient plus affichés. Le chargement commence maintenant au plus ancien événement présent dans les données locales ou importées, afin de réafficher l'historique et de conserver le développement des séries récurrentes.
Aucune migration ni suppression de données n'est effectuée.

VersionName 1.1.44 / versionCode 54.
