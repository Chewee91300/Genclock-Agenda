Bellendar 1.1.46

Correction ciblée de l'ouverture des pièces jointes depuis la fenêtre de pièces jointes de la vue Jour/Semaine : cette vue utilisait encore un Intent ACTION_VIEW direct sur l'URI SAF, en contournant AttachmentOpener. Elle utilise maintenant le même ouvreur sécurisé FileProvider que les cartes d'événements.

L'ouvreur vérifie également que le fichier a bien été copié dans le cache avant de lancer le lecteur, et affiche une erreur explicite en cas d'échec.

VersionName 1.1.46 / versionCode 56.
