Bellendar 1.1.45

Corrections :
- Conservation de l'affichage des événements passés (correction précédente).
- Ouverture des pièces jointes via un partage temporaire FileProvider depuis le cache de l'application.
- Transmission explicite des autorisations de lecture et affichage d'un message en cas d'échec.
- Fonctionnement identique depuis les cartes d'événements et la vue hebdomadaire.

Identifiant Android conservé : fr.bellendar
VersionCode : 55
VersionName : 1.1.45

Installer comme une mise à jour, sans désinstaller la version précédente, pour conserver les données locales.
