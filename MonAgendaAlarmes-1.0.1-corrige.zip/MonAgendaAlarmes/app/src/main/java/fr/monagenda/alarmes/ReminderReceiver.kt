package fr.monagenda.alarmes

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            // Nouvel identifiant pour appliquer les paramètres sonores même si l'ancien canal existe.
            val channelId = "agenda_alarm_reminders_v2"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val channel = NotificationChannel(
                    channelId, "Alarmes et rappels Mon Agenda", NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Sonnerie des rappels de Mon Agenda"
                    setSound(alarmSound, audioAttributes)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 250, 500)
                }
                manager.createNotificationChannel(channel)
            }

            val title = intent.getStringExtra("title") ?: "Rappel"
            val description = intent.getStringExtra("description").orEmpty()
            val openApp = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(description.ifBlank { "Votre événement est prévu maintenant." })
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(openApp)
                .build()
            manager.notify(intent.getLongExtra("eventId", 0L).hashCode(), notification)
        } catch (_: Exception) {
            // Un problème de notification ne doit pas provoquer de crash du processus.
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            EventStore(context).load().forEach { ReminderScheduler.schedule(context, it) }
        } catch (_: Exception) {
            // La restauration des rappels ne doit pas faire planter le démarrage.
        }
    }
}
