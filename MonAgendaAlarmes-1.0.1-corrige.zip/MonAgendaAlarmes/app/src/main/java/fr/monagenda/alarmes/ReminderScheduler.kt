package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    /**
     * Programme un rappel local. Retourne false si Android refuse la programmation.
     * L'application ne doit jamais se fermer si l'accès aux alarmes exactes est refusé.
     */
    fun schedule(context: Context, event: AgendaEvent): Boolean {
        return try {
            val triggerAt = event.timeMillis - event.leadMinutes * 60_000L
            if (triggerAt <= System.currentTimeMillis()) return false

            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("eventId", event.id)
                putExtra("title", event.title)
                putExtra("description", event.description)
            }
            val pending = PendingIntent.getBroadcast(
                context, event.id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                // Autorisation spéciale non accordée : rappel non exact plutôt que plantage.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
            } else {
                try {
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
                } catch (_: SecurityException) {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun cancel(context: Context, event: AgendaEvent) {
        try {
            val intent = Intent(context, ReminderReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context, event.id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
        } catch (_: Exception) {
            // Une suppression ne doit pas faire tomber l'application.
        }
    }
}
