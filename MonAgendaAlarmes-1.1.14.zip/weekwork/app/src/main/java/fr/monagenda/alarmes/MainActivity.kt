package fr.monagenda.alarmes

import android.app.AlarmManager
import android.provider.Settings
import android.net.Uri
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen() {
    val context = LocalContext.current
    val store = remember { EventStore(context) }
    var events by remember { mutableStateOf(store.load()) }
    var message by remember { mutableStateOf<String?>(null) }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                // Restaurer d'abord la sauvegarde existante. Ne jamais l'écraser
                // avec la liste vide chargée avant que l'utilisateur ait choisi le dossier.
                events = store.attachBackupTree(uri, events)
                message = if (events.isNotEmpty()) {
                    "Sauvegarde retrouvée : ${events.size} événement(s) restauré(s)."
                } else {
                    "Sauvegarde automatique activée dans Documents/MonAgendaAlarmes."
                }
            }.onFailure {
                message = "Impossible d'activer la sauvegarde locale. Vérifie que le dossier Documents est accessible."
            }
        }
    }
    LaunchedEffect(Unit) {
        if (store.backupTreeUri() == null) {
            val documentsUri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADocuments")
            backupFolderPicker.launch(documentsUri)
        }
    }
    var showEditor by remember { mutableStateOf(false) }
    var eventBeingEdited by remember { mutableStateOf<AgendaEvent?>(null) }
    var showExactAlarmDialog by remember { mutableStateOf(false) }
    var showDayEvents by remember { mutableStateOf(true) }
    var showAbout by remember { mutableStateOf(false) }
    var outlookDeleteTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var outlookReminderTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val appVersion = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "inconnue" }.getOrDefault("inconnue")
    }
    var view by remember { mutableStateOf("Mois") }
    var selectedDay by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var outlookEvents by remember { mutableStateOf(emptyList<AgendaEvent>()) }
    val allEvents = remember(events, outlookEvents) { (events + outlookEvents).distinctBy { it.id }.sortedBy { it.timeMillis } }

    val calendarPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        } else {
            message = "Autorisation de lecture du calendrier refusée. Active-la dans les paramètres Android pour afficher les événements Outlook."
        }
    }

    val outlookWritePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val target = outlookDeleteTarget
        if (granted && target != null) {
            if (OutlookCalendarReader.deleteEvent(context, target)) {
                ReminderScheduler.cancel(context, target)
                events = events.filterNot { it.id == target.id }
                store.save(events)
                outlookEvents = OutlookCalendarReader.readEvents(context)
                message = "Événement supprimé du calendrier synchronisé."
            } else message = "La suppression a échoué. Vérifie les droits du calendrier synchronisé."
        } else if (!granted) message = "Autorisation de modification du calendrier refusée."
        outlookDeleteTarget = null
    }

    var notificationsAllowed by remember {
        mutableStateOf(
            android.os.Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
        )
    }

    // La réponse Android est prise en compte immédiatement, sans redémarrer l'application.
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsAllowed = granted
        if (granted) {
            store.load()
                .filter { it.reminderMode == "notification" }
                .forEach { ReminderScheduler.schedule(context, it) }
            message = "Notifications autorisées. Les rappels enregistrés sont maintenant activés."
        } else {
            message = "Notifications non autorisées. Tu peux les activer dans les paramètres Android."
        }
    }
    fun exactAlarmsAllowed(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) return true
        val manager = context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager
        return manager.canScheduleExactAlarms()
    }

    LaunchedEffect(Unit) {
        while (true) {
            clockNow = System.currentTimeMillis()
            delay(1000)
        }
    }

    LaunchedEffect(Unit) {
        if (!exactAlarmsAllowed()) showExactAlarmDialog = true
        // Première ouverture : demander l'accès au calendrier pour pouvoir importer Outlook.
        if (!OutlookCalendarReader.hasPermission(context)) {
            calendarPermission.launch(Manifest.permission.READ_CALENDAR)
        } else {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && !notificationsAllowed) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Actualisation automatique à chaque retour de l'application au premier plan.
    val lifecycle = (context as? ComponentActivity)?.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (OutlookCalendarReader.hasPermission(context)) outlookEvents = OutlookCalendarReader.readEvents(context)
                if (!exactAlarmsAllowed()) showExactAlarmDialog = true

                // Android peut modifier l'autorisation pendant que l'application est en arrière-plan.
                // On relit son état au retour, puis on restaure les rappels sans fermeture/réouverture.
                notificationsAllowed = android.os.Build.VERSION.SDK_INT < 33 ||
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED

                store.load().forEach { saved ->
                    when (saved.reminderMode) {
                        "alarm" -> if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        "notification" -> if (notificationsAllowed) ReminderScheduler.schedule(context, saved)
                    }
                }
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    val violet = Color(0xFF6420B8)
    val pale = Color(0xFFF8F1FF)
    MaterialTheme(colorScheme = lightColorScheme(
        primary = violet, onPrimary = Color.White,
        primaryContainer = Color(0xFFEAD9FF), onPrimaryContainer = Color(0xFF32105F),
        secondary = Color(0xFF8A4BD1), background = pale, surface = Color.White,
        onSurface = Color(0xFF211536), surfaceVariant = Color(0xFFF0E5FA),
        onSurfaceVariant = Color(0xFF655A70)
    )) {
        Scaffold(
            containerColor = pale,
            topBar = {
                Box(Modifier.fillMaxWidth().height(96.dp).statusBarsPadding()) {
                    Image(painter = painterResource(id = R.drawable.banner_agenda), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(96.dp), contentScale = ContentScale.Crop)
                    Row(Modifier.fillMaxWidth().align(Alignment.Center).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(42.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            Text("Mon Agenda &", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, lineHeight = 24.sp)
                            Text("Alarmes", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, lineHeight = 24.sp)
                        }
                        TextButton(onClick = { showAbout = true }, contentPadding = PaddingValues(horizontal = 4.dp)) {
                            Icon(Icons.Default.Info, null, tint = Color.White, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("À propos", color = Color.White, fontSize = 12.sp, maxLines = 1)
                        }
                        IconButton(onClick = {
                            if (OutlookCalendarReader.hasPermission(context)) {
                                outlookEvents = OutlookCalendarReader.readEvents(context)
                                message = "Calendrier synchronisé actualisé."
                            } else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                        }, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Actualiser Outlook", tint = Color.White, modifier = Modifier.size(27.dp))
                        }
                    }
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showEditor = true }, containerColor = Color(0xFF7629C8), contentColor = Color.White, shape = RoundedCornerShape(22.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un événement")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().background(Color(0xFFF8F1FF)).padding(horizontal = 10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Jour", "Semaine", "Mois").forEach { label ->
                            FilterChip(selected = view == label, onClick = { view = label }, label = { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.height(36.dp))
                        }
                    }
                    Text(SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date(clockNow)), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                CalendarNavigator(view, selectedDay, onPrevious = { selectedDay = shiftDate(selectedDay, view, -1) },
                    onNext = { selectedDay = shiftDate(selectedDay, view, 1) }, onToday = { selectedDay = System.currentTimeMillis() })
                when (view) {
                    "Jour" -> DayAgenda(selectedDay, allEvents, expanded = !showDayEvents)
                    "Semaine" -> WeekAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                    else -> MonthAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                }
                val dayEvents = allEvents.filter { sameDay(it.timeMillis, selectedDay) }.sortedBy { it.timeMillis }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 7.dp)
                    .background(Color(0xFFEBD9FC), RoundedCornerShape(16.dp)).padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, null, tint = Color(0xFF6420B8), modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Événements du ${SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(selectedDay))}",
                        fontSize = 15.sp, lineHeight = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
                        modifier = Modifier.weight(1f), color = Color(0xFF24113F))
                    TextButton(onClick = { showDayEvents = !showDayEvents }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                        Text(if (showDayEvents) "Masquer ⌃" else "Afficher", fontSize = 12.sp, color = Color(0xFF6420B8), fontWeight = FontWeight.Bold)
                    }
                }
                if (showDayEvents) {
                    if (dayEvents.isEmpty()) Text("Aucun événement ce jour.", Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(dayEvents, key = { it.id }) { event ->
                            EventCard(event, onEdit = {
                                if (event.outlookEventId != null) {
                                    val editIntent = Intent(Intent.ACTION_EDIT).apply {
                                        data = android.content.ContentUris.withAppendedId(
                                            android.provider.CalendarContract.Events.CONTENT_URI, event.outlookEventId
                                        )
                                        type = "vnd.android.cursor.item/event"
                                    }
                                    runCatching { context.startActivity(editIntent) }
                                        .onFailure { message = "Aucune application de calendrier ne permet de modifier cet événement." }
                                }
                            }, onDelete = {
                                if (event.outlookEventId != null) {
                                    outlookDeleteTarget = event
                                } else {
                                    ReminderScheduler.cancel(context, event)
                                    events = events.filterNot { it.id == event.id }
                                    store.save(events)
                                }
                            }, onAlarm = {
                                if (event.outlookEventId != null) outlookReminderTarget = event
                                else {
                                    eventBeingEdited = event
                                    showEditor = true
                                }
                            })
                        }
                    }
                }
            }
        }
    }

    outlookDeleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { outlookDeleteTarget = null },
            title = { Text("Supprimer du calendrier source ?") },
            text = { Text("« ${target.title} » sera supprimé du calendrier synchronisé et la suppression pourra être répercutée dans Outlook ou Google après synchronisation. Attention : si ce rendez-vous appartient à une série récurrente, la série entière peut être supprimée.") },
            confirmButton = {
                TextButton(onClick = {
                    if (OutlookCalendarReader.hasWritePermission(context)) {
                        if (OutlookCalendarReader.deleteEvent(context, target)) {
                            ReminderScheduler.cancel(context, target)
                            events = events.filterNot { it.id == target.id }
                            store.save(events)
                            outlookEvents = OutlookCalendarReader.readEvents(context)
                            message = "Événement supprimé du calendrier synchronisé."
                        } else message = "Impossible de supprimer cet événement."
                        outlookDeleteTarget = null
                    } else {
                        outlookWritePermission.launch(Manifest.permission.WRITE_CALENDAR)
                    }
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { outlookDeleteTarget = null }) { Text("Annuler") } }
        )
    }

    outlookReminderTarget?.let { target ->
        OutlookReminderEditor(
            event = target,
            onDismiss = { outlookReminderTarget = null },
            onSave = { mode, lead, alarmTime, soundUri, vibrate ->
                val updated = target.copy(reminderMode = mode, leadMinutes = lead, alarmTimeMillis = alarmTime, alarmSoundUri = soundUri, vibrate = vibrate)
                ReminderScheduler.cancel(context, target)
                events = (events.filterNot { it.id == target.id } + updated).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = if (mode == "alarm") ReminderScheduler.scheduleAlarm(context, updated)
                    else ReminderScheduler.schedule(context, updated)
                outlookReminderTarget = null
                if (scheduled) message = if (mode == "alarm") "Alarme sonore ajoutée à l’événement Outlook." else "Notification ajoutée à l’événement Outlook."
                else {
                    message = "Le rappel est enregistré, mais n’a pas pu être programmé. Vérifie l’autorisation Alarmes et rappels et que l’événement est dans le futur."
                    if (mode == "alarm" && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }

    if (showEditor) {
        val editing = eventBeingEdited
        EventEditor(
            initialDateMillis = editing?.timeMillis ?: selectedDay,
            initialEvent = editing,
            onDismiss = { showEditor = false; eventBeingEdited = null },
            onSave = { title, desc, time, mode, lead, soundUri, vibrate ->
                val event = if (editing != null) editing.copy(
                    title = title, description = desc, timeMillis = time,
                    reminderMode = mode, leadMinutes = lead, alarmTimeMillis = null,
                    alarmSoundUri = soundUri, vibrate = vibrate
                ) else AgendaEvent(System.currentTimeMillis(), title, desc, time, mode, lead, alarmSoundUri = soundUri, vibrate = vibrate)
                if (editing != null) ReminderScheduler.cancel(context, editing)
                events = (events.filterNot { it.id == event.id } + event).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = when (mode) {
                    "notification" -> ReminderScheduler.schedule(context, event)
                    "alarm" -> ReminderScheduler.scheduleAlarm(context, event)
                    else -> false
                }
                showEditor = false
                eventBeingEdited = null
                selectedDay = time
                if (scheduled) message = if (editing != null) "Événement modifié et rappel reprogrammé." else "Événement enregistré."
                else {
                    message = "L'événement est enregistré, mais le rappel n'a pas pu être programmé. Vérifie l'autorisation Alarmes et rappels."
                    if (mode == "alarm" && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Mon Agenda & Alarmes", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(38.dp))
                            Text("Votre agenda, vos rappels.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Organisez vos événements et ne manquez plus aucun rendez-vous.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Text("Développé par V Da Silva", fontWeight = FontWeight.SemiBold)
                    Text("Version $appVersion", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Fermer") } }
        )
    }

    if (showExactAlarmDialog) {
        AlertDialog(
            onDismissRequest = { showExactAlarmDialog = false },
            title = { Text("Autoriser les alarmes exactes") },
            text = { Text("Pour que les alarmes sonnent à l'heure prévue, Mon Agenda doit être autorisé à utiliser « Alarmes et rappels ». Active cette autorisation dans les paramètres Android.") },
            confirmButton = {
                TextButton(onClick = {
                    showExactAlarmDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:" + context.packageName)
                        }
                        context.startActivity(intent)
                    }
                }) { Text("ACTIVER LES ALARMES EXACTES") }
            },
            dismissButton = {
                TextButton(onClick = { showExactAlarmDialog = false }) { Text("Plus tard") }
            }
        )
    }

    message?.let {
        AlertDialog(onDismissRequest = { message = null }, confirmButton = {
            TextButton(onClick = { message = null }) { Text("OK") }
        }, title = { Text("Information") }, text = { Text(it) })
    }
}

private fun dayStart(time: Long): Calendar = Calendar.getInstance().apply {
    timeInMillis = time
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}
private fun sameDay(a: Long, b: Long): Boolean {
    val x = dayStart(a); val y = dayStart(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}
private fun shiftDate(time: Long, view: String, amount: Int): Long = Calendar.getInstance().apply {
    timeInMillis = time
    add(when(view) { "Jour" -> Calendar.DAY_OF_MONTH; "Semaine" -> Calendar.WEEK_OF_YEAR; else -> Calendar.MONTH }, amount)
}.timeInMillis

@Composable
private fun CalendarNavigator(view: String, selected: Long, onPrevious: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    val title = when(view) {
        "Jour" -> SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date(selected))
        "Semaine" -> {
            val c = dayStart(selected); c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            val first = c.timeInMillis; c.add(Calendar.DAY_OF_MONTH, 6)
            SimpleDateFormat("d MMM", Locale.FRANCE).format(Date(first)) + " – " + SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(c.time)
        }
        else -> SimpleDateFormat("MMMM yyyy", Locale.FRANCE).format(Date(selected))
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(onClick = onPrevious, shape = RoundedCornerShape(14.dp), color = Color(0xFFF1E5FC), modifier = Modifier.size(38.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronLeft, "Période précédente", tint = Color(0xFF32105F)) }
        }
        Spacer(Modifier.width(8.dp))
        Text(title.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.ExtraBold, color = Color(0xFF32105F),
            fontSize = 20.sp, maxLines = 1, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Spacer(Modifier.width(6.dp))
        TextButton(onClick = onToday, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 3.dp)) {
            Text("Aujourd'hui", color = Color(0xFF6420B8), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Surface(onClick = onNext, shape = RoundedCornerShape(14.dp), color = Color(0xFFF1E5FC), modifier = Modifier.size(38.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronRight, "Période suivante", tint = Color(0xFF32105F)) }
        }
    }
}

@Composable
private fun DayAgenda(selected: Long, events: List<AgendaEvent>, expanded: Boolean) {
    val hours = (0..23).toList()
    Column(Modifier.fillMaxWidth().heightIn(max = if (expanded) 520.dp else 230.dp).padding(bottom = 6.dp)) {
        Text("Planning horaire", style = MaterialTheme.typography.labelLarge)
        LazyColumn { items(hours) { hour ->
            val atHour = events.filter { sameDay(it.timeMillis, selected) && Calendar.getInstance().apply { timeInMillis = it.timeMillis }.get(Calendar.HOUR_OF_DAY) == hour }
            Row(Modifier.fillMaxWidth().heightIn(min = 28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(String.format(Locale.FRANCE, "%02d:00", hour), modifier = Modifier.width(52.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                HorizontalDivider(Modifier.weight(1f))
                if (atHour.isNotEmpty()) Text("  ${atHour.joinToString { it.title }}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        } }
    }
}

@Composable
private fun WeekAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, expanded: Boolean) {
    val start = dayStart(selected).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }
    Column(Modifier.fillMaxWidth().heightIn(max = if (expanded) 520.dp else 230.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(7) { index ->
            val day = Calendar.getInstance().apply { timeInMillis = start.timeInMillis; add(Calendar.DAY_OF_MONTH, index) }
            val dayEvents = events.filter { sameDay(it.timeMillis, day.timeInMillis) }
            OutlinedButton(onClick = { onSelectDay(day.timeInMillis) }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)) {
                Text(SimpleDateFormat("EEE d", Locale.FRANCE).format(day.time).replaceFirstChar { it.uppercase() }, modifier = Modifier.width(75.dp))
                Text(if (dayEvents.isEmpty()) "—" else dayEvents.joinToString(" · ") { SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(it.timeMillis)) + " " + it.title }, maxLines = 1)
            }
        }
    }
}

// Jours fériés légaux en France métropolitaine, calculés pour chaque année.
private fun isFrenchPublicHoliday(date: Calendar): Boolean {
    val year = date.get(Calendar.YEAR)
    val month = date.get(Calendar.MONTH) + 1
    val day = date.get(Calendar.DAY_OF_MONTH)
    val fixed = setOf("1-1", "5-1", "5-8", "7-14", "8-15", "11-1", "11-11", "12-25")
    if ("$month-$day" in fixed) return true
    val easter = easterSunday(year)
    val easterMonday = easter.plusDays(1)
    val ascension = easter.plusDays(39)
    val whitMonday = easter.plusDays(50)
    val current = java.time.LocalDate.of(year, month, day)
    return current == easterMonday || current == ascension || current == whitMonday
}

private fun easterSunday(year: Int): java.time.LocalDate {
    val a = year % 19
    val b = year / 100
    val c = year % 100
    val d = b / 4
    val e = b % 4
    val f = (b + 8) / 25
    val g = (b - f + 1) / 3
    val h = (19 * a + b - d - g + 15) % 30
    val i = c / 4
    val k = c % 4
    val l = (32 + 2 * e + 2 * i - h - k) % 7
    val m = (a + 11 * h + 22 * l) / 451
    val month = (h + l - 7 * m + 114) / 31
    val day = (h + l - 7 * m + 114) % 31 + 1
    return java.time.LocalDate.of(year, month, day)
}

@Composable
private fun MonthAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, expanded: Boolean) {
    val month = Calendar.getInstance().apply { timeInMillis = selected; set(Calendar.DAY_OF_MONTH, 1); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
    val offset = (month.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY + 7) % 7
    val days = (0 until offset).map { 0 } + (1..month.getActualMaximum(Calendar.DAY_OF_MONTH)).toList()
    val weeks = days.chunked(7)
    Card(Modifier.fillMaxWidth().padding(top = 1.dp, bottom = 3.dp), shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(5.dp)) {
        Column(Modifier.padding(horizontal = 5.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth().background(Color(0xFFF2E8FF), RoundedCornerShape(14.dp)).padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Sem.", Modifier.width(48.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = Color(0xFF5B2A9B), style = MaterialTheme.typography.labelMedium)
                listOf("L", "M", "M", "J", "V", "S", "D").forEachIndexed { i, label ->
                    Text(label, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold,
                        color = when(i) { 5 -> Color(0xFF1769D2); 6 -> Color(0xFFD52E2E); else -> Color(0xFF241936) })
                }
            }
            weeks.forEachIndexed { wi, week ->
                Row(Modifier.fillMaxWidth().height(if (expanded) 43.dp else 38.dp), verticalAlignment = Alignment.CenterVertically) {
                    val weekStart = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; add(Calendar.DAY_OF_MONTH, wi * 7 - offset); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
                    Box(Modifier.width(48.dp).fillMaxHeight().padding(vertical = 3.dp).background(Color(0xFFF3E9FC), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text(weekStart.get(Calendar.WEEK_OF_YEAR).toString(), color = Color(0xFF62566E), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                    week.forEach { n ->
                        Box(Modifier.weight(1f).fillMaxHeight().padding(2.dp), contentAlignment = Alignment.Center) {
                            if (n > 0) {
                                val date = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; set(Calendar.DAY_OF_MONTH, n) }
                                val count = events.count { sameDay(it.timeMillis, date.timeInMillis) }
                                val selectedDate = sameDay(date.timeInMillis, selected)
                                val dayColor = when { isFrenchPublicHoliday(date) || date.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY -> Color(0xFFD52E35); date.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY -> Color(0xFF1769D2); else -> Color(0xFF241936) }
                                Surface(onClick = { onSelectDay(date.timeInMillis) }, modifier = Modifier.fillMaxSize(), shape = RoundedCornerShape(14.dp), color = if (selectedDate) Color(0xFF7629C8) else Color.Transparent) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = if (selectedDate) Color.White else dayColor, fontWeight = if (selectedDate || isFrenchPublicHoliday(date)) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp, lineHeight = 16.sp)
                                        if (count > 0) Text("•".repeat(count.coerceAtMost(3)), color = if (selectedDate) Color.White else Color(0xFF7025B9), style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                    repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                }
                if (wi < weeks.lastIndex) HorizontalDivider(color = Color(0xFFF0E8F7), thickness = 0.7.dp)
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(start = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("●", color = Color(0xFF7025B9)); Text(" Notification", color = Color(0xFF51475D), style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.width(18.dp)); Text("●●", color = Color(0xFF7025B9)); Text(" Alarme Horloge", color = Color(0xFF51475D), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun EventCard(event: AgendaEvent, onEdit: () -> Unit, onDelete: () -> Unit, onAlarm: () -> Unit) {
    val date = remember(event.timeMillis) {
        SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFBF8FF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Box(Modifier.width(5.dp).height(142.dp).background(Color(0xFF8B35D2)))
            Row(Modifier.padding(horizontal = 11.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF7629C8), modifier = Modifier.size(40.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(event.title, fontSize = 17.sp, lineHeight = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1F1730), maxLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(17.dp), tint = Color(0xFF241936))
                        Spacer(Modifier.width(6.dp))
                        Text(date.replaceFirstChar { it.uppercase() }, fontSize = 13.sp, lineHeight = 16.sp, color = Color(0xFF342B42), maxLines = 2)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (event.reminderMode == "alarm") Icons.Default.Alarm else Icons.Default.Notifications, null,
                            modifier = Modifier.size(19.dp), tint = Color(0xFF241936))
                        Spacer(Modifier.width(6.dp))
                        Text((when (event.reminderMode) {
                            "alarm" -> "Alarme Mon Agenda"
                            "outlook" -> "Événement Outlook sans rappel"
                            else -> if (event.outlookEventId != null) "Rappel Outlook" else "Notification"
                        }) + if (event.reminderMode == "outlook") "" else " · ${event.leadMinutes} min avant",
                            fontSize = 13.sp, lineHeight = 16.sp, color = Color(0xFF342B42), maxLines = 2)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (event.outlookEventId != null) {
                            OutlinedButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF9A56D5))) {
                                Text("Modifier", fontSize = 12.sp, color = Color(0xFF6420B8), maxLines = 1)
                            }
                        } else if (event.reminderMode == "alarm") {
                            OutlinedButton(onClick = onAlarm, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF9A56D5))) {
                                Text("Reprogrammer l’alarme", fontSize = 12.sp, color = Color(0xFF6420B8), maxLines = 1)
                            }
                        }
                        OutlinedButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                            shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE66A83))) {
                            Text("Supprimer", fontSize = 12.sp, color = Color(0xFFB3263B), maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OutlookReminderEditor(
    event: AgendaEvent,
    onDismiss: () -> Unit,
    onSave: (String, Int, Long, String?, Boolean) -> Unit
) {
    var mode by remember(event.id) { mutableStateOf(if (event.reminderMode == "outlook") "alarm" else event.reminderMode) }
    var alarmTimeMillis by remember(event.id) {
        mutableLongStateOf(event.alarmTimeMillis ?: run {
            val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
            val eventMinute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val alarmMinute = (eventMinute - 15).coerceAtLeast(0)
            c.set(Calendar.HOUR_OF_DAY, alarmMinute / 60)
            c.set(Calendar.MINUTE, alarmMinute % 60)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.timeInMillis
        })
    }
    var error by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var soundUri by remember(event.id) { mutableStateOf(event.alarmSoundUri) }
    var vibrate by remember(event.id) { mutableStateOf(event.vibrate) }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }
    val alarmTimeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(alarmTimeMillis))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rappel de l’événement Outlook") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(event.title, fontWeight = FontWeight.SemiBold)
                Text(SimpleDateFormat("EEEE d MMMM 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis)))
                Text("Le jour du rendez-vous reste inchangé. Seule l’heure de l’alarme sera modifiée.", style = MaterialTheme.typography.bodySmall)
                Text("Type de rappel", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "alarm", { mode = "alarm" })
                    Text("Alarme sonore")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "notification", { mode = "notification" })
                    Text("Notification")
                }
                Text("Heure de l’alarme", fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                    TimePickerDialog(
                        context,
                        { _, hour, minute ->
                            val selected = Calendar.getInstance().apply {
                                timeInMillis = event.timeMillis
                                set(Calendar.HOUR_OF_DAY, hour)
                                set(Calendar.MINUTE, minute)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                            alarmTimeMillis = selected.timeInMillis
                            error = false
                        },
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true
                    ).show()
                }) { Text("Choisir : $alarmTimeText") }
                Text("Sonnerie", fontWeight = FontWeight.SemiBold)
                Text(soundLabel, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                        }
                        ringtonePicker.launch(picker)
                    }) { Text("Choisir une sonnerie") }
                    TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Vibreur", modifier = Modifier.weight(1f))
                    Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                }
                if (error) Text("Choisis une heure future, le même jour que le rendez-vous.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val eventDay = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val alarmDay = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                val sameDay = eventDay.get(Calendar.YEAR) == alarmDay.get(Calendar.YEAR) &&
                    eventDay.get(Calendar.DAY_OF_YEAR) == alarmDay.get(Calendar.DAY_OF_YEAR)
                if (!sameDay || alarmTimeMillis <= System.currentTimeMillis()) error = true
                else onSave(mode, 0, alarmTimeMillis, soundUri, vibrate)
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun EventEditor(
    initialDateMillis: Long,
    initialEvent: AgendaEvent? = null,
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String, Int, String?, Boolean) -> Unit
) {
    val context = LocalContext.current
    var title by remember(initialEvent?.id) { mutableStateOf(initialEvent?.title ?: "") }
    var description by remember(initialEvent?.id) { mutableStateOf(initialEvent?.description ?: "") }
    var mode by remember(initialEvent?.id) { mutableStateOf(initialEvent?.reminderMode ?: "notification") }
    var lead by remember(initialEvent?.id) { mutableStateOf((initialEvent?.leadMinutes ?: 15).toString()) }
    var customLead by remember(initialEvent?.id) { mutableStateOf("45") }
    var selectedTime by remember(initialEvent?.id, initialDateMillis) {
        mutableLongStateOf(
            initialEvent?.timeMillis ?: Calendar.getInstance().run {
                val now = System.currentTimeMillis()
                val chosenDay = Calendar.getInstance().apply { timeInMillis = initialDateMillis }
                val today = Calendar.getInstance()
                if (chosenDay.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    chosenDay.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                    timeInMillis = now + 3_600_000L
                } else {
                    timeInMillis = initialDateMillis
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                timeInMillis
            }
        )
    }
    var error by remember { mutableStateOf(false) }
    var soundUri by remember(initialEvent?.id) { mutableStateOf(initialEvent?.alarmSoundUri) }
    var vibrate by remember(initialEvent?.id) { mutableStateOf(initialEvent?.vibrate ?: true) }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedTime }
    val dateText = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(selectedTime))
    val timeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(selectedTime))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialEvent == null) "Programmer un événement" else "Modifier l’événement", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Détails du rendez-vous", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        OutlinedTextField(title, { title = it }, label = { Text("Titre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(description, { description = it }, label = { Text("Description (facultatif)") }, modifier = Modifier.fillMaxWidth())
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Date et heure", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(y, m, d)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text(dateText) }
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(Calendar.HOUR_OF_DAY, h)
                                set(Calendar.MINUTE, m)
                                set(Calendar.SECOND, 0)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    }) { Text(timeText) }
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Type de rappel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "notification", { mode = "notification" })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "alarm", { mode = "alarm" })
                    Text("Alarme sonore Mon Agenda")
                }
                Text("Délai avant l'événement", fontWeight = FontWeight.SemiBold)
                val choices = listOf("0" to "À l'heure", "5" to "5 min", "15" to "15 min", "30" to "30 min", "60" to "1 h", "1440" to "La veille", "custom" to "Personnalisé")
                choices.chunked(3).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { (value, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(lead == value, { lead = value })
                                Text(label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (lead == "custom") {
                    OutlinedTextField(
                        customLead, { customLead = it.filter(Char::isDigit).take(5) },
                        label = { Text("Minutes avant") },
                        singleLine = true
                    )
                }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Personnaliser l’alarme", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(soundLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                }
                                ringtonePicker.launch(picker)
                            }) { Text("Choisir la sonnerie") }
                            TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vibreur", modifier = Modifier.weight(1f))
                            Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                        }
                    }
                }
                if (error) Text("Saisissez un titre, une date future et un délai valide.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val minutes = if (lead == "custom") customLead.toIntOrNull() else lead.toIntOrNull()
                if (title.isBlank() || selectedTime <= System.currentTimeMillis() || minutes == null || minutes < 0) {
                    error = true
                } else {
                    onSave(title.trim(), description.trim(), selectedTime, mode, minutes, soundUri, vibrate)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

