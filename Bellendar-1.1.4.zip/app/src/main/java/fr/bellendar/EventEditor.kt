package fr.bellendar

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt


@Composable
fun EventEditor(
    initialDateMillis: Long,
    initialTimeMillis: Long? = null,
    initialEvent: AgendaEvent? = null,
    onDismiss: () -> Unit,
    eventStore: EventStore,
    onSave: (String, String, Long, Long?, String, Int, String?, Boolean, List<EventAttachment>, String?, String, Int, List<Int>, Long?, Int?) -> Unit
) {
    val uiLocale = currentUiLocale()
    val context = LocalContext.current
    var title by remember(initialEvent?.id) { mutableStateOf(initialEvent?.title ?: "") }
    var description by remember(initialEvent?.id) { mutableStateOf(initialEvent?.description ?: "") }
    var notificationEnabled by remember(initialEvent?.id) { mutableStateOf(initialEvent?.reminderMode != "alarm") }
    var alarmEnabled by remember(initialEvent?.id) { mutableStateOf(initialEvent?.reminderMode == "alarm" || initialEvent?.reminderMode == "both") }
    var lead by remember(initialEvent?.id) { mutableStateOf((initialEvent?.leadMinutes ?: 15).toString()) }
    var customLead by remember(initialEvent?.id) { mutableStateOf("45") }
    var selectedTime by remember(initialEvent?.id, initialDateMillis) {
        mutableLongStateOf(
            initialEvent?.timeMillis ?: initialTimeMillis ?: Calendar.getInstance().run {
                val now = System.currentTimeMillis()
                val chosenDay = Calendar.getInstance().apply { timeInMillis = initialDateMillis }
                val today = Calendar.getInstance()
                if (chosenDay.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    chosenDay.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                    timeInMillis = now + 3_600_000L
                } else {
                    timeInMillis = initialDateMillis
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                timeInMillis
            }
        )
    }
    var endTime by remember(initialEvent?.id, initialDateMillis) {
        mutableStateOf(initialEvent?.endTimeMillis ?: (selectedTime + 60L * 60L * 1000L))
    }
    var hasEndTime by remember(initialEvent?.id) { mutableStateOf(initialEvent?.endTimeMillis != null) }
    var error by remember { mutableStateOf(false) }
    var soundUri by remember(initialEvent?.id) { mutableStateOf(initialEvent?.alarmSoundUri) }
    var vibrate by remember(initialEvent?.id) { mutableStateOf(initialEvent?.vibrate ?: true) }
    var attachments by remember(initialEvent?.id) { mutableStateOf(initialEvent?.attachments ?: emptyList()) }
    val eventColorOptions = listOf("#1565C0", "#00BFA5", "#FFB300", "#E53935", "#8E24AA")
    var selectedEventColor by remember(initialEvent?.id) { mutableStateOf(initialEvent?.colorHex ?: eventColorOptions.first()) }
    var recurrenceType by remember(initialEvent?.id) { mutableStateOf(initialEvent?.recurrenceType ?: "NONE") }
    var showRecurrenceOptions by remember(initialEvent?.id) { mutableStateOf(false) }
    var recurrenceInterval by remember(initialEvent?.id) { mutableStateOf((initialEvent?.recurrenceInterval ?: 1).toString()) }
    var recurrenceEndMode by remember(initialEvent?.id) { mutableStateOf(if (initialEvent?.recurrenceCount != null) "COUNT" else if (initialEvent?.recurrenceEndMillis != null) "DATE" else "NEVER") }
    var recurrenceCount by remember(initialEvent?.id) { mutableStateOf((initialEvent?.recurrenceCount ?: 10).toString()) }
    var recurrenceDays by remember(initialEvent?.id) {
        mutableStateOf(
            initialEvent?.recurrenceDays?.takeIf { it.isNotEmpty() }
                ?: listOf(Calendar.getInstance().apply {
                    timeInMillis = initialEvent?.timeMillis ?: initialDateMillis
                }.get(Calendar.DAY_OF_WEEK))
        )
    }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val copied = eventStore.copyAttachment(uri, initialEvent?.id ?: System.currentTimeMillis())
            if (copied != null) attachments = attachments + copied
        }
    }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedTime }
    val dateText = SimpleDateFormat("dd/MM/yyyy", uiLocale).format(Date(selectedTime))
    val timeText = SimpleDateFormat("HH:mm", uiLocale).format(Date(selectedTime))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr(if (initialEvent == null) "Programmer un événement" else "Modifier l’événement"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp), modifier = Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(tr("Détails du rendez-vous"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        OutlinedTextField(title, { title = it }, label = { Text(tr("Titre")) }, singleLine = true, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp), textStyle = MaterialTheme.typography.bodyMedium)
                        OutlinedTextField(description, { description = it }, label = { Text(tr("Description (facultatif)")) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp), minLines = 1, maxLines = 3, textStyle = MaterialTheme.typography.bodyMedium)
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(tr("Couleur de l’événement"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            eventColorOptions.forEach { hex ->
                                val swatch = Color(android.graphics.Color.parseColor(hex))
                                val selected = selectedEventColor == hex
                                Surface(
                                    modifier = Modifier.size(if (selected) 30.dp else 26.dp).clickable { selectedEventColor = hex },
                                    shape = CircleShape,
                                    color = swatch,
                                    border = androidx.compose.foundation.BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        if (selected) Icon(Icons.Default.CheckCircle, contentDescription = tr("Couleur sélectionnée"), tint = Color.DarkGray, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(tr("Date et heure"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(y, m, d)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                    }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text(dateText, style = MaterialTheme.typography.labelLarge) }
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(Calendar.HOUR_OF_DAY, h)
                                set(Calendar.MINUTE, m)
                                set(Calendar.SECOND, 0)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text(timeText, style = MaterialTheme.typography.labelLarge) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Définir une heure de fin"), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = hasEndTime, onCheckedChange = { enabled ->
                                hasEndTime = enabled
                                if (enabled && endTime <= selectedTime) endTime = selectedTime + 60L * 60L * 1000L
                            })
                        }
                        if (hasEndTime) {
                            val endCalendar = Calendar.getInstance().apply { timeInMillis = endTime }
                            OutlinedButton(onClick = {
                                TimePickerDialog(context, { _, h, m ->
                                    val c = Calendar.getInstance().apply {
                                        timeInMillis = selectedTime
                                        set(Calendar.HOUR_OF_DAY, h)
                                        set(Calendar.MINUTE, m)
                                        set(Calendar.SECOND, 0)
                                        set(Calendar.MILLISECOND, 0)
                                    }
                                    endTime = c.timeInMillis
                                }, endCalendar.get(Calendar.HOUR_OF_DAY), endCalendar.get(Calendar.MINUTE), true).show()
                            }) {
                                Text(tr("Fin : ") + SimpleDateFormat("HH:mm", uiLocale).format(Date(endTime)))
                            }
                            if (endTime <= selectedTime) {
                                Text(tr("L'heure de fin doit être après l'heure de début."), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                Card(modifier = Modifier.fillMaxWidth().clickable { showRecurrenceOptions = true }) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tr("Récurrence"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            val recurrenceDayLabels = buildList {
                                for (day in recurrenceDays.sorted()) {
                                    add(tr(when (day) {
                                        Calendar.MONDAY -> "Lun"
                                        Calendar.TUESDAY -> "Mar"
                                        Calendar.WEDNESDAY -> "Mer"
                                        Calendar.THURSDAY -> "Jeu"
                                        Calendar.FRIDAY -> "Ven"
                                        Calendar.SATURDAY -> "Sam"
                                        else -> "Dim"
                                    }))
                                }
                            }.joinToString(", ")
                            val recurrenceSummary = when (recurrenceType) {
                                "DAILY" -> tr("Tous les jours")
                                "WEEKLY" -> tr("Toutes les semaines") + " · " + recurrenceDayLabels
                                "MONTHLY" -> tr("Tous les mois")
                                "YEARLY" -> tr("Tous les ans")
                                "CUSTOM" -> tr("Tous les X jours").replace("X", recurrenceInterval)
                                else -> tr("Aucune répétition")
                            }
                            Text(recurrenceSummary, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { showRecurrenceOptions = true }) { Text(tr("Configurer")) }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(tr("Type de rappel"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it }, modifier = Modifier.size(30.dp))
                        Text(tr("Notification"), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    Row(Modifier.weight(1.35f), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it }, modifier = Modifier.size(30.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text(tr("Alarme"), style = MaterialTheme.typography.bodySmall, maxLines = 1, softWrap = false)
                        }
                    }
                }
                if (!notificationEnabled && !alarmEnabled) Text(tr("Sélectionne au moins un type de rappel."), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (notificationEnabled || alarmEnabled) Text(tr("Délai avant l'événement"), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
                val choices = listOf("0" to "À l'heure", "5" to "5 min", "15" to "15 min", "30" to "30 min", "60" to "1 h", "1440" to "La veille", "custom" to "Personnalisé")
                choices.chunked(3).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { (value, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(lead == value, { lead = value }, modifier = Modifier.size(26.dp))
                                Text(tr(label), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                }
                if (lead == "custom") {
                    OutlinedTextField(
                        customLead, { customLead = it.filter(Char::isDigit).take(5) },
                        label = { Text(tr("Minutes avant")) },
                        singleLine = true
                    )
                }
                    }
                }
                if (alarmEnabled) Card {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(tr("Personnaliser l’alarme"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(soundLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val ringtonePickerTitle = tr("Choisir la sonnerie de l’alarme")
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            OutlinedButton(onClick = {
                                val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, ringtonePickerTitle)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                }
                                ringtonePicker.launch(picker)
                            }) { Text(tr("Choisir la sonnerie")) }
                            TextButton(onClick = { soundUri = null }) { Text(tr("Par défaut")) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Vibreur"), modifier = Modifier.weight(1f))
                            Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(tr("Pièces jointes"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        OutlinedButton(onClick = {
                            attachmentPicker.launch(arrayOf("application/pdf", "image/*", "text/*", "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                        }) {
                            Icon(Icons.Default.AttachFile, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(tr("Ajouter une pièce jointe"))
                        }
                        if (attachments.isEmpty()) {
                            Text(tr("Aucune pièce jointe."), style = MaterialTheme.typography.bodySmall)
                        } else {
                            attachments.forEach { attachment ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text(attachment.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                    IconButton(onClick = { attachments = attachments.filterNot { it.id == attachment.id } }) {
                                        Icon(Icons.Default.Close, contentDescription = tr("Retirer la pièce jointe"))
                                    }
                                }
                            }
                        }
                    }
                }
                if (error) Text(tr("Saisissez un titre, une date future et un délai valide."), color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val minutes = if (lead == "custom") customLead.toIntOrNull() else lead.toIntOrNull()
                if (title.isBlank() || (initialEvent == null && selectedTime <= System.currentTimeMillis()) || minutes == null || minutes < 0 ||
                    (hasEndTime && endTime <= selectedTime) || (!notificationEnabled && !alarmEnabled) || (recurrenceType != "NONE" && (recurrenceInterval.toIntOrNull() == null || recurrenceInterval.toIntOrNull()!! < 1)) || (recurrenceType == "WEEKLY" && recurrenceDays.isEmpty()) || (recurrenceEndMode == "COUNT" && (recurrenceCount.toIntOrNull() == null || recurrenceCount.toIntOrNull()!! < 1))) {
                    error = true
                } else {
                    val mode = when { notificationEnabled && alarmEnabled -> "both"; alarmEnabled -> "alarm"; else -> "notification" }
                    onSave(title.trim(), description.trim(), selectedTime, if (hasEndTime) endTime else null, mode, minutes, soundUri, vibrate, attachments, selectedEventColor, recurrenceType, recurrenceInterval.toIntOrNull() ?: 1, if (recurrenceType == "WEEKLY") recurrenceDays else emptyList(), null, if (recurrenceType != "NONE" && recurrenceEndMode == "COUNT") recurrenceCount.toIntOrNull() else null)
                }
            }) { Text(tr("Enregistrer")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Annuler")) } }
    )

    if (showRecurrenceOptions) {
        AlertDialog(
            onDismissRequest = { showRecurrenceOptions = false },
            title = { Text(tr("Options de récurrence"), fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val recurrenceLabels = listOf("NONE" to tr("Aucune répétition"), "DAILY" to tr("Tous les jours"), "WEEKLY" to tr("Toutes les semaines"), "MONTHLY" to tr("Tous les mois"), "YEARLY" to tr("Tous les ans"), "CUSTOM" to tr("Tous les X jours"))
                    recurrenceLabels.forEach { (value, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { recurrenceType = value }) {
                            RadioButton(selected = recurrenceType == value, onClick = { recurrenceType = value })
                            Text(label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    if (recurrenceType != "NONE") {
                        OutlinedTextField(
                            value = recurrenceInterval,
                            onValueChange = { recurrenceInterval = it.filter(Char::isDigit).take(3) },
                            label = { Text(tr(if (recurrenceType == "CUSTOM") "Répéter tous les X jours" else "Répéter tous les X ${if (recurrenceType == "WEEKLY") "semaines" else if (recurrenceType == "MONTHLY") "mois" else if (recurrenceType == "YEARLY") "ans" else "jours"}")) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (recurrenceType == "WEEKLY") {
                            Text(tr("Jours de la semaine"), fontWeight = FontWeight.SemiBold)
                            val weekDays = listOf(Calendar.MONDAY to "Lun", Calendar.TUESDAY to "Mar", Calendar.WEDNESDAY to "Mer", Calendar.THURSDAY to "Jeu", Calendar.FRIDAY to "Ven", Calendar.SATURDAY to "Sam", Calendar.SUNDAY to "Dim")
                            weekDays.chunked(4).forEach { row ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    row.forEach { (day, label) ->
                                        FilterChip(
                                            selected = day in recurrenceDays,
                                            onClick = { recurrenceDays = if (day in recurrenceDays) recurrenceDays - day else recurrenceDays + day },
                                            label = { Text(tr(label)) }
                                        )
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { recurrenceDays = weekDays.map { it.first } }) { Text(tr("Tous")) }
                                TextButton(onClick = { recurrenceDays = weekDays.take(5).map { it.first } }) { Text(tr("Lun–Ven")) }
                                TextButton(onClick = { recurrenceDays = emptyList() }) { Text(tr("Effacer")) }
                            }
                            if (recurrenceDays.isEmpty()) Text(tr("Sélectionne au moins un jour."), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(tr("Fin de répétition"), fontWeight = FontWeight.SemiBold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            listOf("NEVER" to "Jamais", "COUNT" to "Après X fois").forEach { (v, label) ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    RadioButton(selected = recurrenceEndMode == v, onClick = { recurrenceEndMode = v })
                                    Text(tr(label), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        if (recurrenceEndMode == "COUNT") OutlinedTextField(
                            value = recurrenceCount,
                            onValueChange = { recurrenceCount = it.filter(Char::isDigit).take(4) },
                            label = { Text(tr("Nombre d'occurrences")) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showRecurrenceOptions = false }) { Text(tr("Valider")) } },
            dismissButton = { TextButton(onClick = { showRecurrenceOptions = false }) { Text(tr("Annuler")) } }
        )
    }
}

