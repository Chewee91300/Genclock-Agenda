Bellendar 1.0.6

Ajout d'une rubrique Paramètres > Import / Export Outlook.
- Import d'un fichier iCalendar (.ics) via le sélecteur de fichiers Android.
- Fusion avec les événements existants et détection des doublons par titre, date/heure et description.
- Export des événements Bellendar au format .ics compatible Outlook.
- Export des récurrences quotidiennes, hebdomadaires, mensuelles et annuelles simples.
- Traductions de la nouvelle interface et des messages en anglais, espagnol, allemand et portugais (Portugal).

Limites : échange manuel par fichier, sans synchronisation automatique Microsoft. Les règles de récurrence personnalisées, exceptions, pièces jointes, alarmes et couleurs ne sont pas transportées par ce premier échange .ics.
