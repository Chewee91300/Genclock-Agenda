Bellendar – Version 2.1.4

Modification : le bouton flottant « + » est masqué en mode Semaine.
L'ajout d'un rendez-vous reste accessible directement depuis la grille
hebdomadaire en sélectionnant le créneau souhaité.

Le bouton + reste disponible dans les autres modes d'affichage.
Version Android : versionName 2.1.4 / versionCode 102.

La compilation Android doit être vérifiée avec le workflow GitHub Actions.
