Bellendar 2.5.6
VersionCode: 135

Correction de compilation du zoom par pincement : suppression de l’import incorrect de awaitPointerEvent. Cette fonction est disponible comme membre du scope de détection de gestes Compose utilisé par awaitEachGesture.

Le traitement du zoom et les gestes sont conservés.
Compilation Android complète non exécutée dans cet environnement. Vérifier avec GitHub Actions.
