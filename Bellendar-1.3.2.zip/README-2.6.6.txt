Bellendar — version 2.6.6 (versionCode 145)

Modifications :
- Nouveau logo Bellendar dans les ressources de l’application.
- Icône Android mise à jour pour les densités mdpi, hdpi, xhdpi, xxhdpi et xxxhdpi.
- Identifiant Android conservé : fr.bellendar.
- Données et sauvegardes existantes conservées.

Compilation Android à confirmer avec GitHub Actions.
