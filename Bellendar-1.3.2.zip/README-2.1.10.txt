Bellendar — version 2.1.10
VersionCode Android : 108

Optimisations de la fiche événement :
- Marges intérieures et espacements verticaux légèrement réduits.
- Libellé d'alarme raccourci en « Alarme » avec une icône dédiée, sur une seule ligne.
- Contrôles de sélection de rappel légèrement resserrés.
- Choix des délais, pièces jointes, date/heure, couleurs et options existantes conservés.
- Barre de validation et défilement de la fiche conservés.

La compilation Android doit être validée par GitHub Actions.
