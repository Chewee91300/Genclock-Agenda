Bellendar 2.4.0 – Récurrence

Ajouts :
- Règles quotidiennes, hebdomadaires (sélection des jours), mensuelles, annuelles et personnalisées en nombre de jours.
- Intervalle configurable.
- Fin après un nombre d'occurrences ou sans fin.
- Persistance des paramètres de récurrence dans le JSON local et la sauvegarde externe ; les anciens événements sans ces champs restent compatibles.
- Génération à la demande des occurrences sur 400 jours pour l'affichage.
- Programmation des rappels dans une fenêtre glissante de 180 jours ; reconstruction après redémarrage/changement d'heure via BootReceiver.
- Couleurs, alarmes, vibration et pièces jointes sont héritées par les occurrences.

Limites à valider avant diffusion :
- La date de fin personnalisée n'est pas encore exposée dans l'interface.
- La modification/suppression d'une occurrence isolée ou d'une série complète (exceptions) n'est pas encore implémentée : une occurrence générée ne doit pas être utilisée pour éditer une série en production.
- Les occurrences sont calculées et leurs rappels préprogrammés sur 180 jours ; la programmation continue au-delà de cette fenêtre doit être renouvelée.
- Compilation Android et essais sur appareil à effectuer via GitHub Actions.
