Bellendar 2.7.0
VersionCode : 149

- Ajout de l'espagnol comme troisième langue proposée au premier démarrage et dans les paramètres.
- Ajout de traductions espagnoles pour les libellés principaux, les formulaires, les rappels, les vues d'agenda et plusieurs rubriques d'aide.
- Locale espagnole utilisée pour les formats de dates et heures.
- Écran d'alarme traduit en espagnol.
- Français et anglais conservés.

Note : les traductions sont intégrées dans UiTranslations.kt. Une vérification complète de tous les libellés affichés et de la compilation doit être effectuée sur GitHub Actions et sur appareil.
