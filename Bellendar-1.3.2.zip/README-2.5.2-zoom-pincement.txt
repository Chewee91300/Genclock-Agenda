Bellendar 2.5.2 – Zoom du planning hebdomadaire

- Zoom vertical par pincement/écartement de deux doigts directement sur la grille de la semaine.
- Aucun bouton ajouté à l'interface.
- Le niveau minimum reste l'échelle d'origine (1x) ; il est impossible de dézoomer en dessous.
- Agrandissement progressif jusqu'à 3x.
- Le niveau choisi est mémorisé dans les préférences de l'application.
- Les durées et positions temporelles des événements restent proportionnelles à l'échelle.
- Le zoom ne concerne que le mode semaine.

Version Android : 2.5.2 (versionCode 131).
Compilation Android complète non exécutée dans cet environnement.
