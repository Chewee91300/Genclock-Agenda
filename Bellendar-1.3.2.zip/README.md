# Bellendar — version 1.3.2

Application Android native développée en Kotlin et Jetpack Compose.

## Identification de la version
- `versionName` : **1.3.2**
- `versionCode` : **50**
- Identifiant Android : `fr.bellendar`
- SDK de compilation : 35
- SDK minimum : 26
- Java : 17

## Contenu de cette archive
Cette archive correspond à la base source Bellendar 1.3.2. Les notes et fichiers portant un numéro de version différent sont des documents historiques conservés pour retracer les évolutions antérieures ; ils ne définissent pas la version de l'application contenue dans cette archive.

La création d'événements depuis les vues Jour et Semaine se déclenche par double-clic sur la grille horaire. Un rectangle de sélection persistant apparaît avec deux poignées tactiles de redimensionnement par pas de 15 minutes ; les heures de début et de fin sont répercutées dans l'éditeur. Le panneau inférieur présente un en-tête en état réduit et le formulaire complet après glissement vers le haut. La sélection est masquée à la fermeture ou à l'annulation.

## Construire l'APK
1. Ouvrir le dossier du projet dans Android Studio avec un JDK 17.
2. Laisser Android Studio synchroniser Gradle.
3. Lancer **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. L'APK debug est normalement généré dans `app/build/outputs/apk/debug/app-debug.apk`.

Le projet ne contient pas de Gradle Wrapper dans cette archive. La compilation doit donc être lancée depuis Android Studio avec une installation Gradle compatible, ou après ajout d'un wrapper adapté.

## Compilation GitHub Actions
Le workflow `.github/workflows/android-apk.yml`, s'il est présent dans le dépôt, peut être lancé depuis l'onglet **Actions** de GitHub. La réussite de la compilation doit être vérifiée dans le journal de l'exécution ; elle n'est pas présumée par la seule présence du workflow.

## Notes de version
Le journal de cette version est disponible dans `CHANGELOG-1.3.2.txt`. Les fichiers `README-*` et `CHANGELOG-*` portant d'autres numéros sont conservés comme documentation historique et ne doivent pas être renommés artificiellement en 1.3.2.
