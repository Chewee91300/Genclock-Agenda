Bellendar 1.1.38

Création dimensionnée d'événements :
- Dans les vues Jour et Semaine, maintenir le doigt sur une zone vide puis glisser verticalement.
- Le cadre de sélection matérialise la durée choisie.
- La sélection est arrondie au quart d'heure.
- Au relâchement, le formulaire de création s'ouvre avec les heures de début et de fin préremplies.
- Le double-appui conserve la création rapide à une heure précise.
