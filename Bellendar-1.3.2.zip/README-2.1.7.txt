Bellendar – version 2.1.7
versionCode : 105

Optimisation verticale de la fiche événement :
- Espacements et marges internes réduits.
- Champs titre et description plus compacts.
- Palette de couleurs plus compacte, sans texte explicatif redondant.
- Sections date/heure, rappels, sonnerie et pièces jointes resserrées.
- Aide descriptive superflue retirée de la fiche ; les fonctions restent disponibles.

Base : version 2.1.6. Les fonctionnalités existantes sont conservées.
Compilation Android à vérifier avec GitHub Actions.
