Bellendar 2.7.2
VersionCode: 151
Base: Bellendar 2.7.1

Correctifs de traduction espagnole :
- Traduction des invites et commandes de dictée vocale.
- Traduction des options et fréquences de récurrence.
- Traduction complète des sections du guide d'aide.
- Traduction des libellés de paramètres et des autorisations affichées dans les captures.
- Mise à jour de l'aide pour mentionner le français, l'anglais et l'espagnol.

Les traductions françaises et anglaises sont conservées. Identifiant Android inchangé : fr.bellendar.
Compilation Gradle non exécutée dans cet environnement ; validation GitHub Actions nécessaire.
