package fr.bellendar

import java.util.Calendar

/** Opérations de série sur les événements stockés (et non sur leurs occurrences virtuelles). */
object RecurrenceManager {
    enum class Scope { THIS, THIS_AND_FOLLOWING, ENTIRE_SERIES }

    fun seriesMaster(events: List<AgendaEvent>, occurrence: AgendaEvent): AgendaEvent? {
        val id = occurrence.seriesId ?: occurrence.id
        return events.firstOrNull { it.id == id && it.recurrenceType != "NONE" }
    }

    fun delete(events: List<AgendaEvent>, occurrence: AgendaEvent, scope: Scope): List<AgendaEvent> {
        val master = seriesMaster(events, occurrence) ?: return events.filterNot { it.id == occurrence.id }
        val original = occurrence.originalOccurrenceMillis ?: occurrence.timeMillis
        return when (scope) {
            Scope.ENTIRE_SERIES -> events.filterNot { it.id == master.id || it.seriesId == master.id }
            Scope.THIS -> events.mapNotNull { item ->
                when {
                    item.id == master.id -> item.copy(recurrenceExcludedMillis = (item.recurrenceExcludedMillis + original).distinct())
                    item.seriesId == master.id && item.originalOccurrenceMillis == original -> null
                    else -> item
                }
            }
            Scope.THIS_AND_FOLLOWING -> events.filterNot {
                it.id == master.id || (it.seriesId == master.id && (it.originalOccurrenceMillis ?: Long.MIN_VALUE) >= original)
            } + master.copy(
                recurrenceEndMillis = original - 1L,
                recurrenceCount = null
            ).let { it }
        }
    }

    /** Remplace une occurrence sans toucher aux autres dates de la série. */
    fun replaceOccurrence(events: List<AgendaEvent>, occurrence: AgendaEvent, edited: AgendaEvent): List<AgendaEvent> {
        val master = seriesMaster(events, occurrence) ?: return events.filterNot { it.id == occurrence.id } + edited
        val original = occurrence.originalOccurrenceMillis ?: occurrence.timeMillis
        val override = edited.copy(
            id = stableOverrideId(master.id, original),
            recurrenceType = "NONE",
            recurrenceInterval = 1,
            recurrenceDays = emptyList(),
            recurrenceEndMillis = null,
            recurrenceCount = null,
            seriesId = master.id,
            originalOccurrenceMillis = original,
            recurrenceExcludedMillis = emptyList()
        )
        val updatedMaster = master.copy(recurrenceExcludedMillis = (master.recurrenceExcludedMillis + original).distinct())
        return events.filterNot { it.id == master.id || (it.seriesId == master.id && it.originalOccurrenceMillis == original) } + updatedMaster + override
    }

    /** Coupe l'ancienne série avant la date choisie et crée une nouvelle série à partir de l'événement modifié. */
    fun replaceFollowing(events: List<AgendaEvent>, occurrence: AgendaEvent, edited: AgendaEvent): List<AgendaEvent> {
        val master = seriesMaster(events, occurrence) ?: return events.filterNot { it.id == occurrence.id } + edited
        val original = occurrence.originalOccurrenceMillis ?: occurrence.timeMillis
        val previous = previousOccurrence(master, original)
        val occurrencesBefore = RecurrenceEngine.expand(listOf(master), master.timeMillis, original - 1L).size
        val remainingCount = master.recurrenceCount?.let { (it - occurrencesBefore).coerceAtLeast(1) }
        val shortened = master.copy(recurrenceEndMillis = previous ?: (original - 1L), recurrenceCount = null)
        val newMaster = edited.copy(
            id = stableOverrideId(master.id, original),
            recurrenceType = master.recurrenceType,
            recurrenceInterval = master.recurrenceInterval,
            recurrenceDays = master.recurrenceDays,
            recurrenceEndMillis = master.recurrenceEndMillis,
            recurrenceCount = remainingCount,
            seriesId = null,
            originalOccurrenceMillis = null,
            recurrenceExcludedMillis = emptyList()
        )
        return events.filterNot { it.id == master.id || (it.seriesId == master.id && (it.originalOccurrenceMillis ?: Long.MIN_VALUE) >= original) } + shortened + newMaster
    }

    private fun previousOccurrence(master: AgendaEvent, before: Long): Long? {
        val start = master.timeMillis
        if (before <= start) return null
        val occurrences = RecurrenceEngine.expand(listOf(master), start, before - 1L)
        return occurrences.lastOrNull()?.timeMillis
    }

    private fun stableOverrideId(seriesId: Long, original: Long): Long {
        val value = (seriesId * 37L) xor (original / 60_000L) xor Long.MIN_VALUE
        return if (value == 0L || value == seriesId) value + 1L else value
    }
}
