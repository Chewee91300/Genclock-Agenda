package fr.bellendar

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Calendar

/**
 * Développe les règles de récurrence à la demande.
 * Les occurrences restent virtuelles : elles ne sont pas dupliquées dans le stockage.
 */
object RecurrenceEngine {
    private const val MAX_OCCURRENCES_PER_EVENT = 20_000
    private val zone: ZoneId
        get() = ZoneId.systemDefault()

    fun expand(
        events: List<AgendaEvent>,
        fromMillis: Long,
        untilMillis: Long,
        overriddenDates: Set<Long> = emptySet()
    ): List<AgendaEvent> {
        if (untilMillis < fromMillis) return emptyList()

        val overrides = events.filter { it.seriesId != null && it.originalOccurrenceMillis != null }
        val persistedOverrides = overrides.groupBy { it.seriesId!! }
            .mapValues { (_, values) -> values.mapNotNull { it.originalOccurrenceMillis }.toSet() }
        return buildList {
            events.forEach { event ->
                when {
                    event.recurrenceType != "NONE" -> addAll(expandSeries(event, fromMillis, untilMillis,
                        overriddenDates + persistedOverrides[event.id].orEmpty()))
                    event.seriesId != null -> {
                        if (event.timeMillis in fromMillis..untilMillis) add(event)
                    }
                    event.timeMillis in fromMillis..untilMillis -> add(event)
                }
            }
        }.distinctBy { it.id }.sortedBy { it.timeMillis }
    }

    private fun expandSeries(
        event: AgendaEvent,
        fromMillis: Long,
        untilMillis: Long,
        overriddenDates: Set<Long> = emptySet()
    ): List<AgendaEvent> {
        val start = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(event.timeMillis), zone)
        val startDate = start.toLocalDate()
        val startTime = start.toLocalTime()
        val duration = event.endTimeMillis?.minus(event.timeMillis)?.coerceAtLeast(0L)
        val interval = event.recurrenceInterval.coerceAtLeast(1)
        val result = mutableListOf<AgendaEvent>()
        var occurrenceIndex = 0
        var date = startDate
        var inspected = 0

        while (inspected++ < MAX_OCCURRENCES_PER_EVENT) {
            val occurrenceMillis = date.atTime(startTime).atZone(zone).toInstant().toEpochMilli()
            if (occurrenceMillis > untilMillis) break
            if (event.recurrenceEndMillis != null && occurrenceMillis > event.recurrenceEndMillis) break
            if (event.recurrenceCount != null && occurrenceIndex >= event.recurrenceCount) break

            if (matches(event, startDate, date, interval)) {
                if (occurrenceMillis >= fromMillis &&
                    occurrenceMillis !in event.recurrenceExcludedMillis && occurrenceMillis !in overriddenDates) {
                    val occurrenceId = if (occurrenceIndex == 0) event.id
                    else stableOccurrenceId(event.id, occurrenceMillis)
                    result += event.copy(
                        id = occurrenceId,
                        timeMillis = occurrenceMillis,
                        endTimeMillis = duration?.let { occurrenceMillis + it },
                        recurrenceType = "NONE",
                        seriesId = event.id,
                        originalOccurrenceMillis = occurrenceMillis,
                        recurrenceExcludedMillis = emptyList()
                    )
                }
                occurrenceIndex++
            }
            date = date.plusDays(1)
        }
        return result
    }

    private fun matches(
        event: AgendaEvent,
        anchor: LocalDate,
        candidate: LocalDate,
        interval: Int
    ): Boolean {
        val daysFromStart = java.time.temporal.ChronoUnit.DAYS.between(anchor, candidate)
        if (daysFromStart < 0) return false

        return when (event.recurrenceType) {
            "DAILY", "CUSTOM" -> daysFromStart % interval == 0L
            "WEEKLY" -> {
                val anchorMonday = anchor.with(java.time.temporal.TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val candidateMonday = candidate.with(java.time.temporal.TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val weeks = java.time.temporal.ChronoUnit.WEEKS.between(anchorMonday, candidateMonday)
                val selectedDays = event.recurrenceDays
                weeks % interval == 0L &&
                    if (selectedDays.isEmpty()) candidate.dayOfWeek == anchor.dayOfWeek
                    else candidate.toCalendarDayOfWeek() in selectedDays
            }
            "MONTHLY" -> {
                val months = java.time.temporal.ChronoUnit.MONTHS.between(
                    YearMonth.from(anchor), YearMonth.from(candidate)
                )
                months >= 0 && months % interval == 0L &&
                    candidate.dayOfMonth == minOf(anchor.dayOfMonth, YearMonth.from(candidate).lengthOfMonth())
            }
            "YEARLY" -> {
                val years = candidate.year - anchor.year
                years >= 0 && years % interval == 0 &&
                    candidate.monthValue == anchor.monthValue &&
                    candidate.dayOfMonth == minOf(anchor.dayOfMonth, YearMonth.of(candidate.year, candidate.monthValue).lengthOfMonth())
            }
            else -> false
        }
    }

    private fun LocalDate.toCalendarDayOfWeek(): Int = when (dayOfWeek) {
        DayOfWeek.SUNDAY -> Calendar.SUNDAY
        DayOfWeek.MONDAY -> Calendar.MONDAY
        DayOfWeek.TUESDAY -> Calendar.TUESDAY
        DayOfWeek.WEDNESDAY -> Calendar.WEDNESDAY
        DayOfWeek.THURSDAY -> Calendar.THURSDAY
        DayOfWeek.FRIDAY -> Calendar.FRIDAY
        DayOfWeek.SATURDAY -> Calendar.SATURDAY
        else -> Calendar.MONDAY
    }

    private fun stableOccurrenceId(seriesId: Long, occurrenceMillis: Long): Long {
        // Identifiant déterministe pour qu'une même occurrence soit reconnue au fil des affichages.
        var value = seriesId * 31L + occurrenceMillis / 60_000L
        if (value == 0L || value == seriesId) value = value xor Long.MIN_VALUE
        return value
    }
}
