package fr.bellendar

import android.content.Context

/**
 * Point d'entrée unique des opérations métier sur l'agenda.
 * La couche Compose ne décide plus directement comment persister les événements.
 */
class AgendaRepository(context: Context) {
    private val appContext = context.applicationContext
    private val store = EventStore(appContext)

    fun load(): List<AgendaEvent> = store.load()

    fun save(events: List<AgendaEvent>) {
        store.save(events.sortedBy { it.timeMillis })
    }

    fun saveAndSchedule(event: AgendaEvent, previous: AgendaEvent? = null): Boolean {
        previous?.let { cancelSeries(it) }
        val current = (load().filterNot { it.id == event.id } + event).sortedBy { it.timeMillis }
        save(current)
        return scheduleSeries(event, current)
    }

    fun scheduleSeries(event: AgendaEvent, related: List<AgendaEvent> = load()): Boolean =
        ReminderScheduler.scheduleSeries(appContext, event, related)

    fun cancel(event: AgendaEvent) = ReminderScheduler.cancel(appContext, event)

    fun cancelSeries(event: AgendaEvent) = ReminderScheduler.cancelSeries(appContext, event)

    fun rescheduleAll(events: List<AgendaEvent>) {
        events.filter { it.recurrenceType != "NONE" }.forEach { scheduleSeries(it, events) }
        events.filter { it.seriesId != null }.forEach { item ->
            if (item.reminderMode == "notification" || item.reminderMode == "both") {
                ReminderScheduler.schedule(appContext, item)
            }
            if (item.reminderMode == "alarm" || item.reminderMode == "both") {
                ReminderScheduler.scheduleAlarm(appContext, item)
            }
        }
    }
}
