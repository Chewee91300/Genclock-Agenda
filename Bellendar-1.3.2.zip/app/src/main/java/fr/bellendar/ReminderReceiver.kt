package fr.bellendar

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val language = context.getSharedPreferences("interface", Context.MODE_PRIVATE).getString("app_language", "fr") ?: "fr"
            val isEnglish = language == "en"
            val isGerman = language == "de"
            val isSpanish = language == "es"
            val isPortuguese = language == "pt"
            val channelId = "agenda_reminders_v3"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
                manager.createNotificationChannel(NotificationChannel(channelId, when { isEnglish -> "Bellendar reminders"; isGerman -> "Bellendar-Erinnerungen"; isSpanish -> "Recordatorios de Bellendar"; isPortuguese -> "Lembretes Bellendar"; else -> "Rappels Bellendar" }, NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(sound, attrs); enableVibration(true)
                })
            }
            val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(intent.getStringExtra("title") ?: when { isEnglish -> "Reminder"; isGerman -> "Erinnerung"; isSpanish -> "Recordatorio"; isPortuguese -> "Lembrete"; else -> "Rappel" })
                .setContentText(intent.getStringExtra("description") ?: when { isEnglish -> "Your event is scheduled now."; isGerman -> "Dein Termin ist jetzt geplant."; isSpanish -> "Tu evento está programado para ahora."; isPortuguese -> "O seu evento está agendado para agora."; else -> "Votre événement est prévu maintenant." })
                .setCategory(NotificationCompat.CATEGORY_REMINDER).setAutoCancel(true).setContentIntent(open).build()
            manager.notify(intent.getLongExtra("eventId", 0L).hashCode(), n)
        } catch (_: Exception) { }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val service = Intent(context, AlarmPlaybackService::class.java).apply {
            putExtras(intent)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
            else context.startService(service)
        } catch (_: Exception) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val supported = action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        if (!supported) return

        // AlarmManager ne conserve pas les alarmes après un redémarrage.
        // Pour une série, il ne faut surtout pas filtrer sur l'alarme du maître :
        // celle-ci peut être passée alors que des occurrences futures existent.
        val pendingResult = goAsync()
        Thread {
            try {
                val appContext = context.applicationContext
                val storedEvents = EventStore(appContext).load()
                val now = System.currentTimeMillis()

                storedEvents.filter { it.recurrenceType != "NONE" }.forEach { master ->
                    ReminderScheduler.scheduleSeries(appContext, master, storedEvents)
                }

                // Les événements indépendants et les occurrences modifiées individuellement
                // sont reprogrammés séparément. Les occurrences virtuelles de la série sont
                // prises en charge par scheduleSeries et ne sont pas dupliquées ici.
                storedEvents.asSequence()
                    .filter { it.recurrenceType == "NONE" }
                    .filter { it.seriesId == null }
                    .filter { item ->
                        val trigger = item.alarmTimeMillis
                            ?: (item.timeMillis - item.leadMinutes * 60_000L)
                        trigger > now
                    }
                    .forEach { item ->
                        if (item.reminderMode == "notification" || item.reminderMode == "both") {
                            ReminderScheduler.schedule(appContext, item)
                        }
                        if (item.reminderMode == "alarm" || item.reminderMode == "both") {
                            ReminderScheduler.scheduleAlarm(appContext, item)
                        }
                    }
            } catch (_: Exception) {
                // Ne jamais faire planter le processus système de réception.
            } finally {
                pendingResult.finish()
            }
        }.start()
    }
}
