package fr.bellendar

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

internal fun isFrenchPublicHoliday(date: Calendar): Boolean {
    val year = date.get(Calendar.YEAR)
    val month = date.get(Calendar.MONTH) + 1
    val day = date.get(Calendar.DAY_OF_MONTH)
    val fixed = setOf("1-1", "5-1", "5-8", "7-14", "8-15", "11-1", "11-11", "12-25")
    if ("$month-$day" in fixed) return true
    val easter = easterSunday(year)
    val easterMonday = easter.plusDays(1)
    val ascension = easter.plusDays(39)
    val whitMonday = easter.plusDays(50)
    val current = java.time.LocalDate.of(year, month, day)
    return current == easterMonday || current == ascension || current == whitMonday
}

internal fun easterSunday(year: Int): java.time.LocalDate {
    val a = year % 19
    val b = year / 100
    val c = year % 100
    val d = b / 4
    val e = b % 4
    val f = (b + 8) / 25
    val g = (b - f + 1) / 3
    val h = (19 * a + b - d - g + 15) % 30
    val i = c / 4
    val k = c % 4
    val l = (32 + 2 * e + 2 * i - h - k) % 7
    val m = (a + 11 * h + 22 * l) / 451
    val month = (h + l - 7 * m + 114) / 31
    val day = (h + l - 7 * m + 114) % 31 + 1
    return java.time.LocalDate.of(year, month, day)
}

@Composable
internal fun MonthAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, onOpenDay: (Long) -> Unit, expanded: Boolean) {
    val uiLocale = currentUiLocale()
    val localizedWeekdays = DateFormatSymbols(uiLocale).shortWeekdays
    val weekdayLabels = if (uiLocale == Locale.FRANCE) listOf("L", "M", "M", "J", "V", "S", "D") else listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY).map { day -> localizedWeekdays[day].replace(".", "").take(2).uppercase(uiLocale) }
    val month = Calendar.getInstance().apply { timeInMillis = selected; set(Calendar.DAY_OF_MONTH, 1); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
    val offset = (month.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY + 7) % 7
    val days = (0 until offset).map { 0 } + (1..month.getActualMaximum(Calendar.DAY_OF_MONTH)).toList()
    val weeks = days.chunked(7)
    Card(Modifier.fillMaxWidth().padding(top = 1.dp, bottom = 3.dp), shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(5.dp)) {
        Column(Modifier.padding(horizontal = 5.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp)).padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Sem."), Modifier.width(48.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                weekdayLabels.forEachIndexed { i, label ->
                    Text(label, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold,
                        color = when(i) { 5 -> Color(0xFF1769D2); 6 -> Color(0xFFD52E2E); else -> MaterialTheme.colorScheme.onSurface })
                }
            }
            weeks.forEachIndexed { wi, week ->
                Row(Modifier.fillMaxWidth().height(if (expanded) 43.dp else 38.dp), verticalAlignment = Alignment.CenterVertically) {
                    val weekStart = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; add(Calendar.DAY_OF_MONTH, wi * 7 - offset); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
                    Box(Modifier.width(48.dp).fillMaxHeight().padding(vertical = 3.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text(weekStart.get(Calendar.WEEK_OF_YEAR).toString(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                    week.forEach { n ->
                        Box(Modifier.weight(1f).fillMaxHeight().padding(2.dp), contentAlignment = Alignment.Center) {
                            if (n > 0) {
                                val date = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; set(Calendar.DAY_OF_MONTH, n) }
                                val hasNotification = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "notification" }
                                val hasAlarm = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "alarm" }
                                val hasBoth = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "both" }
                                val selectedDate = sameDay(date.timeInMillis, selected)
                                val dayColor = when { isFrenchPublicHoliday(date) || date.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY -> Color(0xFFD52E35); date.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY -> Color(0xFF1769D2); else -> MaterialTheme.colorScheme.onSurface }
                                Surface(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .pointerInput(date.timeInMillis) {
                                            detectTapGestures(
                                                onDoubleTap = { onOpenDay(date.timeInMillis) },
                                                onTap = { onSelectDay(date.timeInMillis) }
                                            )
                                        }
                                        .then(if (selectedDate) Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp)) else Modifier),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Transparent
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = dayColor, fontWeight = if (selectedDate || isFrenchPublicHoliday(date)) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp, lineHeight = 16.sp)
                                        // Réserve toujours la même hauteur sous le numéro :
                                        // l'apparition des points ne déplace jamais le chiffre.
                                        Box(Modifier.height(10.dp), contentAlignment = Alignment.Center) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                                if (hasNotification) Text("•", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                                if (hasAlarm) Text("•", color = Color(0xFFD52E35), style = MaterialTheme.typography.labelSmall)
                                                if (hasBoth) Text("•", color = Color(0xFF8E44AD), style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                }
                if (wi < weeks.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.7.dp)
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(start = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("●", color = MaterialTheme.colorScheme.primary); Text(tr(" Notification"), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.width(18.dp)); Text("●", color = Color(0xFFD52E35)); Text(tr(" Alarme"), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.width(18.dp)); Text("●", color = Color(0xFF8E44AD)); Text(tr(" Les deux"), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
    }
}

