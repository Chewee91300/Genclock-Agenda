package fr.bellendar

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
internal fun WeeklyPaperAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, onEditEvent: (AgendaEvent) -> Unit, fullScreen: Boolean = false, modifier: Modifier = Modifier) {
    val uiLocale = currentUiLocale()
    val weekStart = Calendar.getInstance().apply {
        timeInMillis = dayStart(selected).timeInMillis
        firstDayOfWeek = Calendar.MONDAY
        minimalDaysInFirstWeek = 4
        set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    }
    val days = (0..6).map { offset -> Calendar.getInstance().apply { timeInMillis = weekStart.timeInMillis; add(Calendar.DAY_OF_MONTH, offset) } }
    BoxWithConstraints(modifier.fillMaxWidth().then(if (fullScreen) Modifier.fillMaxHeight() else Modifier.heightIn(max = 560.dp))) {
        val columnWidth = if (fullScreen || maxWidth >= 700.dp) (maxWidth - 68.dp) / 7 else 116.dp
        val paper = Color.Transparent
        val ink = Color(0xFF142B45)
        val grid = Color(0xFF71879B)
        // Pastels suffisamment soutenus pour rester visibles sur le papier clair.
        val eventPalette = listOf(Color(0xFF8FC5F2), Color(0xFFF2D477), Color(0xFFF0A0A8), Color(0xFFA6D99A), Color(0xFFC2AFE9), Color(0xFF91D8D4))
        // Échelle uniforme : chaque heure possède exactement la même hauteur.
        // Les événements seront positionnés à la minute près sur cette échelle.
        val hourHeight = 72.dp
        val hourHeights = (6..20).associateWith { hourHeight }
        val horizontalModifier = if (fullScreen) Modifier else Modifier.horizontalScroll(rememberScrollState())
        // Aspect véritable agenda papier : couverture cuir, page ivoire texturée et reliure centrale.
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF6B3824), Color(0xFF321A13))), RoundedCornerShape(16.dp)).border(2.dp, Color(0xFF8B5638), RoundedCornerShape(16.dp)).padding(10.dp)) {
            Image(
                painter = painterResource(id = R.drawable.paper_texture),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)).border(1.dp, Color(0xFFD8C5A5), RoundedCornerShape(10.dp))
            )
            Row(Modifier.fillMaxSize().then(horizontalModifier).verticalScroll(rememberScrollState()).padding(5.dp)) {
            Column(Modifier.width(48.dp)) {
                Box(Modifier.height(if (fullScreen) 26.dp else 30.dp).fillMaxWidth().background(Color(0x55FFF9EC)), contentAlignment = Alignment.Center) {
                    Text(tr("Heure"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ink, fontFamily = FontFamily.Serif)
                }
                Column {
                    (6..20).forEach { hour ->
                        Box(Modifier.height(hourHeights.getValue(hour)).fillMaxWidth().background(Color(0x55FFF9EC)).border(0.5.dp, grid), contentAlignment = Alignment.TopCenter) {
                            Text(String.format(Locale.FRANCE, "%02d:00", hour), fontSize = if (fullScreen) 12.sp else 11.sp, fontWeight = FontWeight.SemiBold, color = ink, modifier = Modifier.padding(top = 3.dp))
                        }
                    }
                }
            }
            days.forEach { day ->
                val dayEvents = events.filter { sameDay(it.timeMillis, day.timeInMillis) }.sortedBy { it.timeMillis }
                Column(Modifier.width(columnWidth).background(paper).border(0.7.dp, grid)) {
                    Box(
                        Modifier.fillMaxWidth()
                            .height(if (fullScreen) 26.dp else 30.dp)
                            .background(if (sameDay(day.timeInMillis, selected)) Color(0x88DCE9F7) else Color(0x66FFF9EC))
                            .clickable { onSelectDay(day.timeInMillis) },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            val dayName = SimpleDateFormat("EEEE", uiLocale).format(day.time).replaceFirstChar { it.uppercase() }
                            val dayNumber = SimpleDateFormat("d MMM", uiLocale).format(day.time)
                            val dayColor = when (day.get(Calendar.DAY_OF_WEEK)) {
                                Calendar.SUNDAY -> Color(0xFFD94B50)
                                Calendar.SATURDAY -> Color(0xFF2878C8)
                                else -> ink
                            }
                            Text(dayName, fontSize = if (fullScreen) 12.sp else 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, color = dayColor, fontFamily = FontFamily.Serif)
                            Text(dayNumber, fontSize = if (fullScreen) 11.sp else 10.sp, fontWeight = FontWeight.SemiBold, color = dayColor, fontFamily = FontFamily.Serif)
                        }
                    }
                    Box(
                        Modifier.fillMaxWidth().height(hourHeight * 15)
                            .background(paper)
                    ) {
                        // Lignes horaires : une heure = 72 dp, identique à la colonne de gauche.
                        Column(Modifier.fillMaxSize()) {
                            (6..20).forEach { hour ->
                                Box(
                                    Modifier.fillMaxWidth().height(hourHeight)
                                        .background(Color.Transparent)
                                        .border(0.5.dp, grid.copy(alpha = 0.95f))
                                )
                            }
                        }
                        // Les blocs sont positionnés selon l'heure ET les minutes de début.
                        dayEvents.forEachIndexed { eventIndex, event ->
                            val startCal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                            val startHour = startCal.get(Calendar.HOUR_OF_DAY)
                            val startMinute = startCal.get(Calendar.MINUTE)
                            if (startHour in 6..20) {
                                val minutesFromTop = (startHour - 6) * 60 + startMinute
                                val yPosition = hourHeight * (minutesFromTop / 60f)
                                val durationMinutes = event.endTimeMillis
                                    ?.takeIf { it > event.timeMillis }
                                    ?.let { ((it - event.timeMillis) / 60000L).toInt() }
                                    ?: 0
                                val remainingMinutes = 15 * 60 - minutesFromTop
                                val visibleMinutes = if (durationMinutes > 0) minOf(durationMinutes, remainingMinutes) else 45
                                val eventHeight = if (durationMinutes > 0) {
                                    (hourHeight * (visibleMinutes / 60f)).coerceAtLeast(18.dp)
                                } else 28.dp
                                val eventColor = parseEventColor(event.colorHex) ?: eventPalette[eventIndex.mod(eventPalette.size)]
                                val eventInk = eventTextColor(eventColor)
                                Surface(
                                    onClick = { onEditEvent(event) },
                                    color = eventColor.copy(alpha = 0.97f),
                                    contentColor = eventInk,
                                    shape = RoundedCornerShape(5.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .offset(y = yPosition)
                                        .height(eventHeight)
                                        .padding(horizontal = 2.dp, vertical = 1.dp)
                                        .border(1.dp, Color(0xFF536B83), RoundedCornerShape(5.dp))
                                ) {
                                    Column(
                                        Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 2.dp),
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        val startLabel = SimpleDateFormat("HH:mm", uiLocale).format(Date(event.timeMillis))
                                        val endMillis = event.endTimeMillis?.takeIf { it > event.timeMillis }
                                        if (endMillis == null) {
                                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(event.title.ifBlank { tr("Événement") }, modifier = Modifier.weight(1f), fontSize = if (fullScreen) 11.sp else 10.sp, lineHeight = 11.sp, fontWeight = FontWeight.Bold, color = eventInk, fontFamily = FontFamily.Serif, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(startLabel, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF10243A), maxLines = 1, softWrap = false)
                                            }
                                        } else {
                                            Text(
                                                event.title.ifBlank { "Événement" },
                                                fontSize = if (fullScreen) 11.sp else 10.sp,
                                                lineHeight = if (fullScreen) 12.sp else 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = eventInk,
                                                fontFamily = FontFamily.Serif,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                "$startLabel – ${SimpleDateFormat("HH:mm", uiLocale).format(Date(endMillis))}",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = eventInk,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }
            // Reliure centrale avec anneaux métalliques, dans l'esprit du modèle validé.
            if (fullScreen) {
                val spineX = 48.dp + columnWidth * 3
                Box(Modifier.offset(x = spineX - 5.dp).fillMaxHeight().width(10.dp).background(Brush.horizontalGradient(listOf(Color(0x55301810), Color(0xCC6E4934), Color(0x55301810)))))
                Column(Modifier.offset(x = spineX - 9.dp).fillMaxHeight().padding(vertical = 34.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                    repeat(6) {
                        Box(Modifier.size(width = 18.dp, height = 8.dp).background(Brush.verticalGradient(listOf(Color(0xFFE6E0D4), Color(0xFF4B4A46), Color(0xFFD8D1C4))), RoundedCornerShape(5.dp)).border(0.7.dp, Color(0xFF51463B), RoundedCornerShape(5.dp)))
                    }
                }
            }
        }
    }
    if (!fullScreen) Text(tr("Vue agenda papier · ouvrez le plein écran pour afficher les 7 jours simultanément."), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
}

// Jours fériés légaux en France métropolitaine, calculés pour chaque année.
