package fr.bellendar

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Import/export iCalendar (.ics) compatible Outlook. */
object IcsCalendarCodec {
    private val utc = TimeZone.getTimeZone("UTC")

    fun export(events: List<AgendaEvent>): String = buildString {
        append("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Bellendar//Calendar Export//FR\r\nCALSCALE:GREGORIAN\r\nMETHOD:PUBLISH\r\n")
        events.filter { it.reminderMode != "outlook" }.distinctBy { it.id }.sortedBy { it.timeMillis }.forEach { event ->
            append("BEGIN:VEVENT\r\n")
            append("UID:bellendar-${event.id}@bellendar.app\r\n")
            append("DTSTAMP:${formatUtc(System.currentTimeMillis())}\r\n")
            append("DTSTART:${formatUtc(event.timeMillis)}\r\n")
            event.endTimeMillis?.let { append("DTEND:${formatUtc(it)}\r\n") }
            append("SUMMARY:${escape(event.title)}\r\n")
            if (event.description.isNotBlank()) append("DESCRIPTION:${escape(event.description)}\r\n")
            when (event.recurrenceType) {
                "DAILY" -> append("RRULE:FREQ=DAILY;INTERVAL=${event.recurrenceInterval.coerceAtLeast(1)}\r\n")
                "WEEKLY" -> append("RRULE:FREQ=WEEKLY;INTERVAL=${event.recurrenceInterval.coerceAtLeast(1)}\r\n")
                "MONTHLY" -> append("RRULE:FREQ=MONTHLY;INTERVAL=${event.recurrenceInterval.coerceAtLeast(1)}\r\n")
                "YEARLY" -> append("RRULE:FREQ=YEARLY;INTERVAL=${event.recurrenceInterval.coerceAtLeast(1)}\r\n")
            }
            append("END:VEVENT\r\n")
        }
        append("END:VCALENDAR\r\n")
    }

    fun import(ics: String, existing: List<AgendaEvent>): Pair<List<AgendaEvent>, Int> {
        val unfolded = ics.replace("\r\n ", "").replace("\n ", "").replace("\r\n\t", "").replace("\n\t", "")
        val blocks = Regex("(?is)BEGIN:VEVENT\\s*(.*?)\\s*END:VEVENT").findAll(unfolded)
        val additions = mutableListOf<AgendaEvent>()
        blocks.forEach { match ->
            val fields = mutableMapOf<String, String>()
            match.groupValues[1].lines().forEach { line ->
                val colon = line.indexOf(':')
                if (colon > 0) fields[line.substring(0, colon).substringBefore(';').uppercase(Locale.ROOT)] = line.substring(colon + 1).trim()
            }
            val title = unescape(fields["SUMMARY"].orEmpty()).ifBlank { "(Sans titre)" }
            val start = parseDate(fields["DTSTART"]) ?: return@forEach
            val end = parseDate(fields["DTEND"])
            val description = unescape(fields["DESCRIPTION"].orEmpty())
            val duplicate = (existing + additions).any {
                it.timeMillis == start && it.title.equals(title, true) && it.description == description
            }
            if (!duplicate) {
                val rule = fields["RRULE"].orEmpty()
                val freq = Regex("FREQ=([A-Z]+)").find(rule)?.groupValues?.get(1)
                val type = when (freq) { "DAILY" -> "DAILY"; "WEEKLY" -> "WEEKLY"; "MONTHLY" -> "MONTHLY"; "YEARLY" -> "YEARLY"; else -> "NONE" }
                val interval = Regex("INTERVAL=(\\d+)").find(rule)?.groupValues?.get(1)?.toIntOrNull() ?: 1
                additions += AgendaEvent(
                    id = -((title + "|" + start).hashCode().toLong().let { kotlin.math.abs(it).coerceAtLeast(1L) }), title = title,
                    description = description, timeMillis = start, endTimeMillis = end,
                    reminderMode = "notification", leadMinutes = 0,
                    recurrenceType = type, recurrenceInterval = interval
                )
            }
        }
        return (existing + additions).sortedBy { it.timeMillis } to additions.size
    }

    private fun formatUtc(millis: Long): String = SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.ROOT).apply { timeZone = utc }.format(Date(millis))
    private fun parseDate(value: String?): Long? {
        if (value.isNullOrBlank()) return null
        val raw = value.substringAfter(':', value)
        val pattern = when { raw.matches(Regex("\\d{8}T\\d{6}Z")) -> "yyyyMMdd'T'HHmmss'Z'"; raw.matches(Regex("\\d{8}T\\d{6}")) -> "yyyyMMdd'T'HHmmss"; raw.matches(Regex("\\d{8}")) -> "yyyyMMdd"; else -> return null }
        return runCatching { SimpleDateFormat(pattern, Locale.ROOT).apply { isLenient = false; timeZone = if (raw.endsWith("Z")) utc else TimeZone.getDefault() }.parse(raw)?.time }.getOrNull()
    }
    private fun escape(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n").replace("\r", "")
    private fun unescape(s: String) = s.replace("\\n", "\n").replace("\\N", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")
}
