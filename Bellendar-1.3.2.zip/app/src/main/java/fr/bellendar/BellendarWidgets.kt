package fr.bellendar

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private object BellendarWidgetUi {
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    private fun launch(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, 7101, intent, FLAGS)
    }
    private fun colors(context: Context): Triple<Int, Int, Int> {
        val p = context.getSharedPreferences("interface", Context.MODE_PRIVATE)
        val theme = p.getString("selected_theme", "elegance") ?: "elegance"
        val primary = if (theme == "custom") parseHex(p.getString("custom_primary", "3569A8"), 0xFF3569A8.toInt()) else when(theme) {
            "purple" -> 0xFF7653A6.toInt(); "sunset" -> 0xFFB65F45.toInt(); "greenenergy" -> 0xFF287765.toInt()
            "blackgold" -> 0xFF9A7A3D.toInt(); "midnight" -> 0xFFB99AFF.toInt(); "pastel" -> 0xFF8876C7.toInt()
            "glass" -> 0xFF356BD6.toInt(); "nature" -> 0xFF477B5A.toInt(); else -> 0xFF245A9B.toInt()
        }
        val dark = theme == "blackgold" || theme == "midnight"
        val bg = if (dark) 0xFF1D293A.toInt() else if (theme == "custom") parseHex(p.getString("custom_surface", "FFFFFF"), Color.WHITE) else 0xFFF7FAFF.toInt()
        val fg = if (dark) 0xFFF2EFE8.toInt() else 0xFF202B39.toInt()
        return Triple(primary, bg, fg)
    }
    private fun parseHex(value: String?, fallback: Int): Int = runCatching { Color.parseColor("#" + (value ?: "").removePrefix("#")) }.getOrDefault(fallback)
    private fun applyTheme(context: Context, rv: RemoteViews, root: Int, textIds: List<Int>, accentIds: List<Int> = emptyList()) {
        val (primary, bg, fg) = colors(context)
        val themeId = context.getSharedPreferences("interface", Context.MODE_PRIVATE).getString("selected_theme", "elegance")
        val dark = themeId == "blackgold" || themeId == "midnight"
        rv.setInt(root, "setBackgroundResource", if (dark) R.drawable.widget_dark_bg else R.drawable.widget_card_bg)
        textIds.forEach { rv.setTextColor(it, fg) }
        accentIds.forEach { rv.setTextColor(it, primary) }
    }
    fun update(context: Context, manager: AppWidgetManager, ids: IntArray, layout: Int, kind: String) {
        val allEvents = EventStore(context).load().sortedBy { it.timeMillis }
        val events = allEvents.filter { it.timeMillis > System.currentTimeMillis() - 60_000 }
        ids.forEach { id ->
            val rv = RemoteViews(context.packageName, layout)
            val open = launch(context)
            rv.setOnClickPendingIntent(R.id.widget_root, open)
            when(kind) {
                "next" -> {
                    val next = events.firstOrNull()
                    rv.setTextViewText(R.id.widget_next_title, next?.title ?: "Aucun événement à venir")
                    rv.setTextViewText(R.id.widget_next_time, next?.let { SimpleDateFormat("EEEE d MMMM · HH:mm", Locale.getDefault()).format(Date(it.timeMillis)) } ?: "Votre agenda est libre")
                    val remaining = next?.let { ((it.timeMillis - System.currentTimeMillis()).coerceAtLeast(0) / 60000) }
                    val countdown = when { remaining == null -> ""; remaining < 60 -> "Dans $remaining min"; remaining < 1440 -> "Dans ${remaining / 60} h ${remaining % 60} min"; else -> "Dans ${remaining / 1440} j ${remaining % 1440 / 60} h" }
                    rv.setTextViewText(R.id.widget_next_countdown, countdown)
                    applyTheme(context, rv, R.id.widget_root, listOf(R.id.widget_next_title, R.id.widget_next_time), listOf(R.id.widget_next_countdown))
                }
                "agenda" -> {
                    val now = Calendar.getInstance()
                    rv.setTextViewText(R.id.widget_date, SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date()))
                    val today = allEvents.filter { sameDayWidget(it.timeMillis, now.timeInMillis) }
                    val rows = listOf(R.id.widget_line1, R.id.widget_line2, R.id.widget_line3, R.id.widget_line4)
                    rows.forEachIndexed { index, viewId ->
                        val e = today.getOrNull(index)
                        rv.setTextViewText(viewId, e?.let { "${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it.timeMillis))}   ${it.title}" } ?: if (index == 0 && today.isEmpty()) "Aucun rendez-vous aujourd'hui" else "")
                    }
                    applyTheme(context, rv, R.id.widget_root, rows + R.id.widget_date, listOf(R.id.widget_title, R.id.widget_footer))
                    rows.forEachIndexed { index, viewId -> today.getOrNull(index)?.colorHex?.let { hex -> runCatching { rv.setTextColor(viewId, Color.parseColor(hex)) } } }
                }
                "shortcut" -> {
                    rv.setTextViewText(R.id.widget_shortcut_date, SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date()))
                    rv.setOnClickPendingIntent(R.id.widget_shortcut_add, open)
                    applyTheme(context, rv, R.id.widget_root, listOf(R.id.widget_shortcut_date), listOf(R.id.widget_shortcut_add))
                }
                "month" -> updateMonth(context, rv, allEvents)
            }
            manager.updateAppWidget(id, rv)
        }
    }
    private fun updateMonth(context: Context, rv: RemoteViews, events: List<AgendaEvent>) {
        val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
        rv.setTextViewText(R.id.widget_month_title, SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time).uppercase(Locale.getDefault()))
        rv.setTextColor(R.id.widget_month_title, colors(context).first)
        val firstOffset = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val (_, _, fg) = colors(context)
        for (i in 0 until 42) {
            val id = context.resources.getIdentifier("day_$i", "id", context.packageName)
            if (id == 0) continue
            val day = i - firstOffset + 1
            if (day in 1..days) {
                val date = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, day) }.timeInMillis
                val hasEvent = events.any { sameDayWidget(it.timeMillis, date) }
                val isToday = sameDayWidget(date, System.currentTimeMillis())
                rv.setTextViewText(id, if (hasEvent) "•$day" else day.toString())
                rv.setTextColor(id, if (hasEvent) colors(context).first else fg)
                rv.setInt(id, "setBackgroundColor", if (isToday) 0x223569A8 else android.graphics.Color.TRANSPARENT)
                } else rv.setTextViewText(id, "")
            rv.setOnClickPendingIntent(id, launch(context))
        }
    }
    private fun sameDayWidget(a: Long, b: Long): Boolean {
        val x = Calendar.getInstance().apply { timeInMillis = a }
        val y = Calendar.getInstance().apply { timeInMillis = b }
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
    }
}

abstract class BellendarBaseWidget : AppWidgetProvider() {
    abstract val layout: Int
    abstract val kind: String
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = BellendarWidgetUi.update(context, manager, ids, layout, kind)
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) refresh(context)
    }
    companion object {
        const val ACTION_REFRESH = "fr.bellendar.action.REFRESH_WIDGETS"
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            listOf(
                Triple(WidgetNextProvider::class.java, R.layout.widget_next, "next"),
                Triple(WidgetAgendaProvider::class.java, R.layout.widget_agenda, "agenda"),
                Triple(WidgetMonthProvider::class.java, R.layout.widget_month, "month"),
                Triple(WidgetShortcutProvider::class.java, R.layout.widget_shortcut, "shortcut")
            ).forEach { (clazz, layout, kind) ->
                val component = ComponentName(context, clazz)
                val ids = manager.getAppWidgetIds(component)
                if (ids.isNotEmpty()) BellendarWidgetUi.update(context, manager, ids, layout, kind)
            }
        }
    }
}
class WidgetNextProvider : BellendarBaseWidget() { override val layout = R.layout.widget_next; override val kind = "next" }
class WidgetAgendaProvider : BellendarBaseWidget() { override val layout = R.layout.widget_agenda; override val kind = "agenda" }
class WidgetMonthProvider : BellendarBaseWidget() { override val layout = R.layout.widget_month; override val kind = "month" }
class WidgetShortcutProvider : BellendarBaseWidget() { override val layout = R.layout.widget_shortcut; override val kind = "shortcut" }
