MON AGENDA & ALARMES — structure du projet

IMPORTANT : le contenu de cette archive doit être placé directement à la racine
du dépôt GitHub (pas dans un sous-dossier Bellendar).

La racine du dépôt doit contenir :
- settings.gradle.kts
- build.gradle.kts
- gradle.properties
- app/build.gradle.kts
- app/src/...
- .github/workflows/android-apk.yml

Le fichier app/build.gradle.kts est inclus dans cette archive.

Après avoir remplacé les fichiers du dépôt par ceux de cette archive,
vérifier dans GitHub que le chemin app/build.gradle.kts existe bien.

Le workflow fourni compile une APK Debug pour vérifier le projet.
Il ne s'agit pas encore d'une APK Release signée avec la clé permanente.
Ne pas publier cette APK Debug sur Play Store et ne pas l'utiliser pour mettre
à jour une installation signée Release.

Version 1.1.49 (versionCode 60) : import de rendez-vous depuis une photo.
La reconnaissance OCR locale fonctionne hors connexion. Les lignes contenant un horaire
et un jour/date sont proposées dans une liste modifiable avant import. Les événements
ne sont enregistrés qu'après validation, les doublons exacts (intitulé + date/heure)
sont ignorés et aucun rappel/alarme n'est programmé automatiquement.
La reconnaissance manuscrite avancée via Internet n'est pas activée : elle nécessite
un service backend sécurisé et un consentement explicite avant transfert de photo.
