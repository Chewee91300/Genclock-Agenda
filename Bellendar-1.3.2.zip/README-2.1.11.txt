Bellendar - Version 2.1.12

Optimisation de la colonne horaire en mode semaine :
- largeur réduite de 43 dp à 35 dp (environ 19 % de moins) ;
- les libellés HH:00 / HH:30 restent affichés en entier ;
- le numéro ISO de semaine reste dans la même colonne ;
- le calcul de largeur des jours et le positionnement au toucher utilisent la nouvelle largeur.

Version Android : 2.1.12
versionCode : 109

La compilation doit être vérifiée avec GitHub Actions.
