Bellendar — version 2.4.8

Correction de la barre des modes d'affichage :
- les quatre boutons Aujourd'hui, Jour, Semaine et Mois se répartissent équitablement sur la largeur disponible ;
- sur les écrans étroits, l'horloge passe sur une ligne dédiée sous les boutons ;
- sur les écrans larges, l'horloge reste sur la même ligne avec une largeur réservée ;
- les libellés restent sur une seule ligne et ne sont plus coupés par un défilement horizontal.

Version précédente : 2.4.7 (skins premium).
Version Android : versionName 2.4.8, versionCode 127.
Compilation Android non exécutée dans cet environnement.
