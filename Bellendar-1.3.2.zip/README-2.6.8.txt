Bellendar 2.6.8
VersionCode: 147

Modification:
- Vue Aujourd'hui simplifiée en récapitulatif du jour.
- Chaque événement affiche son intitulé et son heure programmée (HH:mm), ou sa plage horaire si une heure de fin est définie.
- Suppression de l'indication relative au délai de rappel (« dans x heures/minutes ») et des détails de configuration de l'alarme dans cette vue.
- Les vues Jour, Semaine et Mois conservent les informations détaillées.

Compilation APK à valider avec GitHub Actions.
