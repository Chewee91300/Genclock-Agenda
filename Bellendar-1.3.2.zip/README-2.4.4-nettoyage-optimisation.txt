Bellendar 2.4.4

Nettoyage ciblé et optimisation du moteur de récurrence.
- Remplacement des calculs hebdomadaires basés sur des millisecondes par des calculs de dates calendaires, robustes aux changements d'heure.
- Calcul de l'heure locale de chaque occurrence avec le fuseau horaire courant.
- Suppression des créations répétées d'objets Calendar à chaque journée parcourue.
- Gestion du dernier jour des mois et des années bissextiles.
- Limite de sécurité du nombre d'occurrences examinées.
- Développement à la demande conservé : les occurrences ne sont pas enregistrées en double.

Version : 2.4.4
VersionCode : 123

Compilation Android non exécutée dans cet environnement. Vérifier via GitHub Actions et tester les séries quotidiennes, hebdomadaires, mensuelles, annuelles et les changements d'heure.
