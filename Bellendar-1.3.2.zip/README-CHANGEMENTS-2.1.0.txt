Bellendar — préparation 2.1.0

Version : 2.1.0
versionCode : 98

Modifications incluses dans cette archive :
- Ajout d'un sélecteur de langue persistant dans les paramètres avec 11 choix (français par défaut, anglais, espagnol, allemand, portugais, chinois simplifié, hindi, arabe, russe, japonais et bengali).
- Le réglage du volume minimum des alarmes accepte 5 à 100 % dans l'interface et dans le service de lecture d'alarme.

Limite connue : le sélecteur mémorise la langue choisie, mais la traduction intégrale de tous les écrans, dialogues, notifications et contenus générés n'est pas encore réalisée. Les textes de l'application restent majoritairement en français. Ne pas publier cette version comme une localisation complète.

Compilation : à vérifier sur GitHub Actions. Aucun wrapper Gradle n'est fourni dans le projet source.
