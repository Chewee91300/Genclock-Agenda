Version 2.11.0 - Synchronisation bidirectionnelle du calendrier Android synchronisé avec Outlook

- Lecture des événements des calendriers Android sélectionnés (fonction existante).
- Nouveau bouton de synchronisation vers le calendrier sélectionné : création des événements locaux et mise à jour de ceux déjà liés.
- L'identifiant de l'événement distant est conservé dans les données de l'événement pour éviter les doublons lors des synchronisations suivantes.
- Demande de l'autorisation Android WRITE_CALENDAR à la première écriture.
- Suppression d'un événement local lié répercutée dans le calendrier distant lorsque l'autorisation d'écriture est disponible.
- Traduction du nouveau bouton en français, anglais, espagnol et allemand.

Limites à vérifier en environnement Android réel : le compte Outlook doit être synchronisé dans le calendrier Android du téléphone et le calendrier de destination doit être sélectionné dans Paramètres > Synchronisation. La synchronisation nécessite une action manuelle. Les suppressions effectuées directement dans Outlook sont reflétées par l'actualisation/lecture, mais les suppressions distantes ne sont pas encore utilisées comme tombstones pour supprimer automatiquement une copie locale indépendante. Les alarmes spécifiques à l'application ne sont pas exportées comme rappels Outlook.
