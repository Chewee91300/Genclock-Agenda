Bellendar 2.8.1 — amélioration de la suppression des événements

Lorsqu'un événement comporte des pièces jointes, une boîte de dialogue permet :
- de sélectionner ou désélectionner tous les fichiers ;
- de cocher individuellement les fichiers à supprimer ;
- de supprimer l'événement et uniquement les fichiers cochés ;
- de conserver les fichiers décochés dans le dossier de sauvegarde.

La suppression d'une seule occurrence d'une série récurrente ne supprime pas physiquement les fichiers partagés avec les autres occurrences.

Les nouveaux textes de l'interface sont traduits en anglais, espagnol et allemand. Le français reste la langue source.

Version conservée : 2.8.1
versionCode conservé : 156
applicationId conservé : fr.bellendar

Compilation Gradle non exécutée dans cet environnement : le projet fourni ne contient pas le script gradlew.
