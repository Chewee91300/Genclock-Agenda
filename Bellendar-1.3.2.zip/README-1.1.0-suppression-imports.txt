Bellendar 1.1.0 — Suppression des événements importés

Ajout dans Paramètres > Import / Export Outlook d'une commande permettant de supprimer les événements importés depuis des fichiers .ics.
La commande affiche le nombre d'événements concernés et demande une confirmation.
Les événements créés manuellement dans Bellendar et les événements synchronisés depuis les calendriers Android/Outlook sont conservés.
Les textes de cette fonctionnalité sont traduits en anglais, espagnol, allemand et portugais européen.

Version Android : versionCode 11 / versionName 1.1.0.
Application ID conservé : fr.bellendar.

La suppression cible les événements importés depuis .ics, identifiés par leur identifiant local négatif et leur mode différent de "outlook". Les événements de calendriers synchronisés ont le mode "outlook" et ne sont pas supprimés.
