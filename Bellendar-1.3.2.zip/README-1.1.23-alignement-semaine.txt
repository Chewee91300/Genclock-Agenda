Bellendar 1.1.23
VersionCode : 34

Correction de l'alignement de la vue hebdomadaire : le bandeau du mois,
les intitulés des jours et la grille horaire utilisent désormais le même
état de défilement horizontal. Le déplacement manuel de l'en-tête en pixels
a été supprimé afin d'éviter le décalage entre les jours et les colonnes.

Les fonctionnalités existantes et les traductions ne sont pas modifiées.
