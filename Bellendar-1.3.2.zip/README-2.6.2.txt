Bellendar 2.6.2 (versionCode 141)

Corrections du planning hebdomadaire :
- Les libellés des jours défilent horizontalement avec les colonnes correspondantes.
- La largeur des colonnes d'en-tête est calculée avec la même formule que celle de la grille.
- La colonne des heures reste fixe et visible pendant le défilement horizontal.
- Les heures ne disparaissent donc plus lors du zoom horizontal.
- Le double-tap pour créer un événement utilise les coordonnées de la grille sans décalage de la colonne horaire.

Archive source. La compilation Android et les essais tactiles doivent être exécutés dans l'environnement Android/GitHub Actions.
