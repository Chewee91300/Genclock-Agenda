Bellendar 2.6.9
VersionCode : 148

- Première ouverture : écran obligatoire de sélection de langue avant l'accès à l'agenda.
- La liste ne propose que les langues actuellement disponibles dans l'interface : Français et English.
- Le choix est mémorisé sur l'appareil et peut ensuite être modifié dans Paramètres.
- Aide mise à jour avec les instructions de sélection de langue et de déplacement diagonal en vue Semaine.
- Identifiant Android conservé : fr.bellendar.

La compilation complète doit être validée par GitHub Actions.
