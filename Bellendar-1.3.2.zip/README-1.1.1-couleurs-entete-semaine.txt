Bellendar 1.1.1

Vue semaine :
- Fond rouge fixe pour les dimanches et les jours fériés français.
- Fond rouge clair fixe pour les samedis.
- Couleurs indépendantes du skin sélectionné.
- Texte adapté pour rester lisible sur les fonds colorés.

VersionCode : 12
VersionName : 1.1.1
