Version 2.9.5

- Ajout dans Paramètres d'une section de sélection individuelle des calendriers Android visibles.
- Les calendriers sont regroupés par compte (Google, Microsoft/Outlook ou autre fournisseur déclaré par Android).
- Les choix sont mémorisés sur l'appareil.
- La lecture des événements externes est filtrée selon les calendriers sélectionnés.
- Décocher un calendrier n'efface aucun événement local déjà enregistré.

Base du projet : Bellendar 2.9.3, conformément à la demande.
La correction de défilement horizontal de la 2.9.4 tronquée n'a pas été reprise.
Compilation Android non effectuée dans cet environnement.
