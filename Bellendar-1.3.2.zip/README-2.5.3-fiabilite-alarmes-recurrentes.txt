Bellendar — version 2.5.3 (versionCode 132)

Correctifs de fiabilité des alarmes récurrentes :
- Une heure d'alarme personnalisée est réappliquée comme décalage à chaque occurrence, au lieu de réutiliser la date absolue du rendez-vous maître.
- Les occurrences modifiées individuellement conservent leur propre configuration d'alarme.
- Après redémarrage, changement d'heure, changement de fuseau ou mise à jour, les séries sont reconstruites à partir des événements enregistrés, même si l'alarme du rendez-vous maître est déjà passée.
- Les événements autonomes sont reprogrammés séparément des occurrences virtuelles des séries.
- Après autorisation des notifications, l'application relance la programmation de l'ensemble des événements et de leurs séries.

Base : version 2.5.2.
Contrôles effectués : inspection des appels de programmation et vérification de l'intégrité de l'archive ZIP.
Compilation Android complète non exécutée dans cet environnement. À valider avec GitHub Actions et sur appareil Android.
