Bellendar — version 2.1.5
versionCode : 103
Base : version 2.1.4

Modifications :
- Le bouton flottant « + » est masqué dans les modes Jour et Semaine.
  La création d'un événement reste disponible par double appui sur un créneau.
- Ajout du choix d'une couleur parmi cinq dans la fiche de création/modification d'événement.
- La couleur choisie est enregistrée dans le JSON local et dans la sauvegarde externe.
- La couleur est indépendante du thème global et est utilisée dans les vues Jour et Semaine,
  ainsi que comme repère dans la carte de l'événement.
- Les anciens événements sans couleur conservent leur affichage habituel.

Compilation : non exécutée dans cet environnement (Gradle n'est pas installé et le projet
ne contient pas de Gradle Wrapper). Le workflow GitHub Actions du projet est conservé.
