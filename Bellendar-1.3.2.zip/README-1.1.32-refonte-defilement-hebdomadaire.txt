Bellendar 1.1.32 — refonte du défilement hebdomadaire

- Le bandeau du mois, l'en-tête des jours et la grille partagent désormais
  le même ScrollState horizontal Compose.
- Suppression des décalages horizontaux manuels par offset sur les en-têtes.
- Les trois zones utilisent les mêmes dimensions de contenu et de viewport.
- La colonne horaire reste hors du défilement horizontal.
- Version Android : versionName 1.1.32, versionCode 42.

Validation : archive source contrôlée. Compilation Gradle non exécutée dans
cet environnement ; le comportement à l'exécution doit être vérifié sur
l'appareil.
