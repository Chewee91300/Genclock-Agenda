Bellendar — Version 2.1.15
VersionCode : 113

Modifications :
- Icônes Notification et Alarme affichées dans les événements des vues Jour et Semaine.
- Couleur des icônes calculée automatiquement selon le contraste maximal (noir/blanc) avec la couleur de fond de l'événement.
- Icônes de pièces jointes harmonisées avec le contraste de l'événement.
- Curseur de l'heure actuelle adapté au contraste de l'événement lorsqu'il traverse un événement ; couleur d'alerte conservée hors événement.
- Même logique de contraste dans les vues Jour et Semaine.

Base : projet 2.1.14 fourni dans cette conversation.
Compilation Android et tests sur appareil à effectuer avec GitHub Actions et un téléphone réel.
