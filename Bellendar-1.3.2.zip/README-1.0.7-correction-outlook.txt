Bellendar 1.0.7
Correction de compilation de la fonctionnalité Import / Export Outlook.
- Les messages affichés dans les callbacks de sélection/import/export sont traduits sans appeler de fonction @Composable.
- La traduction dynamique des messages Outlook est accessible depuis MainActivity.
- Suppression de la référence à selectedLanguage avant sa déclaration.
Version Android : versionCode 8, versionName 1.0.7.
Compilation à valider avec GitHub Actions.
