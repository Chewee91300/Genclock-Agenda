Bellendar — version 2.6.4 (versionCode 143)

Renommage de la marque affichée : Bellendar.
- Nom du lanceur Android en français et en anglais.
- Titre principal et titres de fenêtres de l’application.
- Noms affichés des canaux de notification et d’alarme.
- Mise à jour du nom de projet Gradle et de la documentation principale.

Conservés volontairement pour assurer les mises à jour sans perte de données :
- applicationId / namespace : fr.bellendar
- chemins de sauvegarde et dossiers de pièces jointes Bellendar
- identifiants internes des canaux et composants Android.

La compilation Android doit encore être exécutée dans Android Studio ou GitHub Actions.
