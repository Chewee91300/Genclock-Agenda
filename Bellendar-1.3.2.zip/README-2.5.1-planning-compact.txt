Bellendar — version 2.5.1 (code 130)

Optimisation de l’espace du planning hebdomadaire :
- Horloge HH:mm:ss déplacée dans l’en-tête du planning hebdomadaire.
- Suppression de la ligne d’horloge dédiée en vue Semaine.
- Boutons de navigation réduits à 30 dp de hauteur.
- Navigation calendrier compactée : boutons 32 dp, marges verticales réduites et titre 17 sp.
- Boutons de modes compactés à 30 dp.
- En-tête des jours et commandes du week-end conservés.

Base : version 2.5.0. Les fonctions existantes, dont les récurrences, sont conservées.
Compilation Android complète à vérifier avec GitHub Actions.
