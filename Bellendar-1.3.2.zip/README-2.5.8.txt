Bellendar 2.5.8
Correction du thème personnalisé : édition des couleurs principale, arrière-plan et surfaces avec application immédiate et mémorisation locale.
Version précédente : 2.5.7 (code 136). Nouvelle version : 2.5.8 (code 137).
Compilation Android complète non exécutée dans cet environnement.
