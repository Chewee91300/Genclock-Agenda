Bellendar — version 2.3.0
VersionCode : 117

Fiabilisation du moteur d'alarmes :
- Le service de lecture ne redémarre plus automatiquement sans Intent valide (START_NOT_STICKY).
- Une Intent nulle ou dépourvue d'identifiant d'événement est rejetée sans lancer de sonnerie.
- Les alarmes successives arrêtent proprement la lecture et la vibration précédentes avant de démarrer la nouvelle.
- La répétition de 5 minutes conserve le son personnalisé et le réglage de vibration de l'événement.
- Chaque répétition utilise un PendingIntent distinct par événement.
- Les alarmes et rappels futurs sont reprogrammés après redémarrage, changement manuel d'heure, changement de fuseau et mise à jour de l'application.
- Les événements dont l'heure de déclenchement est passée ne sont pas reprogrammés.

À vérifier sur appareil :
- Autorisation Android « Alarmes et rappels ».
- Son personnalisé, vibration et répétition 5 minutes.
- Arrêt depuis notification et écran verrouillé.
- Redémarrage du téléphone et changements d'heure/fuseau.
- Restrictions batterie propres au constructeur.

La compilation Android doit être validée dans GitHub Actions : aucun Gradle Wrapper n'est fourni dans cette archive.
