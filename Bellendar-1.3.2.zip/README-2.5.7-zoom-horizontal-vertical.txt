Bellendar 2.5.7 (versionCode 136)

Mode semaine : le pincement à deux doigts agrandit simultanément la hauteur des créneaux et la largeur des colonnes de jours. La colonne horaire reste fixe. La grille devient horizontalement défilable lorsque le zoom dépasse 1x. Le zoom minimal reste 1x (échelle historique), le maximum reste 3x. Les positions de défilement horizontal et vertical ainsi que le niveau de zoom sont mémorisés.

Compilation Android complète non exécutée dans cet environnement. Vérifier avec GitHub Actions et tester le geste sur appareil.
