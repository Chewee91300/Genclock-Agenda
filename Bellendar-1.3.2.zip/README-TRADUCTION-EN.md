# Bellendar 1.3.2 — documentation de traduction (historique)

Ce fichier contient les notes historiques relatives à l'ajout de la couche d'interface anglaise. Il ne constitue pas la fiche de version courante de l'application.

La version source de cette archive reste **1.3.2 (versionCode 50)**, telle que déclarée dans `app/build.gradle.kts`.

Les notes ci-dessous sont conservées pour mémoire et décrivent l'état de traduction au moment de leur rédaction ; elles ne doivent pas être interprétées comme une déclaration de version actuelle.

---

# Historical note — English translation layer

This update added an English UI layer while keeping French as the default language.

- Select **English** in Settings → Language.
- The selection is stored in the existing interface preferences.
- Main interface labels, dialogs, event editor, reminder settings, alarm screen, and reminder/alarm notification labels received English translations.
- User-entered event titles and descriptions are preserved as entered and are not machine-translated.

Validation note: a full Android/Gradle build was not recorded in this historical note. The voice wizard's date/time parsing examples and parsing logic were French-specific at that time.
