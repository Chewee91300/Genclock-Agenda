Bellendar 1.1.36 - Widgets Android

Quatre widgets sont disponibles dans le sélecteur de widgets Android :
1. Prochain événement : affiche le prochain rendez-vous, son heure et un compte à rebours.
2. Agenda du jour : affiche jusqu'à quatre rendez-vous de la journée.
3. Calendrier mensuel : affiche le mois courant et marque les jours qui contiennent un événement.
4. Raccourci : ouvre Bellendar depuis l'écran d'accueil.

Ajout : appui long sur une zone vide de l'écran d'accueil Android, ouvrir Widgets, rechercher Bellendar, puis faire glisser le widget souhaité.

Les widgets se mettent à jour après l'enregistrement d'événements, lors d'un changement de thème, à intervalle périodique (selon le lanceur Android) et lors d'un changement de date ou d'heure. Touchez un widget pour ouvrir l'application.
