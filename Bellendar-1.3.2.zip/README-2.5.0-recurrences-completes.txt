Bellendar 2.5.0 — Gestion des séries récurrentes

- Choix des jours de la semaine conservé pour les récurrences hebdomadaires.
- Les occurrences affichées gardent leur identifiant de série et leur date d'origine.
- Modification : occurrence seule, occurrence et suivantes, ou série entière.
- Suppression : occurrence seule, occurrence et suivantes, ou série entière.
- Une occurrence modifiée est stockée comme exception et remplace seulement la date d'origine.
- Une occurrence supprimée est mémorisée comme exception et ne réapparaît pas au prochain affichage.
- Les exceptions déjà enregistrées sont prises en compte par le moteur.
- Les rappels des séries et des exceptions sont annulés puis reprogrammés après les opérations.
- Les anciennes sauvegardes restent lisibles ; les nouvelles métadonnées sont conservées dans le JSON.

Vérifications effectuées :
- Compilation Kotlin isolée de Event.kt, RecurrenceEngine.kt et RecurrenceManager.kt réussie.
- Archive ZIP à contrôler après génération.
- Compilation Android complète non exécutée dans cet environnement ; vérifier avec GitHub Actions avant installation.
