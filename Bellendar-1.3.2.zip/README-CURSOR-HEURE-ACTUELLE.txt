Bellendar - version 2.1.2 (versionCode 100)

Modification : ajout d'un curseur horizontal rouge dans le planning hebdomadaire.
- Le curseur apparaît dans la colonne du jour courant, à la position correspondant à l'heure et à la minute actuelles.
- Il se met à jour automatiquement toutes les 30 secondes.
- Il n'apparaît pas lorsque la semaine affichée ne contient pas aujourd'hui, ni lorsque l'heure actuelle est hors de la plage horaire affichée.
- Il suit le réglage d'affichage du week-end : si le jour courant est masqué, le curseur n'est pas affiché.

Compilation : non exécutée dans cet environnement, car l'archive source ne contient pas gradlew / gradle wrapper.
