Bellendar 2.5.4 - Optimisations du planning hebdomadaire

- Le zoom par pincement conserve désormais l'heure située sous le centre du geste : la grille s'agrandit autour du point visé.
- La position verticale du planning est mémorisée dans les préférences et restaurée lors des prochaines ouvertures.
- À la première ouverture sans position mémorisée, le planning de la semaine courante se positionne près de l'heure actuelle.
- Le zoom minimum reste 1x, identique à l'échelle historique. Aucun bouton supplémentaire n'est ajouté.
- Le mode Jour et le mode Mois ne sont pas concernés.

Version Android : 2.5.4 (versionCode 133).
Compilation Android complète non exécutée dans cet environnement ; vérifier avec GitHub Actions et tester le geste sur appareil.
