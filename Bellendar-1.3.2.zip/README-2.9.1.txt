Bellendar – version 2.9.1

Vue Semaine : lorsqu'un défilement horizontal atteint une butée, poursuivre le geste vers la gauche affiche la semaine suivante ; poursuivre vers la droite affiche la semaine précédente. Une seule bascule est effectuée par geste. La navigation fonctionne aussi lorsque le zoom ne laisse aucun débordement horizontal.

Version précédente : 2.9.0 (versionCode 157)
Nouvelle version : 2.9.1 (versionCode 158)
