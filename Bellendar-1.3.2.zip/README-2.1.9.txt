Bellendar — version 2.1.9
versionCode: 107

Optimisation de la fiche événement :
- réduction des marges internes et des espacements entre sections ;
- champs Titre et Description plus compacts ;
- pastilles de couleur légèrement réduites ;
- boutons Date et Heure avec un remplissage vertical réduit ;
- cases à cocher et boutons radio plus compacts ;
- options de personnalisation de l'alarme (sonnerie et vibreur) affichées uniquement lorsque « Alarme sonore Bellendar » est activée ;
- conservation des données et des options sélectionnées lorsque la section alarme est temporairement masquée.

La fiche conserve son défilement et les boutons Annuler / Enregistrer de la boîte de dialogue.
Compilation Android non exécutée dans cet environnement ; valider avec GitHub Actions.
