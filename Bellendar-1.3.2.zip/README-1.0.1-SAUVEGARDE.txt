Bellendar 1.0.1 — Changement du répertoire de sauvegarde

Une rubrique « Sauvegarde » est disponible dans les paramètres.
L'utilisateur peut sélectionner un nouveau répertoire. Avant de valider, un avertissement explique que Bellendar importera les événements et les pièces jointes présents dans le répertoire, les fusionnera avec les événements déjà présents dans l'application, puis utilisera ce répertoire pour les prochaines sauvegardes. L'ancien répertoire n'est pas supprimé.

Le changement est effectué après lecture et validation du fichier JSON, réassociation/copie des pièces jointes accessibles, fusion des événements sans doublonner les identifiants, écriture et vérification de la nouvelle sauvegarde. Si l'opération échoue, l'ancien répertoire reste configuré.

Les nouveaux textes de l'interface sont traduits en français, anglais, espagnol et allemand.

Version : 1.0.1
versionCode : 2
