Bellendar – version 2.1.8
VersionCode : 106

Optimisation de la fiche événement :
- Titre de fenêtre plus compact et sur une seule ligne.
- Champs titre et description moins hauts (description extensible sur deux lignes).
- Espacements et marges internes des sections réduits.
- Pastilles de couleur légèrement réduites.
- Date et heures gardées côte à côte.
- Cases Notification et Alarme présentées côte à côte pour limiter la hauteur.
- Choix du délai et options conservés.
- Boutons Annuler et Enregistrer restent dans la zone fixe de l'AlertDialog.

Toutes les fonctions et données de la version 2.1.7 sont conservées.
Compilation Android non exécutée dans cet environnement ; vérifier avec GitHub Actions.
