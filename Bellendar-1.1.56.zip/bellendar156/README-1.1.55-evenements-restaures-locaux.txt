Bellendar 1.1.55 – événements restaurés depuis une sauvegarde

Correction : les identifiants CalendarContract/Outlook d'un autre appareil ne sont plus conservés lors de la restauration d'une sauvegarde. Les événements restaurés deviennent autonomes dans Bellendar et leurs modifications restent locales. Les rappels marqués comme rappels Outlook sont convertis en absence de rappel Outlook, car leur événement source n'existe pas dans le calendrier courant.

Les événements Outlook lus directement depuis le calendrier Android continuent à conserver leur identifiant source et leur parcours de mise à jour.

Version : 1.1.55 (versionCode 65).
Compilation Android non exécutée dans cet environnement.
