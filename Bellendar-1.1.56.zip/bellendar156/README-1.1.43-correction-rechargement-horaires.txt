Bellendar 1.1.43

Correction de la fiche de modification après une modification des horaires.
La clé de mémorisation Compose des champs heure de début et heure de fin incluait l'identifiant de l'événement, mais pas leurs valeurs courantes.
Quand on rouvrait la fiche du même événement, Compose pouvait donc conserver l'ancien état (par exemple 18:00) même si l'événement enregistré était passé à 17:00.
Les valeurs timeMillis et endTimeMillis de l'événement font désormais partie des clés de réinitialisation des états correspondants.
VersionName 1.1.43 / versionCode 53.
Compilation Android non exécutée dans cet environnement.
