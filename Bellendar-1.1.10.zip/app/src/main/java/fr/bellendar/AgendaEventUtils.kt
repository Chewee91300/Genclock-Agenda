package fr.bellendar

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Modèle léger utilisé pendant l'import d'un agenda papier ou dicté. */
fun parseDictatedAgendaText(text: String, referenceDay: Long): List<PhotoEventCandidate> {
    val normalized = text.lowercase(Locale.FRANCE).replace('’', '\'').trim()
    if (normalized.isBlank()) return emptyList()
    val calendar = Calendar.getInstance().apply {
        timeInMillis = referenceDay
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val weekdays = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
    val weekday = weekdays.firstOrNull { Regex("\\b$it\\b").containsMatchIn(normalized) }
    if (weekday != null) {
        val target = weekdays.indexOf(weekday)
        val today = (calendar.get(Calendar.DAY_OF_WEEK) + 5) % 7
        var delta = target - today
        if (normalized.contains("prochain") || normalized.contains("semaine prochaine")) { if (delta <= 0) delta += 7 }
        else if (delta < 0) delta += 7
        calendar.add(Calendar.DAY_OF_MONTH, delta)
    } else if (normalized.contains("demain")) calendar.add(Calendar.DAY_OF_MONTH, 1)
    else if (normalized.contains("après-demain") || normalized.contains("apres-demain")) calendar.add(Calendar.DAY_OF_MONTH, 2)

    val months = mapOf("janvier" to 1, "février" to 2, "fevrier" to 2, "mars" to 3, "avril" to 4, "mai" to 5, "juin" to 6, "juillet" to 7, "août" to 8, "aout" to 8, "septembre" to 9, "octobre" to 10, "novembre" to 11, "décembre" to 12, "decembre" to 12)
    val dateMatch = Regex("\\b([0-3]?\\d)\\s+(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)(?:\\s+(20\\d{2}))?").find(normalized)
    if (dateMatch != null) {
        val day = dateMatch.groupValues[1].toIntOrNull() ?: return emptyList()
        val month = months[dateMatch.groupValues[2]] ?: return emptyList()
        var year = dateMatch.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
        val candidate = Calendar.getInstance().apply { clear(); set(year, month - 1, day, 0, 0, 0) }
        if (dateMatch.groupValues[3].isBlank() && candidate.timeInMillis < referenceDay - 24L * 60 * 60 * 1000) year++
        calendar.set(year, month - 1, day)
        if (calendar.get(Calendar.MONTH) != month - 1 || calendar.get(Calendar.DAY_OF_MONTH) != day) return emptyList()
    }

    // Reconnaître les plages horaires en français :
    // « entre 15 et 16h », « de 15h à 16h », « 15h30-16h30 ».
    val rangeMatch = Regex(
        "\\b(?:entre\\s+|de\\s*)?([01]?\\d|2[0-3])(?:\\s*h\\s*([0-5]\\d)?)?\\s*(?:et|à|a|jusqu['’]?\\s*à|-)\\s*([01]?\\d|2[0-3])(?:\\s*h\\s*([0-5]\\d)?)?\\b"
    ).find(normalized)
    val timeToken = Regex("\\b(midi|minuit)\\b").find(normalized)
    val numericTime = if (rangeMatch == null) {
        Regex("\\b(?:à|a)\\s*([01]?\\d|2[0-3])(?:\\s*h\\s*([0-5]\\d)?)?\\b").find(normalized)
            ?: Regex("\\b([01]?\\d|2[0-3])\\s*h\\s*([0-5]\\d)?\\b").find(normalized)
    } else null

    val hour: Int
    val minute: Int
    when {
        rangeMatch != null -> {
            hour = rangeMatch.groupValues[1].toInt()
            minute = rangeMatch.groupValues[2].toIntOrNull() ?: 0
        }
        timeToken?.value == "midi" -> { hour = 12; minute = 0 }
        timeToken?.value == "minuit" -> { hour = 0; minute = 0 }
        numericTime != null -> {
            hour = numericTime.groupValues[1].toIntOrNull() ?: return emptyList()
            minute = numericTime.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        }
        else -> return emptyList()
    }

    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, minute)
    val startText = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(calendar.time)
    val endText = if (rangeMatch != null) {
        val endCalendar = calendar.clone() as Calendar
        endCalendar.set(Calendar.HOUR_OF_DAY, rangeMatch.groupValues[3].toInt())
        endCalendar.set(Calendar.MINUTE, rangeMatch.groupValues[4].toIntOrNull() ?: 0)
        if (endCalendar.timeInMillis <= calendar.timeInMillis) endCalendar.add(Calendar.DAY_OF_MONTH, 1)
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(endCalendar.time)
    } else ""

    // Nettoyage effectué sur le texte d'origine normalisé, sans séparer les lettres.
    var title = normalized
        .replace(dateMatch?.value ?: "", " ")
        .replace(rangeMatch?.value ?: "", " ")
        .replace(timeToken?.value ?: numericTime?.value.orEmpty(), " ")
        .replace(Regex("\\b(aujourd'hui|demain|après-demain|apres-demain|prochain|semaine prochaine)\\b"), " ")
        .replace(Regex("\\b(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\\b"), " ")
        .replace(Regex("\\b(le|pour|rendez-vous|rdv|de|entre)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', ',', '.', '-', ':')
    if (title.isBlank()) return emptyList()
    return listOf(PhotoEventCandidate(title.trim().replaceFirstChar { it.uppercase(Locale.FRANCE) }, startText, endText))
}

fun parseVoiceDate(value: String, referenceDay: Long): Long? {
    val normalized = value.lowercase(Locale.FRANCE)
        .replace('’', '\'')
        .trim()
        // La reconnaissance vocale restitue souvent « premier », « 1er » ou « un »
        // lorsqu'on dicte le premier jour du mois.
        .replace(Regex("\\bpremier\\b"), "1")
        .replace(Regex("\\b1\\s*er\\b"), "1")
        .replace(Regex("\\bun(?=\\s+(?:janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre))"), "1")
        .replace(Regex("\\ble\\s+1\\b"), "1")
    val months = mapOf("janvier" to 1, "février" to 2, "fevrier" to 2, "mars" to 3, "avril" to 4, "mai" to 5, "juin" to 6, "juillet" to 7, "août" to 8, "aout" to 8, "septembre" to 9, "octobre" to 10, "novembre" to 11, "décembre" to 12, "decembre" to 12)
    val match = Regex("\\b([0-3]?\\d)\\s+(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)(?:\\s+(20\\d{2}))?").find(normalized)
    if (match != null) {
        val day = match.groupValues[1].toIntOrNull() ?: return null
        val month = months[match.groupValues[2]] ?: return null
        var year = match.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
        val cal = Calendar.getInstance().apply { clear(); set(year, month - 1, day, 9, 0, 0) }
        if (cal.get(Calendar.MONTH) != month - 1 || cal.get(Calendar.DAY_OF_MONTH) != day) return null
        if (match.groupValues[3].isBlank() && cal.timeInMillis < referenceDay - 86_400_000L) { year++; cal.set(Calendar.YEAR, year) }
        return cal.timeInMillis
    }
    if (normalized.contains("aujourd'hui") || normalized == "aujourd'hui") return Calendar.getInstance().apply { timeInMillis = referenceDay; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    if (normalized.contains("demain")) return Calendar.getInstance().apply { timeInMillis = referenceDay; add(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val weekdayNames = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
    weekdayNames.firstOrNull { normalized.contains(it) }?.let { dayName ->
        val cal = Calendar.getInstance().apply { timeInMillis = referenceDay; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val target = weekdayNames.indexOf(dayName) + 2
        var delta = target - cal.get(Calendar.DAY_OF_WEEK)
        if (delta <= 0 || normalized.contains("prochain")) { if (delta <= 0) delta += 7 }
        cal.add(Calendar.DAY_OF_MONTH, delta)
        return cal.timeInMillis
    }
    val numeric = Regex("\\b([0-3]?\\d)[/.-]([01]?\\d)(?:[/.-](20\\d{2}))?\\b").find(normalized) ?: return null
    val day = numeric.groupValues[1].toInt(); val month = numeric.groupValues[2].toInt(); val year = numeric.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
    return runCatching { Calendar.getInstance().apply { clear(); set(year, month - 1, day, 9, 0, 0); if (get(Calendar.MONTH) != month - 1 || get(Calendar.DAY_OF_MONTH) != day) throw IllegalArgumentException() }.timeInMillis }.getOrNull()
}

fun parseVoiceTime(value: String): Pair<Int, Int>? {
    val n = value.lowercase(Locale.FRANCE).replace("heures", "h").replace("heure", "h").replace(" et ", " ").trim()
    if (n.contains("midi")) return 12 to 0
    if (n.contains("minuit")) return 0 to 0
    val m = Regex("\\b([01]?\\d|2[0-3])\\s*(?:h|:| )\\s*([0-5]\\d)?\\b").find(n) ?: Regex("\\b([01]?\\d|2[0-3])\\b").find(n) ?: return null
    val h = m.groupValues[1].toIntOrNull() ?: return null; val min = m.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
    return if (h in 0..23 && min in 0..59) h to min else null
}

fun parseVoiceDuration(value: String): Int? {
    val n = value.lowercase(Locale.FRANCE).trim()
    val h = Regex("(\\d+)\\s*(?:h|heure|heures)").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: if (n.contains("une heure") || n.contains("1 heure")) 1 else 0
    val m = Regex("(\\d+)\\s*(?:min|minute|minutes)").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    val words = mapOf("demi-heure" to 30, "une demi-heure" to 30, "une heure" to 60, "deux heures" to 120, "trois heures" to 180, "quart d'heure" to 15)
    val total = if (h == 0 && m == 0) words.entries.firstOrNull { n.contains(it.key) }?.value ?: return null else h * 60 + m
    return total.takeIf { it in 5..1440 }
}

/**
 * Retourne les événements dont les périodes se recoupent avec le candidat.
 * Un événement sans heure de fin est traité comme un instant (1 ms) : il
 * chevauche donc une plage qui le contient, ou un autre événement au même instant.
 * Les intervalles sont semi-ouverts : deux événements qui se suivent exactement
 * (fin == début) ne sont pas considérés comme en conflit.
 */
fun findOverlappingEvents(candidate: AgendaEvent, existing: List<AgendaEvent>): List<AgendaEvent> {
    val candidateEnd = candidate.endTimeMillis?.takeIf { it > candidate.timeMillis } ?: (candidate.timeMillis + 1L)
    return existing.asSequence()
        .filterNot { it.id == candidate.id }
        .filter { other ->
            val otherEnd = other.endTimeMillis?.takeIf { it > other.timeMillis } ?: (other.timeMillis + 1L)
            candidate.timeMillis < otherEnd && other.timeMillis < candidateEnd
        }
        .sortedBy { it.timeMillis }
        .toList()
}

fun sameCalendarHour(first: Long, second: Long): Boolean {
    val a = Calendar.getInstance().apply { timeInMillis = first }
    val b = Calendar.getInstance().apply { timeInMillis = second }
    return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR) &&
        a.get(Calendar.HOUR_OF_DAY) == b.get(Calendar.HOUR_OF_DAY)
}

fun calculateOverlapLanes(events: List<AgendaEvent>): Map<Long, Pair<Int, Int>> {
    val sorted = events.sortedBy { it.timeMillis }
    val result = mutableMapOf<Long, Pair<Int, Int>>()
    var cluster = mutableListOf<AgendaEvent>()
    var clusterEnd = Long.MIN_VALUE
    fun flush() {
        if (cluster.isEmpty()) return
        val laneEnds = mutableListOf<Long>()
        val assigned = mutableListOf<Pair<AgendaEvent, Int>>()
        cluster.sortedBy { it.timeMillis }.forEach { event ->
            val end = event.endTimeMillis?.takeIf { it > event.timeMillis }
                ?: (event.timeMillis + 30L * 60L * 1000L)
            val lane = laneEnds.indexOfFirst { it <= event.timeMillis }.let { if (it < 0) laneEnds.size else it }
            if (lane == laneEnds.size) laneEnds.add(end) else laneEnds[lane] = end
            assigned.add(event to lane)
        }
        val count = laneEnds.size.coerceAtLeast(1)
        assigned.forEach { (event, lane) -> result[event.id] = lane to count }
        cluster.clear()
        clusterEnd = Long.MIN_VALUE
    }
    sorted.forEach { event ->
        val end = event.endTimeMillis?.takeIf { it > event.timeMillis }
            ?: (event.timeMillis + 30L * 60L * 1000L)
        if (cluster.isNotEmpty() && event.timeMillis >= clusterEnd) flush()
        cluster.add(event)
        clusterEnd = maxOf(clusterEnd, end)
    }
    flush()
    return result
}
