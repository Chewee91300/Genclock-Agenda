# Bellendar 2.1.0 — English translation

This update adds an English UI layer while keeping French as the default language.

- Select **English** in Settings → Language / Language.
- The selection is stored in the existing `interface` preferences.
- Main Compose interface labels, dialogs, event editor, reminder settings, alarm screen, and reminder/alarm notification labels have English translations.
- The alarm minimum-volume setting remains adjustable up to 100%.
- Version remains 2.1.0 (versionCode 98).

Important validation notes:
- A full Android/Gradle build has not been run in this environment. Run the repository's GitHub Actions workflow to validate compilation and APK generation.
- The voice wizard's date/time parsing examples and parsing logic are still French-specific. English interface translation does not yet mean English-language voice date parsing is supported.
- Some event titles/descriptions entered by the user are preserved as entered and are not machine-translated.
- Other languages remain selectable in the existing menu but are not translated by this English-only update.


Version 2.7.4 : ajout de Deutsch (allemand) dans la sélection de langue, les paramètres, la reconnaissance vocale, les écrans d’alarme et les notifications.
