package fr.bellendar

data class EventAttachment(
    val id: String,
    val name: String,
    val uri: String,
    val mimeType: String
)

data class AgendaEvent(
    val id: Long,
    val title: String,
    val description: String,
    val timeMillis: Long,
    val reminderMode: String, // "notification" ou "alarm"
    val leadMinutes: Int,
    val outlookEventId: Long? = null,
    val alarmTimeMillis: Long? = null,
    val alarmSoundUri: String? = null,
    val vibrate: Boolean = true,
    val attachments: List<EventAttachment> = emptyList(),
    val endTimeMillis: Long? = null,
    // Couleur choisie par événement, indépendante du thème global de l’application.
    val colorHex: String? = null,
    // Règle de récurrence : NONE, DAILY, WEEKLY, MONTHLY, YEARLY ou CUSTOM.
    val recurrenceType: String = "NONE",
    val recurrenceInterval: Int = 1,
    val recurrenceDays: List<Int> = emptyList(), // Calendar.DAY_OF_WEEK
    val recurrenceEndMillis: Long? = null,
    val recurrenceCount: Int? = null,
    // Métadonnées stables des occurrences d'une série.
    val seriesId: Long? = null,
    val originalOccurrenceMillis: Long? = null,
    // Dates d'occurrences supprimées ou remplacées individuellement (sur l'événement maître).
    val recurrenceExcludedMillis: List<Long> = emptyList()
)
