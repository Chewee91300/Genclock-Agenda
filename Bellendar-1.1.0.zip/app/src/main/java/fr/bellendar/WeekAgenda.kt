package fr.bellendar

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle as AndroidBundle
import android.os.Handler
import android.os.Looper
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Timelapse
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

@Composable
internal fun WeekAgenda(
    selected: Long,
    events: List<AgendaEvent>,
    onSelectDay: (Long) -> Unit,
    onEditEvent: (AgendaEvent) -> Unit,
    onAddAtTime: (Long) -> Unit,
    onDeleteEvent: (AgendaEvent) -> Unit,
    showWeekend: Boolean,
    onToggleWeekend: (Boolean) -> Unit,
    clockText: String = "",
    modifier: Modifier = Modifier
) {
    val uiLocale = currentUiLocale()
    var eventPendingDeletion by remember { mutableStateOf<AgendaEvent?>(null) }
    var attachmentTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    val context = LocalContext.current
    val zoomPreferences = remember { context.getSharedPreferences("agenda_ui", android.content.Context.MODE_PRIVATE) }
    var weekZoom by rememberSaveable {
        mutableFloatStateOf(zoomPreferences.getFloat("week_timeline_zoom", 1f).coerceIn(1f, 3f))
    }
    val currentWeekZoom by rememberUpdatedState(weekZoom)
    val currentSelected by rememberUpdatedState(selected)
    val currentOnSelectDay by rememberUpdatedState(onSelectDay)
    // Le repositionnement s'effectue apres la recomposition de la semaine cible.
    var pendingWeekEdge by remember { mutableIntStateOf(0) }
    var pendingWeekFrom by remember { mutableLongStateOf(Long.MIN_VALUE) }
    val timelineScrollState = rememberScrollState(
        initial = zoomPreferences.getInt("week_timeline_scroll", 0).coerceAtLeast(0)
    )
    val horizontalScrollState = rememberScrollState(
        initial = zoomPreferences.getInt("week_horizontal_scroll", 0).coerceAtLeast(0)
    )
    val timelineScope = rememberCoroutineScope()
    LaunchedEffect(selected, pendingWeekEdge) {
        if (pendingWeekEdge != 0 && selected != pendingWeekFrom) {
            // Laisser la nouvelle grille se mesurer avant de lire maxValue.
            androidx.compose.runtime.withFrameNanos { }
            androidx.compose.runtime.withFrameNanos { }
            horizontalScrollState.scrollTo(
                if (pendingWeekEdge < 0) horizontalScrollState.maxValue else 0
            )
            pendingWeekEdge = 0
        }
    }
    LaunchedEffect(timelineScrollState) {
        snapshotFlow { timelineScrollState.value }.collect { offset ->
            zoomPreferences.edit().putInt("week_timeline_scroll", offset).apply()
        }
    }
    LaunchedEffect(horizontalScrollState) {
        snapshotFlow { horizontalScrollState.value }.collect { offset ->
            zoomPreferences.edit().putInt("week_horizontal_scroll", offset).apply()
        }
    }
    var currentTimeMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMillis = System.currentTimeMillis()
            delay(30_000L)
        }
    }
    val nowCalendar = Calendar.getInstance().apply { timeInMillis = currentTimeMillis }
    val nowMinuteOfDay = nowCalendar.get(Calendar.HOUR_OF_DAY) * 60 + nowCalendar.get(Calendar.MINUTE)
    val weekStart = dayStart(selected).apply {
        firstDayOfWeek = Calendar.MONDAY
        minimalDaysInFirstWeek = 4
        set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    }
    val days = (0 until if (showWeekend) 7 else 5).map { index ->
        Calendar.getInstance().apply { timeInMillis = weekStart.timeInMillis; add(Calendar.DAY_OF_MONTH, index) }
    }
    val weekEvents = events.filter { event -> days.any { sameDay(event.timeMillis, it.timeInMillis) } }
    val hasEarly = weekEvents.any { event ->
        val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
        c.get(Calendar.HOUR_OF_DAY) < 7
    }
    val hasLate = weekEvents.any { event ->
        val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
        c.get(Calendar.HOUR_OF_DAY) >= 22 || event.endTimeMillis?.let { end ->
            val ec = Calendar.getInstance().apply { timeInMillis = end }
            ec.get(Calendar.HOUR_OF_DAY) >= 22
        } == true
    }
    val firstHour = if (hasEarly) 0 else 7
    val lastHour = if (hasLate) 24 else 22
    // Le niveau 1x correspond exactement à l'échelle historique : aucun dézoom possible.
    // Le pincement à deux doigts permet uniquement d'agrandir la grille hebdomadaire.
    val minuteHeight = 1.2f * weekZoom
    val density = LocalDensity.current.density
    val rowHeight = 36.dp * weekZoom
    // Largeur minimale confortable pour les libellés horaires "00:00" en 9sp.
    // La colonne de semaine est ainsi réduite sans tronquer les heures ni le numéro ISO.
    val labelWidth = 35.dp
    val timelineHeight = ((lastHour - firstHour) * 60 * minuteHeight).dp
    LaunchedEffect(firstHour, lastHour) {
        val savedOffset = zoomPreferences.getInt("week_timeline_scroll", 0)
        val selectedIsToday = sameDay(selected, System.currentTimeMillis())
        if (savedOffset == 0 && selectedIsToday) {
            // Place l'heure actuelle légèrement au-dessus du centre à la première ouverture.
            delay(60)
            val nowFromStart = (nowMinuteOfDay - firstHour * 60).coerceAtLeast(0)
            val target = (nowFromStart * 1.2f * weekZoom * density - 120f * density).roundToInt()
            timelineScrollState.scrollTo(target.coerceAtLeast(0))
        }
    }
    Column(modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Row(Modifier.fillMaxWidth().heightIn(min = 30.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Planning hebdomadaire"), fontSize = 12.sp, lineHeight = 14.sp,
                fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
            if (clockText.isNotBlank()) {
                Text(clockText, fontSize = 16.sp, lineHeight = 19.sp, fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                    modifier = Modifier.padding(end = 8.dp))
            }
            Text(tr("Week-end"), fontSize = 10.sp, lineHeight = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            Spacer(Modifier.width(3.dp))
            Switch(checked = showWeekend, onCheckedChange = onToggleWeekend)
        }
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val headerColumnWidth = (((maxWidth - labelWidth) * weekZoom - 2.dp * (days.size - 1).toFloat()) / days.size.toFloat())
                .coerceAtLeast(1.dp)
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                // Bandeau du mois : ligne dédiée au-dessus des jours, sans superposition.
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier.width(labelWidth),
                        shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Box(Modifier.height(25.dp), contentAlignment = Alignment.Center) {
                            Text(tr("MOIS"), fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Row(
                        Modifier.weight(1f).horizontalScroll(horizontalScrollState),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Surface(
                            modifier = Modifier.width(headerColumnWidth * days.size + 2.dp * (days.size - 1).toFloat()),
                            shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Box(Modifier.height(25.dp), contentAlignment = Alignment.Center) {
                                val monthLabel = SimpleDateFormat("MMMM yyyy", uiLocale).format(Date(selected))
                                    .replaceFirstChar { it.uppercase(uiLocale) }
                                Text(monthLabel, fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 1)
                            }
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // En-tête horaire fixe : il ne défile jamais avec les jours.
                    Surface(
                        modifier = Modifier.width(labelWidth),
                        shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(Modifier.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(tr("SEM."), fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(String.format(Locale.FRANCE, "%02d", weekStart.get(Calendar.WEEK_OF_YEAR)),
                                fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Row(
                        Modifier.weight(1f).horizontalScroll(horizontalScrollState),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        days.forEach { day ->
                            val isSelected = sameDay(day.timeInMillis, selected)
                            Surface(
                                modifier = Modifier.width(headerColumnWidth).clickable { onSelectDay(day.timeInMillis) },
                                shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Column(Modifier.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(SimpleDateFormat("EEE", uiLocale).format(day.time).replaceFirstChar { it.uppercase(uiLocale) },
                                        fontSize = 9.sp, lineHeight = 10.sp, fontWeight = FontWeight.Bold,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1, softWrap = false)
                                    Text(day.get(Calendar.DAY_OF_MONTH).toString(), fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }
            }
        }
        BoxWithConstraints(
            Modifier.fillMaxWidth().weight(1f)
                // Le détecteur est placé AVANT verticalScroll et écoute la passe Initial :
                // le scroll à un doigt reste natif, mais le pincement à deux doigts
                // est intercepté avant que les cartes d'événements ne consomment le geste.
                .pointerInput(timelineScrollState, horizontalScrollState, firstHour, lastHour) {
                    awaitEachGesture {
                        val firstDown = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        // Une seule bascule de semaine est autorisée par geste, même si
                        // le doigt reste appuyé après avoir atteint le bord horizontal.
                        var weekChangeTriggered = false
                        var previousSpan = 0f
                        var previousPosition = firstDown.position
                        var accumulatedDrag = Offset.Zero
                        var freeDragStarted = false
                        // 0 = non déterminé, 1 = vertical, 2 = horizontal.
                        // On verrouille un seul axe pour éviter qu'un scroll vertical
                        // légèrement diagonal ne change accidentellement de semaine.
                        var gestureAxis = 0
                        var horizontalEdgeDistance = 0f
                        var horizontalWeekSwipeDistance = 0f
                        val dragTouchSlop = viewConfiguration.touchSlop
                        val horizontalDominanceRatio = 1.2f
                        val horizontalStartThreshold = 12.dp.toPx()
                        val weekSwitchThreshold = 48.dp.toPx()
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.size >= 2) {
                                freeDragStarted = false
                                gestureAxis = 0
                                accumulatedDrag = Offset.Zero
                                horizontalEdgeDistance = 0f
                                horizontalWeekSwipeDistance = 0f
                                val p1 = pressed[0].position
                                val p2 = pressed[1].position
                                val dx = p1.x - p2.x
                                val dy = p1.y - p2.y
                                val span = sqrt(dx * dx + dy * dy)
                                val centroidX = (p1.x + p2.x) / 2f
                                val centroidY = (p1.y + p2.y) / 2f
                                if (previousSpan > 0f && span > 1f) {
                                    val factor = span / previousSpan
                                    val oldZoom = currentWeekZoom
                                    val newZoom = (oldZoom * factor).coerceIn(1f, 3f)
                                    if (kotlin.math.abs(newZoom - oldZoom) > 0.001f) {
                                        val focalContentY = timelineScrollState.value + centroidY
                                        val focalMinutes = focalContentY / (density * 1.2f * oldZoom)
                                        val targetScroll = (focalMinutes * 1.2f * newZoom * density - centroidY)
                                            .roundToInt().coerceAtLeast(0)
                                        val fixedLabelPx = labelWidth.value * density
                                        val focalContentX = horizontalScrollState.value + centroidX
                                        val scaledFocalX = if (focalContentX <= fixedLabelPx) focalContentX
                                            else fixedLabelPx + (focalContentX - fixedLabelPx) * (newZoom / oldZoom)
                                        val targetHorizontalScroll = (scaledFocalX - centroidX).roundToInt().coerceAtLeast(0)
                                        weekZoom = newZoom
                                        zoomPreferences.edit().putFloat("week_timeline_zoom", newZoom).apply()
                                        timelineScope.launch {
                                            kotlinx.coroutines.yield()
                                            timelineScrollState.scrollTo(targetScroll)
                                            horizontalScrollState.scrollTo(targetHorizontalScroll)
                                        }
                                    }
                                }
                                previousSpan = span
                                pressed.forEach { it.consume() }
                            } else if (pressed.size == 1) {
                                val change = pressed.first()
                                val delta = change.position - previousPosition
                                if (!freeDragStarted) {
                                    accumulatedDrag += delta
                                    if (accumulatedDrag.getDistance() > dragTouchSlop) {
                                        val absX = kotlin.math.abs(accumulatedDrag.x)
                                        val absY = kotlin.math.abs(accumulatedDrag.y)
                                        // Ne verrouille pas trop tôt l'axe vertical sur un petit
                                        // mouvement diagonal : on attend un vrai déplacement
                                        // dominant avant de choisir l'axe du geste.
                                        val horizontalIntent = absX >= horizontalStartThreshold &&
                                            absX >= absY * 0.85f
                                        val verticalIntent = absY >= 22.dp.toPx() &&
                                            absY > absX * horizontalDominanceRatio
                                        if (horizontalIntent || verticalIntent) {
                                            freeDragStarted = true
                                            gestureAxis = if (horizontalIntent) 2 else 1
                                            change.consume()
                                            val dragToApply = accumulatedDrag
                                            accumulatedDrag = Offset.Zero
                                            timelineScope.launch {
                                                if (gestureAxis == 1) {
                                                    timelineScrollState.scrollBy(-dragToApply.y)
                                                } else {
                                                if (currentWeekZoom <= 1.05f) {
                                                    horizontalWeekSwipeDistance += kotlin.math.abs(dragToApply.x)
                                                    if (!weekChangeTriggered && horizontalWeekSwipeDistance >= weekSwitchThreshold) {
                                                        weekChangeTriggered = true
                                                        val nextSelected = Calendar.getInstance().apply {
                                                            timeInMillis = currentSelected
                                                            add(Calendar.DAY_OF_MONTH, if (dragToApply.x < 0f) 7 else -7)
                                                        }.timeInMillis
                                                        pendingWeekFrom = currentSelected
                                                        pendingWeekEdge = if (dragToApply.x < 0f) 1 else -1
                                                        currentOnSelectDay(nextSelected)

                                                    }
                                                } else {
                                                    val max = horizontalScrollState.maxValue
                                                    val consumed = horizontalScrollState.scrollBy(-dragToApply.x)
                                                    val draggingBeyondEdge =
                                                        (dragToApply.x < 0f && horizontalScrollState.value >= max - 2 && consumed < -dragToApply.x - 1f) ||
                                                        (dragToApply.x > 0f && horizontalScrollState.value <= 2 && consumed > -dragToApply.x + 1f)
                                                    horizontalEdgeDistance = if (draggingBeyondEdge) horizontalEdgeDistance + kotlin.math.abs(dragToApply.x) else 0f
                                                    if (!weekChangeTriggered && horizontalEdgeDistance >= weekSwitchThreshold) {
                                                        weekChangeTriggered = true
                                                        val nextSelected = Calendar.getInstance().apply {
                                                            timeInMillis = currentSelected
                                                            add(Calendar.DAY_OF_MONTH, if (dragToApply.x < 0f) 7 else -7)
                                                        }.timeInMillis
                                                        pendingWeekFrom = currentSelected
                                                        pendingWeekEdge = if (dragToApply.x < 0f) 1 else -1
                                                        currentOnSelectDay(nextSelected)
                                                    }
                                                }
                                            }
                                        }
                                            }
                                        }
                                } else {
                                    change.consume()
                                    timelineScope.launch {
                                        if (gestureAxis == 1) {
                                            // Axe vertical verrouillé : aucune variation latérale
                                            // ne peut déclencher le changement de semaine.
                                            timelineScrollState.scrollBy(-delta.y)
                                        } else if (gestureAxis == 2) {
                                            if (currentWeekZoom <= 1.05f) {
                                                horizontalWeekSwipeDistance += kotlin.math.abs(delta.x)
                                                if (!weekChangeTriggered && horizontalWeekSwipeDistance >= weekSwitchThreshold) {
                                                    weekChangeTriggered = true
                                                    val nextSelected = Calendar.getInstance().apply {
                                                        timeInMillis = currentSelected
                                                        add(Calendar.DAY_OF_MONTH, if (delta.x < 0f) 7 else -7)
                                                    }.timeInMillis
                                                    pendingWeekFrom = currentSelected
                                                        pendingWeekEdge = if (delta.x < 0f) 1 else -1
                                                    currentOnSelectDay(nextSelected)
                                                }
                                            } else {
                                                val max = horizontalScrollState.maxValue
                                                val consumed = horizontalScrollState.scrollBy(-delta.x)
                                                val draggingBeyondEdge =
                                                    (delta.x < 0f && horizontalScrollState.value >= max - 2 && consumed < -delta.x - 1f) ||
                                                    (delta.x > 0f && horizontalScrollState.value <= 2 && consumed > -delta.x + 1f)
                                                horizontalEdgeDistance = if (draggingBeyondEdge) horizontalEdgeDistance + kotlin.math.abs(delta.x) else 0f
                                                if (!weekChangeTriggered && horizontalEdgeDistance >= weekSwitchThreshold) {
                                                    weekChangeTriggered = true
                                                    val nextSelected = Calendar.getInstance().apply {
                                                        timeInMillis = currentSelected
                                                        add(Calendar.DAY_OF_MONTH, if (delta.x < 0f) 7 else -7)
                                                    }.timeInMillis
                                                    pendingWeekFrom = currentSelected
                                                        pendingWeekEdge = if (delta.x < 0f) 1 else -1
                                                        currentOnSelectDay(nextSelected)

                                                }
                                            }
                                        }
                                    }
                                }
                                previousPosition = change.position
                                previousSpan = 0f
                            } else {
                                previousSpan = 0f
                                freeDragStarted = false
                                gestureAxis = 0
                                accumulatedDrag = Offset.Zero
                                horizontalEdgeDistance = 0f
                                horizontalWeekSwipeDistance = 0f
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .verticalScroll(timelineScrollState)
        ) {
            val gridWidth = labelWidth + (maxWidth - labelWidth) * weekZoom
            val columnWidth = ((gridWidth - labelWidth - 2.dp * (days.size - 1).toFloat()) / days.size.toFloat()).coerceAtLeast(1.dp)
            Row(Modifier.fillMaxWidth()) {
            // La colonne des heures reste fixe pendant le défilement horizontal des jours.
            Column(Modifier.width(labelWidth).height(timelineHeight)) {
                repeat(lastHour - firstHour) { index ->
                    Box(Modifier.height(rowHeight).fillMaxWidth()) {
                        Text(String.format(Locale.FRANCE, "%02d:00", firstHour + index),
                            fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.align(Alignment.TopStart))
                    }
                    Box(Modifier.height(rowHeight).fillMaxWidth()) {
                        Text(String.format(Locale.FRANCE, "%02d:30", firstHour + index),
                            fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.align(Alignment.TopStart))
                    }
                }
            }
            Row(Modifier.weight(1f).horizontalScroll(horizontalScrollState)) {
            Box(
                Modifier.width(gridWidth - labelWidth).height(timelineHeight)
                    .pointerInput(selected, firstHour, lastHour, showWeekend, minuteHeight) {
                detectTapGestures(onDoubleTap = { offset ->
                    val xDp = offset.x / density
                    val colW = (size.width / density - 2f * (days.size - 1)) / days.size
                    val index = ((xDp / (colW + 2f)).toInt()).coerceIn(0, days.lastIndex)
                    val minutes = (firstHour * 60 + (offset.y / density / minuteHeight).toInt()).coerceIn(0, 1439)
                    val snapped = ((minutes + 2) / 5) * 5
                    val target = (days[index].clone() as Calendar).apply {
                        set(Calendar.HOUR_OF_DAY, (snapped / 60).coerceAtMost(23)); set(Calendar.MINUTE, snapped % 60)
                        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    }
                    onAddAtTime(target.timeInMillis)
                })
            }) {
                Row(Modifier.fillMaxWidth()) {
                    days.forEach { day ->
                        Box(Modifier.width(columnWidth).height(timelineHeight)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.22f))) {
                            Column(Modifier.fillMaxWidth()) {
                                repeat((lastHour - firstHour) * 2) {
                                    Box(Modifier.fillMaxWidth().height(rowHeight)) {
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.75f))
                                    }
                                }
                            }
                            val dayItems = weekEvents.filter { sameDay(it.timeMillis, day.timeInMillis) }
                            val dayLanes = remember(dayItems) { calculateOverlapLanes(dayItems) }
                            dayItems.forEach { event ->
                                val lane = dayLanes[event.id]?.first ?: 0
                                val laneCount = dayLanes[event.id]?.second ?: 1
                                val cal = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                                val startMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                                val end = event.endTimeMillis?.takeIf { it > event.timeMillis }
                                val duration = end?.let { ((it - event.timeMillis) / 60000L).toInt() } ?: 30
                                val y = ((startMinutes - firstHour * 60).coerceAtLeast(0) * minuteHeight).dp
                                var measuredTitleHeightPx by remember(event.id, columnWidth, laneCount, weekZoom) { mutableIntStateOf(0) }
                                val h = if (end == null) {
                                    if (measuredTitleHeightPx > 0) (measuredTitleHeightPx / density).dp + 18.dp
                                    else 36.dp
                                } else (duration * minuteHeight).coerceAtLeast(28f).dp
                                val eventBackground = parseEventColor(event.colorHex)
                                    ?: when (event.reminderMode.lowercase()) {
                                        "alarm" -> Color(0xFFFFDAD6)
                                        "both" -> Color(0xFFE6D9F5)
                                        "notification" -> Color(0xFFD7E8FF)
                                        else -> MaterialTheme.colorScheme.secondaryContainer
                                    }
                                val eventForeground = eventTextColor(eventBackground)
                                Surface(
                                    modifier = Modifier.offset(x = columnWidth * lane / laneCount, y = y)
                                        .width((columnWidth / laneCount).coerceAtLeast(24.dp)).height(h)
                                        .padding(horizontal = 1.dp, vertical = 1.dp)
                                        .pointerInput(event.id, y, firstHour) {
                                            detectTapGestures(
                                                onLongPress = { eventPendingDeletion = event },
                                                onTap = { onEditEvent(event) },
                                                onDoubleTap = { tap ->
                                                    val absoluteY = y.value * density + tap.y
                                                    val minutes = (firstHour * 60 + (absoluteY / (density * minuteHeight)).toInt()).coerceIn(0, 1439)
                                                    val snapped = ((minutes + 2) / 5) * 5
                                                    val target = (day.clone() as Calendar).apply {
                                                        set(Calendar.HOUR_OF_DAY, (snapped / 60).coerceAtMost(23)); set(Calendar.MINUTE, snapped % 60)
                                                        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                                                    }
                                                    onAddAtTime(target.timeInMillis)
                                                }
                                            )
                                        },
                                    shape = RoundedCornerShape(5.dp),
                                    color = eventBackground
                                ) {
                                    Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 1.dp), verticalArrangement = Arrangement.Top) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(event.title, modifier = Modifier.weight(1f), fontSize = 10.sp, lineHeight = 11.sp,
                                                color = eventForeground,
                                                onTextLayout = { layout ->
                                                    if (end == null && measuredTitleHeightPx != layout.size.height) {
                                                        measuredTitleHeightPx = layout.size.height
                                                    }
                                                },
                                                maxLines = if (end == null) Int.MAX_VALUE else 4,
                                                overflow = if (end == null) TextOverflow.Clip else TextOverflow.Ellipsis)
                                            val hasNotification = event.reminderMode == "notification" || event.reminderMode == "both"
                                            val hasAlarm = event.reminderMode == "alarm" || event.reminderMode == "both"
                                            if (hasNotification) {
                                                Icon(Icons.Default.Notifications, contentDescription = tr("Notification programmée"),
                                                    tint = eventForeground, modifier = Modifier.size(11.dp))
                                            }
                                            if (hasAlarm) {
                                                Icon(Icons.Default.Alarm, contentDescription = tr("Alarme programmée"),
                                                    tint = eventForeground, modifier = Modifier.size(11.dp))
                                            }
                                            if (event.attachments.isNotEmpty()) {
                                                Icon(Icons.Default.AttachFile, contentDescription = tr("Ouvrir les pièces jointes"),
                                                    tint = eventForeground,
                                                    modifier = Modifier.size(11.dp).clickable { attachmentTarget = event })
                                            }
                                        }
                                        Text(SimpleDateFormat("HH:mm", uiLocale).format(Date(event.timeMillis)),
                                            fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.Bold,
                                            color = eventForeground, maxLines = 1)
                                    }
                                }
                            }
                            // Curseur de l'heure actuelle : affiché uniquement dans la colonne du jour courant.
                            if (sameDay(day.timeInMillis, currentTimeMillis) &&
                                nowMinuteOfDay >= firstHour * 60 && nowMinuteOfDay < lastHour * 60) {
                                val nowY = ((nowMinuteOfDay - firstHour * 60) * minuteHeight).dp
                                val eventUnderCursor = weekEvents.firstOrNull { event ->
                                    val visualEnd = event.endTimeMillis?.takeIf { it > event.timeMillis }
                                        ?: (event.timeMillis + 30L * 60L * 1000L)
                                    sameDay(event.timeMillis, day.timeInMillis) &&
                                        currentTimeMillis >= event.timeMillis && currentTimeMillis < visualEnd
                                }
                                val cursorColor = eventUnderCursor?.let { event ->
                                    val bg = parseEventColor(event.colorHex) ?: when (event.reminderMode.lowercase()) {
                                        "alarm" -> Color(0xFFFFDAD6)
                                        "both" -> Color(0xFFE6D9F5)
                                        "notification" -> Color(0xFFD7E8FF)
                                        else -> MaterialTheme.colorScheme.secondaryContainer
                                    }
                                    eventTextColor(bg)
                                } ?: Color(0xFFE53935)
                                Row(
                                    modifier = Modifier
                                        .offset(y = nowY - 3.dp)
                                        .fillMaxWidth()
                                        .height(7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.size(7.dp)
                                            .background(cursorColor, RoundedCornerShape(50))
                                    )
                                    Box(
                                        Modifier.weight(1f).height(2.dp)
                                            .background(cursorColor)
                                    )
                                }
                            }
                        }
                        if (day != days.last()) Spacer(Modifier.width(2.dp))
                    }
                }
            }
            }
        }
    }
    eventPendingDeletion?.let { event ->
        AlertDialog(
            onDismissRequest = { eventPendingDeletion = null },
            title = { Text(tr("Supprimer l’événement ?")) },
            text = { Text(tr("Voulez-vous vraiment supprimer « ${event.title} » ?")) },
            confirmButton = {
                TextButton(onClick = { onDeleteEvent(event); eventPendingDeletion = null }) { Text(tr("Supprimer")) }
            },
            dismissButton = {
                TextButton(onClick = { eventPendingDeletion = null }) { Text(tr("Annuler")) }
            }
        )
    }
    attachmentTarget?.let { event ->
        AlertDialog(
            onDismissRequest = { attachmentTarget = null },
            title = { Text(tr("Pièces jointes")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    event.attachments.forEach { attachment ->
                        TextButton(onClick = {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(attachment.uri), attachment.mimeType.ifBlank { "*/*" })
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            runCatching { context.startActivity(intent) }
                            attachmentTarget = null
                        }) {
                            Icon(Icons.Default.InsertDriveFile, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(attachment.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { attachmentTarget = null }) { Text(tr("Fermer")) } }
        )
    }
}
}
