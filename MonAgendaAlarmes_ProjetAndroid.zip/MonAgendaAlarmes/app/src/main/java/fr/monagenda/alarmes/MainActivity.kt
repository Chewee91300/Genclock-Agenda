package fr.monagenda.alarmes

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen() {
    val context = LocalContext.current
    val store = remember { EventStore(context) }
    var events by remember { mutableStateOf(store.load()) }
    var showEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Mon Agenda & Alarmes", fontWeight = FontWeight.Bold) }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showEditor = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un événement")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                Text("Mes événements", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                if (events.isEmpty()) {
                    Text("Aucun événement. Appuyez sur + pour créer votre premier rendez-vous.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(events, key = { it.id }) { event ->
                            EventCard(
                                event = event,
                                onDelete = {
                                    ReminderScheduler.cancel(context, event)
                                    events = events.filterNot { it.id == event.id }
                                    store.save(events)
                                },
                                onAlarm = { createClockAlarm(context, event, onError = { message = it }) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        EventEditor(
            onDismiss = { showEditor = false },
            onSave = { title, desc, time, mode, lead ->
                val event = AgendaEvent(System.currentTimeMillis(), title, desc, time, mode, lead)
                events = (events + event).sortedBy { it.timeMillis }
                store.save(events)
                if (mode == "notification") ReminderScheduler.schedule(context, event)
                showEditor = false
                if (mode == "alarm") createClockAlarm(context, event) { message = it }
            }
        )
    }

    message?.let {
        AlertDialog(onDismissRequest = { message = null }, confirmButton = {
            TextButton(onClick = { message = null }) { Text("OK") }
        }, title = { Text("Information") }, text = { Text(it) })
    }
}

@Composable
fun EventCard(event: AgendaEvent, onDelete: () -> Unit, onAlarm: () -> Unit) {
    val date = remember(event.timeMillis) {
        SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(event.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(date, style = MaterialTheme.typography.bodyMedium)
            if (event.description.isNotBlank()) Text(event.description)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (event.reminderMode == "alarm") Icon(Icons.Default.Alarm, contentDescription = null)
                else Icon(Icons.Default.Notifications, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(
                    (if (event.reminderMode == "alarm") "Alarme Horloge" else "Notification") +
                        " · ${event.leadMinutes} min avant"
                )
            }
            if (event.reminderMode == "alarm") {
                TextButton(onClick = onAlarm) { Text("Créer à nouveau dans Horloge") }
            }
            TextButton(onClick = onDelete) { Text("Supprimer") }
        }
    }
}

@Composable
fun EventEditor(
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String, Int) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("notification") }
    var lead by remember { mutableStateOf("15") }
    var customLead by remember { mutableStateOf("45") }
    var selectedTime by remember { mutableLongStateOf(System.currentTimeMillis() + 3_600_000L) }
    var error by remember { mutableStateOf(false) }

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedTime }
    val dateText = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(selectedTime))
    val timeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(selectedTime))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouvel événement") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Titre") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("Description (facultatif)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(y, m, d)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text(dateText) }
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(Calendar.HOUR_OF_DAY, h)
                                set(Calendar.MINUTE, m)
                                set(Calendar.SECOND, 0)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    }) { Text(timeText) }
                }
                Text("Type de rappel", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "notification", { mode = "notification" })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "alarm", { mode = "alarm" })
                    Text("Véritable alarme Android")
                }
                Text("Délai avant l'événement", fontWeight = FontWeight.SemiBold)
                val choices = listOf("0" to "À l'heure", "5" to "5 min", "15" to "15 min", "30" to "30 min", "60" to "1 h", "1440" to "La veille", "custom" to "Personnalisé")
                choices.chunked(3).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { (value, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(lead == value, { lead = value })
                                Text(label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (lead == "custom") {
                    OutlinedTextField(
                        customLead, { customLead = it.filter(Char::isDigit).take(5) },
                        label = { Text("Minutes avant") },
                        singleLine = true
                    )
                }
                if (error) Text("Saisissez un titre, une date future et un délai valide.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val minutes = if (lead == "custom") customLead.toIntOrNull() else lead.toIntOrNull()
                if (title.isBlank() || selectedTime <= System.currentTimeMillis() || minutes == null || minutes < 0) {
                    error = true
                } else {
                    onSave(title.trim(), description.trim(), selectedTime, mode, minutes)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

fun createClockAlarm(context: android.content.Context, event: AgendaEvent, onError: (String) -> Unit) {
    val alarmTime = Calendar.getInstance().apply {
        timeInMillis = event.timeMillis - event.leadMinutes * 60_000L
    }
    if (alarmTime.timeInMillis <= System.currentTimeMillis()) {
        onError("Le délai choisi place l'alarme dans le passé. Modifiez l'heure ou le délai.")
        return
    }
    val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
        putExtra(AlarmClock.EXTRA_HOUR, alarmTime.get(Calendar.HOUR_OF_DAY))
        putExtra(AlarmClock.EXTRA_MINUTES, alarmTime.get(Calendar.MINUTE))
        putExtra(AlarmClock.EXTRA_MESSAGE, event.title)
        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
    }
    if (intent.resolveActivity(context.packageManager) != null) {
        context.startActivity(intent)
    } else {
        onError("Aucune application Horloge compatible n'a été trouvée sur ce téléphone.")
    }
}
