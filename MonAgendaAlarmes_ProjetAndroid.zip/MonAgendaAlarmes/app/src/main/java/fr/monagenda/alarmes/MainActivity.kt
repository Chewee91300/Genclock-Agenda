package fr.monagenda.alarmes

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen() {
    val context = LocalContext.current
    val store = remember { EventStore(context) }
    var events by remember { mutableStateOf(store.load()) }
    var showEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var view by remember { mutableStateOf("Mois") }
    var selectedDay by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var outlookEvents by remember { mutableStateOf(emptyList<AgendaEvent>()) }
    val allEvents = remember(events, outlookEvents) { (events + outlookEvents).distinctBy { it.id }.sortedBy { it.timeMillis } }

    val calendarPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        } else {
            message = "Autorisation de lecture du calendrier refusée. Active-la dans les paramètres Android pour afficher les événements Outlook."
        }
    }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        // Première ouverture : demander l'accès au calendrier pour pouvoir importer Outlook.
        if (!OutlookCalendarReader.hasPermission(context)) {
            calendarPermission.launch(Manifest.permission.READ_CALENDAR)
        } else {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Actualisation automatique à chaque retour de l'application au premier plan.
    val lifecycle = (context as? ComponentActivity)?.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && OutlookCalendarReader.hasPermission(context)) {
                outlookEvents = OutlookCalendarReader.readEvents(context)
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(
                title = { Text("Mon Agenda & Alarmes", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = {
                        if (OutlookCalendarReader.hasPermission(context)) {
                            outlookEvents = OutlookCalendarReader.readEvents(context)
                            message = "Calendrier synchronisé actualisé."
                        } else {
                            calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                        }
                    }) { Icon(Icons.Default.Refresh, contentDescription = "Actualiser Outlook") }
                }
            ) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showEditor = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un événement")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Jour", "Semaine", "Mois").forEach { label ->
                        FilterChip(selected = view == label, onClick = { view = label }, label = { Text(label) })
                    }
                }
                CalendarNavigator(view, selectedDay, onPrevious = { selectedDay = shiftDate(selectedDay, view, -1) },
                    onNext = { selectedDay = shiftDate(selectedDay, view, 1) }, onToday = { selectedDay = System.currentTimeMillis() })
                when (view) {
                    "Jour" -> DayAgenda(selectedDay, allEvents)
                    "Semaine" -> WeekAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it })
                    else -> MonthAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it })
                }
                Spacer(Modifier.height(12.dp))
                Text("Événements du ${SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(selectedDay))}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val dayEvents = allEvents.filter { sameDay(it.timeMillis, selectedDay) }.sortedBy { it.timeMillis }
                if (dayEvents.isEmpty()) Text("Aucun événement ce jour.", Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    items(dayEvents, key = { it.id }) { event ->
                        EventCard(event, onDelete = {
                            if (event.reminderMode != "outlook") {
                                ReminderScheduler.cancel(context, event)
                                events = events.filterNot { it.id == event.id }
                                store.save(events)
                            }
                        }, onAlarm = { createClockAlarm(context, event) { message = it } })
                    }
                }
            }
        }
    }

    if (showEditor) {
        EventEditor(
            onDismiss = { showEditor = false },
            onSave = { title, desc, time, mode, lead ->
                val event = AgendaEvent(System.currentTimeMillis(), title, desc, time, mode, lead)
                events = (events + event).sortedBy { it.timeMillis }
                store.save(events)
                if (mode == "notification") ReminderScheduler.schedule(context, event)
                showEditor = false
                selectedDay = time
                if (mode == "alarm") createClockAlarm(context, event) { message = it }
            }
        )
    }
    message?.let {
        AlertDialog(onDismissRequest = { message = null }, confirmButton = {
            TextButton(onClick = { message = null }) { Text("OK") }
        }, title = { Text("Information") }, text = { Text(it) })
    }
}

private fun dayStart(time: Long): Calendar = Calendar.getInstance().apply {
    timeInMillis = time
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}
private fun sameDay(a: Long, b: Long): Boolean {
    val x = dayStart(a); val y = dayStart(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}
private fun shiftDate(time: Long, view: String, amount: Int): Long = Calendar.getInstance().apply {
    timeInMillis = time
    add(when(view) { "Jour" -> Calendar.DAY_OF_MONTH; "Semaine" -> Calendar.WEEK_OF_YEAR; else -> Calendar.MONTH }, amount)
}.timeInMillis

@Composable
private fun CalendarNavigator(view: String, selected: Long, onPrevious: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    val title = when(view) {
        "Jour" -> SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date(selected))
        "Semaine" -> {
            val c = dayStart(selected); c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            val first = c.timeInMillis; c.add(Calendar.DAY_OF_MONTH, 6)
            SimpleDateFormat("d MMM", Locale.FRANCE).format(Date(first)) + " – " + SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(c.time)
        }
        else -> SimpleDateFormat("MMMM yyyy", Locale.FRANCE).format(Date(selected))
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        IconButton(onClick = onPrevious) { Icon(Icons.Default.ChevronLeft, "Période précédente") }
        Text(title.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onToday) { Text("Aujourd'hui") }
            IconButton(onClick = onNext) { Icon(Icons.Default.ChevronRight, "Période suivante") }
        }
    }
}

@Composable
private fun DayAgenda(selected: Long, events: List<AgendaEvent>) {
    val hours = (0..23).toList()
    Column(Modifier.fillMaxWidth().heightIn(max = 230.dp).padding(bottom = 6.dp)) {
        Text("Planning horaire", style = MaterialTheme.typography.labelLarge)
        LazyColumn { items(hours) { hour ->
            val atHour = events.filter { sameDay(it.timeMillis, selected) && Calendar.getInstance().apply { timeInMillis = it.timeMillis }.get(Calendar.HOUR_OF_DAY) == hour }
            Row(Modifier.fillMaxWidth().heightIn(min = 28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(String.format(Locale.FRANCE, "%02d:00", hour), modifier = Modifier.width(52.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                HorizontalDivider(Modifier.weight(1f))
                if (atHour.isNotEmpty()) Text("  ${atHour.joinToString { it.title }}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        } }
    }
}

@Composable
private fun WeekAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit) {
    val start = dayStart(selected).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }
    Column(Modifier.fillMaxWidth().heightIn(max = 230.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(7) { index ->
            val day = Calendar.getInstance().apply { timeInMillis = start.timeInMillis; add(Calendar.DAY_OF_MONTH, index) }
            val dayEvents = events.filter { sameDay(it.timeMillis, day.timeInMillis) }
            OutlinedButton(onClick = { onSelectDay(day.timeInMillis) }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)) {
                Text(SimpleDateFormat("EEE d", Locale.FRANCE).format(day.time).replaceFirstChar { it.uppercase() }, modifier = Modifier.width(75.dp))
                Text(if (dayEvents.isEmpty()) "—" else dayEvents.joinToString(" · ") { SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(it.timeMillis)) + " " + it.title }, maxLines = 1)
            }
        }
    }
}

@Composable
private fun MonthAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit) {
    val month = Calendar.getInstance().apply { timeInMillis = selected; set(Calendar.DAY_OF_MONTH, 1) }
    val offset = (month.get(Calendar.DAY_OF_WEEK) - month.firstDayOfWeek + 7) % 7
    val days = (0 until offset).map { 0 } + (1..month.getActualMaximum(Calendar.DAY_OF_MONTH)).toList()
    Column(Modifier.fillMaxWidth().heightIn(max = 230.dp)) {
        Row(Modifier.fillMaxWidth()) { listOf("L", "M", "M", "J", "V", "S", "D").forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Bold) } }
        days.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { number ->
                    Box(Modifier.weight(1f).height(34.dp), contentAlignment = Alignment.Center) {
                        if (number > 0) {
                            val date = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; set(Calendar.DAY_OF_MONTH, number) }
                            val count = events.count { sameDay(it.timeMillis, date.timeInMillis) }
                            Surface(onClick = { onSelectDay(date.timeInMillis) }, shape = MaterialTheme.shapes.small,
                                color = if (sameDay(date.timeInMillis, selected)) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
                                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(number.toString(), style = MaterialTheme.typography.bodySmall)
                                    if (count > 0) Text("•".repeat(count.coerceAtMost(3)), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
                repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Text("• Notification    • Alarme Horloge", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun EventCard(event: AgendaEvent, onDelete: () -> Unit, onAlarm: () -> Unit) {
    val date = remember(event.timeMillis) {
        SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(event.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(date, style = MaterialTheme.typography.bodyMedium)
            if (event.description.isNotBlank()) Text(event.description)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (event.reminderMode == "alarm") Icon(Icons.Default.Alarm, contentDescription = null)
                else if (event.reminderMode == "outlook") Icon(Icons.Default.CalendarMonth, contentDescription = null)
                else Icon(Icons.Default.Notifications, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(
                    (when (event.reminderMode) {
                        "alarm" -> "Alarme Horloge"
                        "outlook" -> "Événement du calendrier synchronisé"
                        else -> "Notification"
                    }) + if (event.reminderMode == "outlook") "" else " · ${event.leadMinutes} min avant"
                )
            }
            if (event.reminderMode == "alarm") {
                TextButton(onClick = onAlarm) { Text("Créer à nouveau dans Horloge") }
            }
            if (event.reminderMode != "outlook") TextButton(onClick = onDelete) { Text("Supprimer") }
        }
    }
}

@Composable
fun EventEditor(
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String, Int) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("notification") }
    var lead by remember { mutableStateOf("15") }
    var customLead by remember { mutableStateOf("45") }
    var selectedTime by remember { mutableLongStateOf(System.currentTimeMillis() + 3_600_000L) }
    var error by remember { mutableStateOf(false) }

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedTime }
    val dateText = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(selectedTime))
    val timeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(selectedTime))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouvel événement") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Titre") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("Description (facultatif)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(y, m, d)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text(dateText) }
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(Calendar.HOUR_OF_DAY, h)
                                set(Calendar.MINUTE, m)
                                set(Calendar.SECOND, 0)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    }) { Text(timeText) }
                }
                Text("Type de rappel", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "notification", { mode = "notification" })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "alarm", { mode = "alarm" })
                    Text("Véritable alarme Android")
                }
                Text("Délai avant l'événement", fontWeight = FontWeight.SemiBold)
                val choices = listOf("0" to "À l'heure", "5" to "5 min", "15" to "15 min", "30" to "30 min", "60" to "1 h", "1440" to "La veille", "custom" to "Personnalisé")
                choices.chunked(3).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { (value, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(lead == value, { lead = value })
                                Text(label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (lead == "custom") {
                    OutlinedTextField(
                        customLead, { customLead = it.filter(Char::isDigit).take(5) },
                        label = { Text("Minutes avant") },
                        singleLine = true
                    )
                }
                if (error) Text("Saisissez un titre, une date future et un délai valide.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val minutes = if (lead == "custom") customLead.toIntOrNull() else lead.toIntOrNull()
                if (title.isBlank() || selectedTime <= System.currentTimeMillis() || minutes == null || minutes < 0) {
                    error = true
                } else {
                    onSave(title.trim(), description.trim(), selectedTime, mode, minutes)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

fun createClockAlarm(context: android.content.Context, event: AgendaEvent, onError: (String) -> Unit) {
    val alarmTime = Calendar.getInstance().apply {
        timeInMillis = event.timeMillis - event.leadMinutes * 60_000L
    }
    if (alarmTime.timeInMillis <= System.currentTimeMillis()) {
        onError("Le délai choisi place l'alarme dans le passé. Modifiez l'heure ou le délai.")
        return
    }
    val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
        putExtra(AlarmClock.EXTRA_HOUR, alarmTime.get(Calendar.HOUR_OF_DAY))
        putExtra(AlarmClock.EXTRA_MINUTES, alarmTime.get(Calendar.MINUTE))
        putExtra(AlarmClock.EXTRA_MESSAGE, event.title)
        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
    }
    if (intent.resolveActivity(context.packageManager) != null) {
        context.startActivity(intent)
    } else {
        onError("Aucune application Horloge compatible n'a été trouvée sur ce téléphone.")
    }
}
