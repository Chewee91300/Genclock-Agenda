Bellendar 1.1.41

Correction de la modification des événements importés depuis un calendrier Android/Outlook :
- une modification utilise l'identifiant de l'événement source ;
- elle cible le calendrier d'origine au lieu de chercher un calendrier de destination sélectionné ;
- les événements importés (identifiants Bellendar négatifs) ne sont plus ignorés par la synchronisation ;
- les événements importés ne sont pas recréés en doublon ;
- l'enregistrement local reste prioritaire si la modification du calendrier source échoue.

Version 1.1.41 / versionCode 51.
Compilation Android non exécutée dans cet environnement.
