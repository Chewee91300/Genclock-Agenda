package fr.monagenda.alarmes

import android.app.AlarmManager
import android.provider.Settings
import android.net.Uri
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen() {
    val context = LocalContext.current
    val store = remember { EventStore(context) }
    var events by remember { mutableStateOf(store.load()) }
    var showEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var showExactAlarmDialog by remember { mutableStateOf(false) }
    var showDayEvents by remember { mutableStateOf(true) }
    var showAbout by remember { mutableStateOf(false) }
    var outlookDeleteTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var outlookReminderTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val appVersion = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "inconnue" }.getOrDefault("inconnue")
    }
    var view by remember { mutableStateOf("Mois") }
    var selectedDay by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var outlookEvents by remember { mutableStateOf(emptyList<AgendaEvent>()) }
    val allEvents = remember(events, outlookEvents) { (events + outlookEvents).distinctBy { it.id }.sortedBy { it.timeMillis } }

    val calendarPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        } else {
            message = "Autorisation de lecture du calendrier refusée. Active-la dans les paramètres Android pour afficher les événements Outlook."
        }
    }

    val outlookWritePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val target = outlookDeleteTarget
        if (granted && target != null) {
            if (OutlookCalendarReader.deleteEvent(context, target)) {
                ReminderScheduler.cancel(context, target)
                events = events.filterNot { it.id == target.id }
                store.save(events)
                outlookEvents = OutlookCalendarReader.readEvents(context)
                message = "Événement Outlook supprimé."
            } else message = "La suppression a échoué. Vérifie les droits du calendrier synchronisé."
        } else if (!granted) message = "Autorisation de modification du calendrier refusée."
        outlookDeleteTarget = null
    }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    fun exactAlarmsAllowed(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) return true
        val manager = context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager
        return manager.canScheduleExactAlarms()
    }

    LaunchedEffect(Unit) {
        while (true) {
            clockNow = System.currentTimeMillis()
            delay(1000)
        }
    }

    LaunchedEffect(Unit) {
        if (!exactAlarmsAllowed()) showExactAlarmDialog = true
        // Première ouverture : demander l'accès au calendrier pour pouvoir importer Outlook.
        if (!OutlookCalendarReader.hasPermission(context)) {
            calendarPermission.launch(Manifest.permission.READ_CALENDAR)
        } else {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Actualisation automatique à chaque retour de l'application au premier plan.
    val lifecycle = (context as? ComponentActivity)?.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (OutlookCalendarReader.hasPermission(context)) outlookEvents = OutlookCalendarReader.readEvents(context)
                if (!exactAlarmsAllowed()) showExactAlarmDialog = true
                store.load().forEach { saved ->
                    when (saved.reminderMode) {
                        "alarm" -> if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        "notification" -> ReminderScheduler.schedule(context, saved)
                    }
                }
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(
                title = { Text("Mon Agenda & Alarmes", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = { showAbout = true }) { Text("À propos de") }
                    IconButton(onClick = {
                        if (OutlookCalendarReader.hasPermission(context)) {
                            outlookEvents = OutlookCalendarReader.readEvents(context)
                            message = "Calendrier synchronisé actualisé."
                        } else {
                            calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                        }
                    }) { Icon(Icons.Default.Refresh, contentDescription = "Actualiser Outlook") }
                }
            ) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showEditor = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un événement")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Jour", "Semaine", "Mois").forEach { label ->
                            FilterChip(selected = view == label, onClick = { view = label }, label = { Text(label) })
                        }
                    }
                    Text(SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date(clockNow)), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                CalendarNavigator(view, selectedDay, onPrevious = { selectedDay = shiftDate(selectedDay, view, -1) },
                    onNext = { selectedDay = shiftDate(selectedDay, view, 1) }, onToday = { selectedDay = System.currentTimeMillis() })
                when (view) {
                    "Jour" -> DayAgenda(selectedDay, allEvents, expanded = !showDayEvents)
                    "Semaine" -> WeekAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                    else -> MonthAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                }
                val dayEvents = allEvents.filter { sameDay(it.timeMillis, selectedDay) }.sortedBy { it.timeMillis }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Événements du ${SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(selectedDay))}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { showDayEvents = !showDayEvents }) {
                        Text(if (showDayEvents) "Masquer" else "Afficher")
                    }
                }
                if (showDayEvents) {
                    if (dayEvents.isEmpty()) Text("Aucun événement ce jour.", Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(dayEvents, key = { it.id }) { event ->
                            EventCard(event, onDelete = {
                                if (event.outlookEventId != null) {
                                    outlookDeleteTarget = event
                                } else {
                                    ReminderScheduler.cancel(context, event)
                                    events = events.filterNot { it.id == event.id }
                                    store.save(events)
                                }
                            }, onAlarm = {
                                if (event.outlookEventId != null) outlookReminderTarget = event
                                else if (!exactAlarmsAllowed()) { showExactAlarmDialog = true; message = "Activez d'abord l'autorisation Alarmes et rappels." }
                                else if (ReminderScheduler.scheduleAlarm(context, event)) message = "Alarme Mon Agenda reprogrammée."
                                else message = "Impossible de programmer cette alarme."
                            })
                        }
                    }
                }
            }
        }
    }

    outlookDeleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { outlookDeleteTarget = null },
            title = { Text("Supprimer l’événement Outlook ?") },
            text = { Text("« ${target.title} » sera supprimé du calendrier synchronisé. Cette suppression peut être répercutée dans Outlook après synchronisation.") },
            confirmButton = {
                TextButton(onClick = {
                    if (OutlookCalendarReader.hasWritePermission(context)) {
                        if (OutlookCalendarReader.deleteEvent(context, target)) {
                            ReminderScheduler.cancel(context, target)
                            events = events.filterNot { it.id == target.id }
                            store.save(events)
                            outlookEvents = OutlookCalendarReader.readEvents(context)
                            message = "Événement Outlook supprimé."
                        } else message = "Impossible de supprimer cet événement."
                        outlookDeleteTarget = null
                    } else {
                        outlookWritePermission.launch(Manifest.permission.WRITE_CALENDAR)
                    }
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { outlookDeleteTarget = null }) { Text("Annuler") } }
        )
    }

    outlookReminderTarget?.let { target ->
        OutlookReminderEditor(
            event = target,
            onDismiss = { outlookReminderTarget = null },
            onSave = { mode, lead, alarmTime, soundUri, vibrate ->
                val updated = target.copy(reminderMode = mode, leadMinutes = lead, alarmTimeMillis = alarmTime, alarmSoundUri = soundUri, vibrate = vibrate)
                ReminderScheduler.cancel(context, target)
                events = (events.filterNot { it.id == target.id } + updated).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = if (mode == "alarm") ReminderScheduler.scheduleAlarm(context, updated)
                    else ReminderScheduler.schedule(context, updated)
                outlookReminderTarget = null
                if (scheduled) message = if (mode == "alarm") "Alarme sonore ajoutée à l’événement Outlook." else "Notification ajoutée à l’événement Outlook."
                else {
                    message = "Le rappel est enregistré, mais n’a pas pu être programmé. Vérifie l’autorisation Alarmes et rappels et que l’événement est dans le futur."
                    if (mode == "alarm" && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }

    if (showEditor) {
        EventEditor(
            onDismiss = { showEditor = false },
            onSave = { title, desc, time, mode, lead, soundUri, vibrate ->
                val event = AgendaEvent(System.currentTimeMillis(), title, desc, time, mode, lead, alarmSoundUri = soundUri, vibrate = vibrate)
                events = (events + event).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = when (mode) {
                    "notification" -> ReminderScheduler.schedule(context, event)
                    "alarm" -> ReminderScheduler.scheduleAlarm(context, event)
                    else -> false
                }
                showEditor = false
                selectedDay = time
                if (!scheduled) { message = "L'événement est enregistré, mais l'alarme n'a pas été programmée. Activez l'autorisation Alarmes et rappels."; if (mode == "alarm" && !exactAlarmsAllowed()) showExactAlarmDialog = true }
            }
        )
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Mon Agenda & Alarmes", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(38.dp))
                            Text("Votre agenda, vos rappels.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Organisez vos événements et ne manquez plus aucun rendez-vous.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Text("Développé par V Da Silva", fontWeight = FontWeight.SemiBold)
                    Text("Version $appVersion", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Fermer") } }
        )
    }

    if (showExactAlarmDialog) {
        AlertDialog(
            onDismissRequest = { showExactAlarmDialog = false },
            title = { Text("Autoriser les alarmes exactes") },
            text = { Text("Pour que les alarmes sonnent à l'heure prévue, Mon Agenda doit être autorisé à utiliser « Alarmes et rappels ». Active cette autorisation dans les paramètres Android.") },
            confirmButton = {
                TextButton(onClick = {
                    showExactAlarmDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:" + context.packageName)
                        }
                        context.startActivity(intent)
                    }
                }) { Text("ACTIVER LES ALARMES EXACTES") }
            },
            dismissButton = {
                TextButton(onClick = { showExactAlarmDialog = false }) { Text("Plus tard") }
            }
        )
    }

    message?.let {
        AlertDialog(onDismissRequest = { message = null }, confirmButton = {
            TextButton(onClick = { message = null }) { Text("OK") }
        }, title = { Text("Information") }, text = { Text(it) })
    }
}

private fun dayStart(time: Long): Calendar = Calendar.getInstance().apply {
    timeInMillis = time
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}
private fun sameDay(a: Long, b: Long): Boolean {
    val x = dayStart(a); val y = dayStart(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}
private fun shiftDate(time: Long, view: String, amount: Int): Long = Calendar.getInstance().apply {
    timeInMillis = time
    add(when(view) { "Jour" -> Calendar.DAY_OF_MONTH; "Semaine" -> Calendar.WEEK_OF_YEAR; else -> Calendar.MONTH }, amount)
}.timeInMillis

@Composable
private fun CalendarNavigator(view: String, selected: Long, onPrevious: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    val title = when(view) {
        "Jour" -> SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date(selected))
        "Semaine" -> {
            val c = dayStart(selected); c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            val first = c.timeInMillis; c.add(Calendar.DAY_OF_MONTH, 6)
            SimpleDateFormat("d MMM", Locale.FRANCE).format(Date(first)) + " – " + SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(c.time)
        }
        else -> SimpleDateFormat("MMMM yyyy", Locale.FRANCE).format(Date(selected))
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        IconButton(onClick = onPrevious) { Icon(Icons.Default.ChevronLeft, "Période précédente") }
        Text(title.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onToday) { Text("Aujourd'hui") }
            IconButton(onClick = onNext) { Icon(Icons.Default.ChevronRight, "Période suivante") }
        }
    }
}

@Composable
private fun DayAgenda(selected: Long, events: List<AgendaEvent>, expanded: Boolean) {
    val hours = (0..23).toList()
    Column(Modifier.fillMaxWidth().heightIn(max = if (expanded) 520.dp else 230.dp).padding(bottom = 6.dp)) {
        Text("Planning horaire", style = MaterialTheme.typography.labelLarge)
        LazyColumn { items(hours) { hour ->
            val atHour = events.filter { sameDay(it.timeMillis, selected) && Calendar.getInstance().apply { timeInMillis = it.timeMillis }.get(Calendar.HOUR_OF_DAY) == hour }
            Row(Modifier.fillMaxWidth().heightIn(min = 28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(String.format(Locale.FRANCE, "%02d:00", hour), modifier = Modifier.width(52.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                HorizontalDivider(Modifier.weight(1f))
                if (atHour.isNotEmpty()) Text("  ${atHour.joinToString { it.title }}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        } }
    }
}

@Composable
private fun WeekAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, expanded: Boolean) {
    val start = dayStart(selected).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }
    Column(Modifier.fillMaxWidth().heightIn(max = if (expanded) 520.dp else 230.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(7) { index ->
            val day = Calendar.getInstance().apply { timeInMillis = start.timeInMillis; add(Calendar.DAY_OF_MONTH, index) }
            val dayEvents = events.filter { sameDay(it.timeMillis, day.timeInMillis) }
            OutlinedButton(onClick = { onSelectDay(day.timeInMillis) }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)) {
                Text(SimpleDateFormat("EEE d", Locale.FRANCE).format(day.time).replaceFirstChar { it.uppercase() }, modifier = Modifier.width(75.dp))
                Text(if (dayEvents.isEmpty()) "—" else dayEvents.joinToString(" · ") { SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(it.timeMillis)) + " " + it.title }, maxLines = 1)
            }
        }
    }
}

// Jours fériés légaux en France métropolitaine, calculés pour chaque année.
private fun isFrenchPublicHoliday(date: Calendar): Boolean {
    val year = date.get(Calendar.YEAR)
    val month = date.get(Calendar.MONTH) + 1
    val day = date.get(Calendar.DAY_OF_MONTH)
    val fixed = setOf("1-1", "5-1", "5-8", "7-14", "8-15", "11-1", "11-11", "12-25")
    if ("$month-$day" in fixed) return true
    val easter = easterSunday(year)
    val easterMonday = easter.plusDays(1)
    val ascension = easter.plusDays(39)
    val whitMonday = easter.plusDays(50)
    val current = java.time.LocalDate.of(year, month, day)
    return current == easterMonday || current == ascension || current == whitMonday
}

private fun easterSunday(year: Int): java.time.LocalDate {
    val a = year % 19
    val b = year / 100
    val c = year % 100
    val d = b / 4
    val e = b % 4
    val f = (b + 8) / 25
    val g = (b - f + 1) / 3
    val h = (19 * a + b - d - g + 15) % 30
    val i = c / 4
    val k = c % 4
    val l = (32 + 2 * e + 2 * i - h - k) % 7
    val m = (a + 11 * h + 22 * l) / 451
    val month = (h + l - 7 * m + 114) / 31
    val day = (h + l - 7 * m + 114) % 31 + 1
    return java.time.LocalDate.of(year, month, day)
}

@Composable
private fun MonthAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, expanded: Boolean) {
    val month = Calendar.getInstance().apply { timeInMillis = selected; set(Calendar.DAY_OF_MONTH, 1) }
    val offset = (month.get(Calendar.DAY_OF_WEEK) - month.firstDayOfWeek + 7) % 7
    val days = (0 until offset).map { 0 } + (1..month.getActualMaximum(Calendar.DAY_OF_MONTH)).toList()
    Column(Modifier.fillMaxWidth().heightIn(max = if (expanded) 520.dp else 230.dp)) {
        Row(Modifier.fillMaxWidth()) { listOf("L", "M", "M", "J", "V", "S", "D").forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Bold) } }
        days.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { number ->
                    Box(Modifier.weight(1f).height(if (expanded) 52.dp else 34.dp), contentAlignment = Alignment.Center) {
                        if (number > 0) {
                            val date = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; set(Calendar.DAY_OF_MONTH, number) }
                            val count = events.count { sameDay(it.timeMillis, date.timeInMillis) }
                            Surface(onClick = { onSelectDay(date.timeInMillis) }, shape = MaterialTheme.shapes.small,
                                color = if (sameDay(date.timeInMillis, selected)) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
                                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(
                                        number.toString(),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = when {
                                            isFrenchPublicHoliday(date) || date.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY -> androidx.compose.ui.graphics.Color(0xFFD32F2F)
                                            date.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY -> androidx.compose.ui.graphics.Color(0xFF1976D2)
                                            else -> MaterialTheme.colorScheme.onSurface
                                        },
                                        fontWeight = if (isFrenchPublicHoliday(date)) FontWeight.Bold else FontWeight.Normal
                                    )
                                    if (count > 0) Text("•".repeat(count.coerceAtMost(3)), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
                repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Text("• Notification    • Alarme Horloge", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun EventCard(event: AgendaEvent, onDelete: () -> Unit, onAlarm: () -> Unit) {
    val date = remember(event.timeMillis) {
        SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(event.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(date, style = MaterialTheme.typography.bodyMedium)
            if (event.description.isNotBlank()) Text(event.description)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (event.reminderMode == "alarm") Icon(Icons.Default.Alarm, contentDescription = null)
                else if (event.outlookEventId != null) Icon(Icons.Default.CalendarMonth, contentDescription = null)
                else Icon(Icons.Default.Notifications, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(
                    (when (event.reminderMode) {
                        "alarm" -> "Alarme Mon Agenda"
                        "outlook" -> "Événement Outlook sans rappel"
                        else -> if (event.outlookEventId != null) "Rappel Outlook" else "Notification"
                    }) + if (event.reminderMode == "outlook") "" else " · ${event.leadMinutes} min avant"
                )
            }
            if (event.outlookEventId != null) {
                TextButton(onClick = onAlarm) {
                    Text(if (event.reminderMode == "outlook") "Ajouter un rappel" else "Modifier le rappel")
                }
            } else if (event.reminderMode == "alarm") {
                TextButton(onClick = onAlarm) { Text("Reprogrammer l’alarme") }
            }
            TextButton(onClick = onDelete) { Text(if (event.outlookEventId != null) "Supprimer d’Outlook" else "Supprimer") }
        }
    }
}

@Composable
fun OutlookReminderEditor(
    event: AgendaEvent,
    onDismiss: () -> Unit,
    onSave: (String, Int, Long, String?, Boolean) -> Unit
) {
    var mode by remember(event.id) { mutableStateOf(if (event.reminderMode == "outlook") "alarm" else event.reminderMode) }
    var alarmTimeMillis by remember(event.id) {
        mutableLongStateOf(event.alarmTimeMillis ?: run {
            val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
            val eventMinute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val alarmMinute = (eventMinute - 15).coerceAtLeast(0)
            c.set(Calendar.HOUR_OF_DAY, alarmMinute / 60)
            c.set(Calendar.MINUTE, alarmMinute % 60)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.timeInMillis
        })
    }
    var error by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var soundUri by remember(event.id) { mutableStateOf(event.alarmSoundUri) }
    var vibrate by remember(event.id) { mutableStateOf(event.vibrate) }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }
    val alarmTimeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(alarmTimeMillis))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rappel de l’événement Outlook") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(event.title, fontWeight = FontWeight.SemiBold)
                Text(SimpleDateFormat("EEEE d MMMM 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis)))
                Text("Le jour du rendez-vous reste inchangé. Seule l’heure de l’alarme sera modifiée.", style = MaterialTheme.typography.bodySmall)
                Text("Type de rappel", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "alarm", { mode = "alarm" })
                    Text("Alarme sonore")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "notification", { mode = "notification" })
                    Text("Notification")
                }
                Text("Heure de l’alarme", fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                    TimePickerDialog(
                        context,
                        { _, hour, minute ->
                            val selected = Calendar.getInstance().apply {
                                timeInMillis = event.timeMillis
                                set(Calendar.HOUR_OF_DAY, hour)
                                set(Calendar.MINUTE, minute)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                            alarmTimeMillis = selected.timeInMillis
                            error = false
                        },
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true
                    ).show()
                }) { Text("Choisir : $alarmTimeText") }
                Text("Sonnerie", fontWeight = FontWeight.SemiBold)
                Text(soundLabel, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                        }
                        ringtonePicker.launch(picker)
                    }) { Text("Choisir une sonnerie") }
                    TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Vibreur", modifier = Modifier.weight(1f))
                    Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                }
                if (error) Text("Choisis une heure future, le même jour que le rendez-vous.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val eventDay = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val alarmDay = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                val sameDay = eventDay.get(Calendar.YEAR) == alarmDay.get(Calendar.YEAR) &&
                    eventDay.get(Calendar.DAY_OF_YEAR) == alarmDay.get(Calendar.DAY_OF_YEAR)
                if (!sameDay || alarmTimeMillis <= System.currentTimeMillis()) error = true
                else onSave(mode, 0, alarmTimeMillis, soundUri, vibrate)
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun EventEditor(
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String, Int, String?, Boolean) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("notification") }
    var lead by remember { mutableStateOf("15") }
    var customLead by remember { mutableStateOf("45") }
    var selectedTime by remember { mutableLongStateOf(System.currentTimeMillis() + 3_600_000L) }
    var error by remember { mutableStateOf(false) }
    var soundUri by remember { mutableStateOf<String?>(null) }
    var vibrate by remember { mutableStateOf(true) }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedTime }
    val dateText = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(selectedTime))
    val timeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(selectedTime))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Programmer un événement", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Détails du rendez-vous", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        OutlinedTextField(title, { title = it }, label = { Text("Titre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(description, { description = it }, label = { Text("Description (facultatif)") }, modifier = Modifier.fillMaxWidth())
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Date et heure", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(y, m, d)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text(dateText) }
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(Calendar.HOUR_OF_DAY, h)
                                set(Calendar.MINUTE, m)
                                set(Calendar.SECOND, 0)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    }) { Text(timeText) }
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Type de rappel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "notification", { mode = "notification" })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "alarm", { mode = "alarm" })
                    Text("Alarme sonore Mon Agenda")
                }
                Text("Délai avant l'événement", fontWeight = FontWeight.SemiBold)
                val choices = listOf("0" to "À l'heure", "5" to "5 min", "15" to "15 min", "30" to "30 min", "60" to "1 h", "1440" to "La veille", "custom" to "Personnalisé")
                choices.chunked(3).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { (value, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(lead == value, { lead = value })
                                Text(label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (lead == "custom") {
                    OutlinedTextField(
                        customLead, { customLead = it.filter(Char::isDigit).take(5) },
                        label = { Text("Minutes avant") },
                        singleLine = true
                    )
                }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Personnaliser l’alarme", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(soundLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                }
                                ringtonePicker.launch(picker)
                            }) { Text("Choisir la sonnerie") }
                            TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vibreur", modifier = Modifier.weight(1f))
                            Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                        }
                    }
                }
                if (error) Text("Saisissez un titre, une date future et un délai valide.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val minutes = if (lead == "custom") customLead.toIntOrNull() else lead.toIntOrNull()
                if (title.isBlank() || selectedTime <= System.currentTimeMillis() || minutes == null || minutes < 0) {
                    error = true
                } else {
                    onSave(title.trim(), description.trim(), selectedTime, mode, minutes, soundUri, vibrate)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

