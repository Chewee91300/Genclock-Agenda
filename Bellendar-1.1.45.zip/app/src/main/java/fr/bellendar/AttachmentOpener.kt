package fr.bellendar

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Opens an attachment through a temporary FileProvider URI.
 * This avoids relying on third-party viewers understanding the Storage Access
 * Framework URI used by Bellendar's backup folder.
 */
object AttachmentOpener {
    fun open(context: Context, sourceUri: String, mimeType: String, displayName: String) {
        val resolver = context.contentResolver
        val source = Uri.parse(sourceUri)
        try {
            val directory = File(context.cacheDir, "shared_attachments").apply { mkdirs() }
            val safeName = displayName.substringAfterLast('/').substringAfterLast('\\')
                .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "document" }
            val extension = safeName.substringAfterLast('.', "").takeIf { it.isNotBlank() }
            val file = File.createTempFile("bellendar_", extension?.let { ".$it" } ?: ".tmp", directory)
            resolver.openInputStream(source)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Fichier introuvable ou inaccessible")

            val sharedUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val type = mimeType.takeIf { it.isNotBlank() && it != "application/octet-stream" }
                ?: resolver.getType(source) ?: "*/*"
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(sharedUri, type)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newUri(resolver, displayName, sharedUri)
            }
            context.startActivity(Intent.createChooser(viewIntent, "Ouvrir avec"))
        } catch (error: Exception) {
            Toast.makeText(
                context,
                "Impossible d'ouvrir cette pièce jointe : ${error.localizedMessage ?: "lecteur indisponible"}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
