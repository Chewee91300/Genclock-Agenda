package fr.monagenda.alarmes

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

class EventStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("agenda_events", Context.MODE_PRIVATE)
    private val backupPrefs = context.getSharedPreferences("agenda_backup", Context.MODE_PRIVATE)
    private val backupFileName = "evenements_backup.json"
    private val attachmentsDirectoryName = "Pieces jointes"

    fun backupTreeUri(): Uri? = backupPrefs.getString("tree_uri", null)?.let { Uri.parse(it) }

    fun setBackupTreeUri(uri: Uri) {
        backupPrefs.edit().putString("tree_uri", uri.toString()).apply()
    }

    /**
     * Attache le dossier choisi par l'utilisateur.
     * Après réinstallation, la sauvegarde externe est prioritaire sur la liste locale
     * (qui est normalement vide). Une liste locale vide ne doit jamais écraser
     * une sauvegarde externe qui contient des événements.
     */
    fun attachBackupTree(uri: Uri, localEvents: List<AgendaEvent>): List<AgendaEvent> {
        setBackupTreeUri(uri)
        val externalEvents = readExternalBackup()
        return when {
            externalEvents.isNotEmpty() -> {
                prefs.edit().putString("events", serialize(externalEvents)).apply()
                externalEvents
            }
            localEvents.isNotEmpty() -> {
                writeExternalBackup(serialize(localEvents))
                localEvents
            }
            else -> emptyList()
        }
    }

    fun load(): List<AgendaEvent> {
        val local = parse(prefs.getString("events", "[]") ?: "[]")
        if (local.isNotEmpty()) return local

        // Après réinstallation, les préférences privées sont vides : restaurer depuis le dossier choisi.
        val external = readExternalBackup()
        if (external.isNotEmpty()) {
            prefs.edit().putString("events", serialize(external)).apply()
            return external
        }
        return local
    }

    fun save(events: List<AgendaEvent>) {
        val json = serialize(events)
        prefs.edit().putString("events", json).apply()
        writeExternalBackup(json)
    }

    private fun readExternalBackup(): List<AgendaEvent> = runCatching {
        val tree = backupTreeUri() ?: return emptyList()
        val directory = backupDirectory(tree) ?: return emptyList()
        val file = directory.findFile(backupFileName) ?: return emptyList()
        val input = context.contentResolver.openInputStream(file.uri) ?: return emptyList()
        val content = input.bufferedReader(Charsets.UTF_8).use { it.readText() }
        parse(content)
    }.getOrDefault(emptyList())

    private fun writeExternalBackup(json: String) {
        runCatching {
            val tree = backupTreeUri() ?: return
            val directory = backupDirectory(tree) ?: return
            var file = directory.findFile(backupFileName)
            if (file == null) file = directory.createFile("application/json", backupFileName)
            file ?: return
            context.contentResolver.openOutputStream(file.uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(json)
            }
        }
    }


    private fun backupDirectory(tree: Uri): DocumentFile? {
        val root = DocumentFile.fromTreeUri(context, tree) ?: return null
        // Si l'utilisateur a sélectionné directement le dossier dédié, on l'utilise.
        if (root.name == "MonAgendaAlarmes") return root
        // Sinon, Documents est la racine autorisée : créer/utiliser son sous-dossier dédié.
        return root.findFile("MonAgendaAlarmes")?.takeIf { it.isDirectory }
            ?: root.createDirectory("MonAgendaAlarmes")
    }

    /**
     * Copie une pièce jointe dans Documents/MonAgendaAlarmes/Pieces jointes.
     * Le fichier est donc indépendant de son emplacement d'origine.
     */
    fun copyAttachment(sourceUri: Uri, eventId: Long): EventAttachment? = runCatching {
        val tree = backupTreeUri() ?: return null
        val directory = backupDirectory(tree) ?: return null
        val attachmentDirectory = directory.findFile(attachmentsDirectoryName)?.takeIf { it.isDirectory }
            ?: directory.createDirectory(attachmentsDirectoryName)
            ?: return null
        val sourceName = DocumentFile.fromSingleUri(context, sourceUri)?.name ?: "document"
        val safeName = sourceName.replace(Regex("[\\\\/:*?\\\"<>|]"), "_").take(100).ifBlank { "document" }
        val mime = context.contentResolver.getType(sourceUri) ?: "application/octet-stream"
        val uniqueName = "${eventId}_${System.currentTimeMillis()}_$safeName"
        val destination = attachmentDirectory.createFile(mime, uniqueName) ?: return null
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            context.contentResolver.openOutputStream(destination.uri, "w")?.use { output ->
                input.copyTo(output)
            } ?: return null
        } ?: return null
        EventAttachment(
            id = uniqueName,
            name = sourceName,
            uri = destination.uri.toString(),
            mimeType = mime
        )
    }.getOrNull()

    private fun serialize(events: List<AgendaEvent>): String {
        val array = JSONArray()
        events.forEach { e ->
            array.put(JSONObject().apply {
                put("id", e.id)
                put("title", e.title)
                put("description", e.description)
                put("timeMillis", e.timeMillis)
                put("reminderMode", e.reminderMode)
                put("leadMinutes", e.leadMinutes)
                if (e.outlookEventId != null) put("outlookEventId", e.outlookEventId)
                if (e.alarmTimeMillis != null) put("alarmTimeMillis", e.alarmTimeMillis)
                if (e.alarmSoundUri != null) put("alarmSoundUri", e.alarmSoundUri)
                put("vibrate", e.vibrate)
                put("attachments", JSONArray().apply {
                    e.attachments.forEach { attachment ->
                        put(JSONObject().apply {
                            put("id", attachment.id)
                            put("name", attachment.name)
                            put("uri", attachment.uri)
                            put("mimeType", attachment.mimeType)
                        })
                    }
                })
            })
        }
        return array.toString()
    }

    private fun parse(json: String): List<AgendaEvent> = runCatching {
        val array = JSONArray(json)
        (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                AgendaEvent(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    description = o.optString("description"),
                    timeMillis = o.getLong("timeMillis"),
                    reminderMode = o.getString("reminderMode"),
                    leadMinutes = o.getInt("leadMinutes"),
                    outlookEventId = if (o.has("outlookEventId") && !o.isNull("outlookEventId")) o.getLong("outlookEventId") else null,
                    alarmTimeMillis = if (o.has("alarmTimeMillis") && !o.isNull("alarmTimeMillis")) o.getLong("alarmTimeMillis") else null,
                    alarmSoundUri = o.optString("alarmSoundUri").takeIf { it.isNotBlank() },
                    vibrate = o.optBoolean("vibrate", true),
                    attachments = (0 until o.optJSONArray("attachments")?.length().orZero()).mapNotNull { index ->
                        runCatching {
                            val a = o.getJSONArray("attachments").getJSONObject(index)
                            EventAttachment(
                                id = a.getString("id"),
                                name = a.getString("name"),
                                uri = a.getString("uri"),
                                mimeType = a.optString("mimeType", "application/octet-stream")
                            )
                        }.getOrNull()
                    }
                )
            }.getOrNull()
        }.sortedBy { it.timeMillis }
    }.getOrDefault(emptyList())
}

private fun Int?.orZero(): Int = this ?: 0
