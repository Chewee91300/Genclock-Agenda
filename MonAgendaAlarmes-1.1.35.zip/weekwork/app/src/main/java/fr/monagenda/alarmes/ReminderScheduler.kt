package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    private fun pending(context: Context, event: AgendaEvent, receiver: Class<*>): PendingIntent {
        val intent = Intent(context, receiver).apply {
            putExtra("eventId", event.id)
            putExtra("title", event.title)
            putExtra("description", event.description)
            putExtra("alarmSoundUri", event.alarmSoundUri)
            putExtra("vibrate", event.vibrate)
        }
        return PendingIntent.getBroadcast(
            context, event.id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, event: AgendaEvent): Boolean = scheduleAt(
        context, event, event.alarmTimeMillis ?: (event.timeMillis - event.leadMinutes * 60_000L), ReminderReceiver::class.java, false
    )

    fun scheduleAlarm(context: Context, event: AgendaEvent, timeMillis: Long = event.timeMillis): Boolean =
        scheduleAt(context, event, event.alarmTimeMillis ?: (timeMillis - event.leadMinutes * 60_000L), AlarmReceiver::class.java, true)

    private fun scheduleAt(context: Context, event: AgendaEvent, triggerAt: Long, receiver: Class<*>, exactRequired: Boolean): Boolean {
        if (triggerAt <= System.currentTimeMillis()) return false
        return try {
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pending(context, event, receiver)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                if (exactRequired) return false
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                try { manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi) }
                catch (_: SecurityException) {
                    if (exactRequired) return false
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            }
            true
        } catch (_: Exception) { false }
    }

    fun cancel(context: Context, event: AgendaEvent) {
        try {
            val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            manager.cancel(pending(context, event, ReminderReceiver::class.java))
            manager.cancel(pending(context, event, AlarmReceiver::class.java))
        } catch (_: Exception) { }
    }
}
