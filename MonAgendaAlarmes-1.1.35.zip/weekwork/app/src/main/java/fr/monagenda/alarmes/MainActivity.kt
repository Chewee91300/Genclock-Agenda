package fr.monagenda.alarmes

import android.app.AlarmManager
import android.app.NotificationManager
import android.provider.Settings
import android.net.Uri
import android.media.RingtoneManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.view.View
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ViewWeek
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Close
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaScreen() {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val fabPositionPrefs = remember { context.getSharedPreferences("interface", android.content.Context.MODE_PRIVATE) }
    var fabOffsetX by remember { mutableFloatStateOf(fabPositionPrefs.getFloat("fab_offset_x", 0f)) }
    var fabOffsetY by remember { mutableFloatStateOf(fabPositionPrefs.getFloat("fab_offset_y", 0f)) }
    val store = remember { EventStore(context) }
    var events by remember { mutableStateOf(store.load()) }
    var message by remember { mutableStateOf<String?>(null) }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                // Restaurer d'abord la sauvegarde existante. Ne jamais l'écraser
                // avec la liste vide chargée avant que l'utilisateur ait choisi le dossier.
                events = store.attachBackupTree(uri, events)
                message = if (events.isNotEmpty()) {
                    "Sauvegarde retrouvée : ${events.size} événement(s) restauré(s)."
                } else {
                    "Sauvegarde automatique activée dans Documents/MonAgendaAlarmes."
                }
            }.onFailure {
                message = "Impossible d'activer la sauvegarde locale. Vérifie que le dossier Documents est accessible."
            }
        }
    }
    LaunchedEffect(Unit) {
        if (store.backupTreeUri() == null) {
            val documentsUri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADocuments")
            backupFolderPicker.launch(documentsUri)
        }
    }
    var showEditor by remember { mutableStateOf(false) }
    var eventBeingEdited by remember { mutableStateOf<AgendaEvent?>(null) }
    var showExactAlarmDialog by remember { mutableStateOf(false) }
    var showDndAlert by remember { mutableStateOf(false) }
    var showDndAccessDialog by remember { mutableStateOf(false) }
    var dndWasActive by remember { mutableStateOf(false) }
    var showDayEvents by remember { mutableStateOf(true) }
    var eventsMaximized by remember { mutableStateOf(false) }
    var paperFullScreen by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showThemes by remember { mutableStateOf(false) }
    val themePrefs = remember { context.getSharedPreferences("interface", android.content.Context.MODE_PRIVATE) }
    var selectedTheme by remember { mutableStateOf(themePrefs.getString("selected_theme", "elegance") ?: "elegance") }
    var minimumAlarmVolume by remember { mutableFloatStateOf(themePrefs.getInt("minimum_alarm_volume_percent", 20).toFloat()) }
    var outlookDeleteTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var outlookReminderTarget by remember { mutableStateOf<AgendaEvent?>(null) }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val appVersion = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "inconnue" }.getOrDefault("inconnue")
    }
    var view by remember { mutableStateOf("Mois") }
    var selectedDay by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var outlookEvents by remember { mutableStateOf(emptyList<AgendaEvent>()) }
    val allEvents = remember(events, outlookEvents) { (events + outlookEvents).distinctBy { it.id }.sortedBy { it.timeMillis } }

    val calendarPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            outlookEvents = OutlookCalendarReader.readEvents(context)
        } else {
            message = "Autorisation de lecture du calendrier refusée. Active-la dans les paramètres Android pour afficher les événements Outlook."
        }
    }

    val outlookWritePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val target = outlookDeleteTarget
        if (granted && target != null) {
            if (OutlookCalendarReader.deleteEvent(context, target)) {
                ReminderScheduler.cancel(context, target)
                events = events.filterNot { it.id == target.id }
                store.save(events)
                outlookEvents = outlookEvents.filterNot { it.id == target.id }
                message = "Événement supprimé du calendrier synchronisé."
            } else message = "La suppression a échoué. Vérifie les droits du calendrier synchronisé."
        } else if (!granted) message = "Autorisation de modification du calendrier refusée."
        outlookDeleteTarget = null
    }

    var notificationsAllowed by remember {
        mutableStateOf(
            android.os.Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
        )
    }

    // La réponse Android est prise en compte immédiatement, sans redémarrer l'application.
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsAllowed = granted
        if (granted) {
            store.load()
                .filter { it.reminderMode == "notification" || it.reminderMode == "both" }
                .forEach { ReminderScheduler.schedule(context, it) }
            message = "Notifications autorisées. Les rappels enregistrés sont maintenant activés."
        } else {
            message = "Notifications non autorisées. Tu peux les activer dans les paramètres Android."
        }
    }
    fun exactAlarmsAllowed(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) return true
        val manager = context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager
        return manager.canScheduleExactAlarms()
    }
    fun hasDndAccess(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M) return false
        val manager = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
        return manager.isNotificationPolicyAccessGranted
    }

    fun isDndActive(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M || !hasDndAccess()) return false
        val manager = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
        return manager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
            manager.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    fun checkDoNotDisturb() {
        if (!hasDndAccess()) return
        val active = isDndActive()
        if (active && !dndWasActive) showDndAlert = true
        dndWasActive = active
    }

    LaunchedEffect(Unit) {
        while (true) {
            clockNow = System.currentTimeMillis()
            checkDoNotDisturb()
            delay(2000)
        }
    }

    LaunchedEffect(Unit) {
        if (!exactAlarmsAllowed()) showExactAlarmDialog = true
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
            !hasDndAccess() && !themePrefs.getBoolean("dnd_access_prompted", false)) {
            themePrefs.edit().putBoolean("dnd_access_prompted", true).apply()
            showDndAccessDialog = true
        }
        // Outlook n'est plus importé automatiquement : l'utilisateur lance la synchronisation
        // depuis le bouton Actualiser du bandeau.
        if (android.os.Build.VERSION.SDK_INT >= 33 && !notificationsAllowed) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Actualisation automatique à chaque retour de l'application au premier plan.
    val lifecycle = (context as? ComponentActivity)?.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (!exactAlarmsAllowed()) showExactAlarmDialog = true
                checkDoNotDisturb()

                // Android peut modifier l'autorisation pendant que l'application est en arrière-plan.
                // On relit son état au retour, puis on restaure les rappels sans fermeture/réouverture.
                notificationsAllowed = android.os.Build.VERSION.SDK_INT < 33 ||
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED

                store.load().forEach { saved ->
                    when (saved.reminderMode) {
                        "alarm" -> if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        "notification" -> if (notificationsAllowed) ReminderScheduler.schedule(context, saved)
                        "both" -> {
                            if (notificationsAllowed) ReminderScheduler.schedule(context, saved)
                            if (exactAlarmsAllowed()) ReminderScheduler.scheduleAlarm(context, saved)
                        }
                    }
                }
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    val hostActivity = context as? ComponentActivity
    DisposableEffect(paperFullScreen) {
        val window = hostActivity?.window
        val previousOrientation = hostActivity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (paperFullScreen) {
            hostActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            hostActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        onDispose {
            @Suppress("DEPRECATION")
            window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            hostActivity?.requestedOrientation = previousOrientation
        }
    }

    val theme = appThemePalette(selectedTheme)
    MaterialTheme(colorScheme = if (theme.dark) darkColorScheme(
        primary = theme.primary, onPrimary = theme.onPrimary,
        primaryContainer = theme.primaryContainer, onPrimaryContainer = theme.onPrimaryContainer,
        secondary = theme.secondary, background = theme.background, surface = theme.surface,
        onSurface = theme.onSurface, surfaceVariant = theme.surfaceVariant,
        onSurfaceVariant = theme.onSurfaceVariant
    ) else lightColorScheme(
        primary = theme.primary, onPrimary = theme.onPrimary,
        primaryContainer = theme.primaryContainer, onPrimaryContainer = theme.onPrimaryContainer,
        secondary = theme.secondary, background = theme.background, surface = theme.surface,
        onSurface = theme.onSurface, surfaceVariant = theme.surfaceVariant,
        onSurfaceVariant = theme.onSurfaceVariant
    )) {
        Scaffold(
            containerColor = if (paperFullScreen) Color(0xFFE9DDBD) else theme.background,
            topBar = {
                if (!paperFullScreen) {
                Box(Modifier.fillMaxWidth().height(78.dp).statusBarsPadding()) {
                    Image(painter = painterResource(id = R.drawable.banner_agenda), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(78.dp), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxWidth().height(78.dp).background(theme.primary.copy(alpha = 0.48f)))
                    Row(Modifier.fillMaxWidth().align(Alignment.Center).padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(7.dp))
                        Text("Mon Agenda & Alarme", color = Color.White, fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp, lineHeight = 18.sp, maxLines = 1, softWrap = false,
                            modifier = Modifier.weight(1f))
                        IconButton(onClick = { showThemes = true }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Default.Palette, contentDescription = "Choisir un thème", tint = Color.White, modifier = Modifier.size(21.dp))
                        }
                        TextButton(onClick = { showAbout = true },
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)) {
                            Icon(Icons.Default.Info, null, tint = Color.White, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("À propos", color = Color.White, fontSize = 10.sp, maxLines = 1)
                        }
                        IconButton(onClick = {
                            if (OutlookCalendarReader.hasPermission(context)) {
                                outlookEvents = OutlookCalendarReader.readEvents(context)
                                message = "Calendrier synchronisé actualisé."
                            } else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                        }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Actualiser Outlook", tint = Color.White, modifier = Modifier.size(23.dp))
                        }
                    }
                }
                }
            },
            floatingActionButton = {
                if (!paperFullScreen) {
                FloatingActionButton(
                    onClick = { showEditor = true },
                    modifier = Modifier
                        .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
                        .pointerInput(configuration.screenWidthDp, configuration.screenHeightDp) {
                            detectDragGesturesAfterLongPress(
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    val maxLeft = with(density) { (configuration.screenWidthDp - 80).coerceAtLeast(0).dp.toPx() }
                                    val maxUp = with(density) { (configuration.screenHeightDp - 180).coerceAtLeast(0).dp.toPx() }
                                    fabOffsetX = (fabOffsetX + dragAmount.x).coerceIn(-maxLeft, 0f)
                                    fabOffsetY = (fabOffsetY + dragAmount.y).coerceIn(-maxUp, 0f)
                                    fabPositionPrefs.edit()
                                        .putFloat("fab_offset_x", fabOffsetX)
                                        .putFloat("fab_offset_y", fabOffsetY)
                                        .apply()
                                }
                            )
                        },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un événement — maintenir appuyé pour déplacer")
                }
                }
            }
        ) { padding ->
            if (paperFullScreen) {
                Column(Modifier.fillMaxSize().background(Color(0xFFE9DDBD)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth().height(38.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("AGENDA DE LA SEMAINE", color = Color(0xFF59452B), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { paperFullScreen = false }) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF59452B))
                            Text("Sortir", color = Color(0xFF59452B), fontWeight = FontWeight.Bold)
                        }
                    }
                    WeeklyPaperAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, fullScreen = true, modifier = Modifier.weight(1f))
                }
            } else Column(Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Jour", "Semaine", "Papier", "Mois").forEach { label ->
                            FilterChip(selected = view == label, onClick = { view = label }, label = { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.height(36.dp))
                        }
                        if (view == "Papier") TextButton(onClick = { paperFullScreen = true }) { Text("Plein écran", fontSize = 11.sp) }
                    }
                    Text(SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date(clockNow)), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                if (!eventsMaximized) {
                    CalendarNavigator(view, selectedDay, onPrevious = { selectedDay = shiftDate(selectedDay, view, -1) },
                        onNext = { selectedDay = shiftDate(selectedDay, view, 1) }, onToday = { selectedDay = System.currentTimeMillis() })
                    when (view) {
                        "Jour" -> DayAgenda(selectedDay, allEvents, expanded = !showDayEvents)
                        "Semaine" -> WeekAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                        "Papier" -> WeeklyPaperAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it })
                        else -> MonthAgenda(selectedDay, allEvents, onSelectDay = { selectedDay = it }, expanded = !showDayEvents)
                    }
                }
                val dayEvents = allEvents.filter { sameDay(it.timeMillis, selectedDay) }.sortedBy { it.timeMillis }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 7.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp)).padding(horizontal = 11.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Événements du ${SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(selectedDay))}",
                        fontSize = 15.sp, lineHeight = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
                        modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                    if (!eventsMaximized) {
                        TextButton(onClick = { showDayEvents = !showDayEvents }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) {
                            Text(if (showDayEvents) "Masquer" else "Afficher", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (showDayEvents) {
                        TextButton(onClick = { eventsMaximized = !eventsMaximized }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) {
                            Text(if (eventsMaximized) "Réduire" else "Agrandir", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (showDayEvents) {
                    if (dayEvents.isEmpty()) Text("Aucun événement ce jour.", Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(dayEvents, key = { it.id }) { event ->
                            EventCard(event, onEdit = {
                                if (event.outlookEventId != null) {
                                    val editIntent = Intent(Intent.ACTION_EDIT).apply {
                                        data = android.content.ContentUris.withAppendedId(
                                            android.provider.CalendarContract.Events.CONTENT_URI, event.outlookEventId
                                        )
                                        type = "vnd.android.cursor.item/event"
                                    }
                                    runCatching { context.startActivity(editIntent) }
                                        .onFailure { message = "Aucune application de calendrier ne permet de modifier cet événement." }
                                }
                            }, onDelete = {
                                if (event.outlookEventId != null) {
                                    outlookDeleteTarget = event
                                } else {
                                    ReminderScheduler.cancel(context, event)
                                    events = events.filterNot { it.id == event.id }
                                    store.save(events)
                                }
                            }, onAlarm = {
                                if (event.outlookEventId != null) outlookReminderTarget = event
                                else {
                                    eventBeingEdited = event
                                    showEditor = true
                                }
                            })
                        }
                    }
                }
            }
        }
    }

    outlookDeleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { outlookDeleteTarget = null },
            title = { Text("Supprimer du calendrier source ?") },
            text = { Text("« ${target.title} » sera supprimé du calendrier synchronisé et la suppression pourra être répercutée dans Outlook ou Google après synchronisation. Attention : si ce rendez-vous appartient à une série récurrente, la série entière peut être supprimée.") },
            confirmButton = {
                TextButton(onClick = {
                    if (OutlookCalendarReader.hasWritePermission(context)) {
                        if (OutlookCalendarReader.deleteEvent(context, target)) {
                            ReminderScheduler.cancel(context, target)
                            events = events.filterNot { it.id == target.id }
                            store.save(events)
                            outlookEvents = outlookEvents.filterNot { it.id == target.id }
                            message = "Événement supprimé du calendrier synchronisé."
                        } else message = "Impossible de supprimer cet événement."
                        outlookDeleteTarget = null
                    } else {
                        outlookWritePermission.launch(Manifest.permission.WRITE_CALENDAR)
                    }
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { outlookDeleteTarget = null }) { Text("Annuler") } }
        )
    }

    outlookReminderTarget?.let { target ->
        OutlookReminderEditor(
            event = target,
            onDismiss = { outlookReminderTarget = null },
            onSave = { mode, lead, alarmTime, soundUri, vibrate ->
                val updated = target.copy(reminderMode = mode, leadMinutes = lead, alarmTimeMillis = alarmTime, alarmSoundUri = soundUri, vibrate = vibrate)
                ReminderScheduler.cancel(context, target)
                events = (events.filterNot { it.id == target.id } + updated).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = when (mode) {
                    "alarm" -> ReminderScheduler.scheduleAlarm(context, updated)
                    "both" -> {
                        val notificationOk = ReminderScheduler.schedule(context, updated)
                        val alarmOk = ReminderScheduler.scheduleAlarm(context, updated)
                        notificationOk && alarmOk
                    }
                    else -> ReminderScheduler.schedule(context, updated)
                }
                outlookReminderTarget = null
                if (scheduled) message = when (mode) {
                    "alarm" -> "Alarme sonore ajoutée à l’événement Outlook."
                    "both" -> "Notification et alarme ajoutées à l’événement Outlook."
                    else -> "Notification ajoutée à l’événement Outlook."
                }
                else {
                    message = "Le rappel est enregistré, mais n’a pas pu être programmé. Vérifie l’autorisation Alarmes et rappels et que l’événement est dans le futur."
                    if ((mode == "alarm" || mode == "both") && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }

    if (showEditor) {
        val editing = eventBeingEdited
        EventEditor(
            initialDateMillis = editing?.timeMillis ?: selectedDay,
            initialEvent = editing,
            eventStore = store,
            onDismiss = { showEditor = false; eventBeingEdited = null },
            onSave = { title, desc, time, mode, lead, soundUri, vibrate, attachments ->
                val event = if (editing != null) editing.copy(
                    title = title, description = desc, timeMillis = time,
                    reminderMode = mode, leadMinutes = lead, alarmTimeMillis = null,
                    alarmSoundUri = soundUri, vibrate = vibrate, attachments = attachments
                ) else AgendaEvent(System.currentTimeMillis(), title, desc, time, mode, lead, alarmSoundUri = soundUri, vibrate = vibrate, attachments = attachments)
                if (editing != null) ReminderScheduler.cancel(context, editing)
                events = (events.filterNot { it.id == event.id } + event).sortedBy { it.timeMillis }
                store.save(events)
                val scheduled = when (mode) {
                    "notification" -> ReminderScheduler.schedule(context, event)
                    "alarm" -> ReminderScheduler.scheduleAlarm(context, event)
                    "both" -> {
                        val notificationOk = ReminderScheduler.schedule(context, event)
                        val alarmOk = ReminderScheduler.scheduleAlarm(context, event)
                        notificationOk && alarmOk
                    }
                    else -> false
                }
                showEditor = false
                eventBeingEdited = null
                selectedDay = time
                if (scheduled) message = if (editing != null) "Événement modifié et rappel reprogrammé." else "Événement enregistré."
                else {
                    message = "L'événement est enregistré, mais le rappel n'a pas pu être programmé. Vérifie l'autorisation Alarmes et rappels."
                    if ((mode == "alarm" || mode == "both") && !exactAlarmsAllowed()) showExactAlarmDialog = true
                }
            }
        )
    }
    if (showThemes) {
        AlertDialog(
            onDismissRequest = { showThemes = false },
            title = { Text("Apparence et thèmes", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    appThemeOptions().forEach { option ->
                        val colors = appThemePalette(option.first)
                        Surface(
                            onClick = {
                                selectedTheme = option.first
                                themePrefs.edit().putString("selected_theme", option.first).apply()
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = colors.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                if (selectedTheme == option.first) 2.dp else 1.dp,
                                if (selectedTheme == option.first) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(colors.primary, colors.secondary, colors.primaryContainer).forEach { swatch ->
                                        Box(Modifier.size(width = 22.dp, height = 38.dp).background(swatch, RoundedCornerShape(7.dp)))
                                    }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(option.second, color = colors.onSurface, fontWeight = FontWeight.Bold)
                                    Text(option.third, color = colors.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                                if (selectedTheme == option.first) Icon(Icons.Default.Palette, contentDescription = "Thème sélectionné", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    Divider()
                    Text("Volume minimum des alarmes", fontWeight = FontWeight.Bold)
                    Text("Si le volume des alarmes du téléphone est inférieur à ce seuil, l'application l'augmentera temporairement pendant la sonnerie, puis restaurera le volume initial.", style = MaterialTheme.typography.bodySmall)
                    Text("Minimum : ${minimumAlarmVolume.roundToInt()} %", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Slider(
                        value = minimumAlarmVolume,
                        onValueChange = { value ->
                            minimumAlarmVolume = value
                            themePrefs.edit().putInt("minimum_alarm_volume_percent", value.roundToInt()).apply()
                        },
                        valueRange = 5f..50f,
                        steps = 8
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showThemes = false }) { Text("Fermer") } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Mon Agenda & Alarmes", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(38.dp))
                            Text("Votre agenda, vos rappels.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Organisez vos événements et ne manquez plus aucun rendez-vous.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Text("Développé par V Da Silva", fontWeight = FontWeight.SemiBold)
                    Text("Version $appVersion", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Fermer") } }
        )
    }

    if (showDndAccessDialog) {
        AlertDialog(
            onDismissRequest = { showDndAccessDialog = false },
            title = { Text("Détection du mode Ne pas déranger") },
            text = { Text("Pour avertir lorsque le mode Ne pas déranger est activé, Mon Agenda & Alarmes doit pouvoir consulter le mode de concentration du téléphone. Autorise cet accès dans les paramètres Android. L'application ne modifiera pas ce réglage.") },
            confirmButton = {
                TextButton(onClick = {
                    showDndAccessDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }
                }) { Text("OUVRIR LES PARAMÈTRES") }
            },
            dismissButton = { TextButton(onClick = { showDndAccessDialog = false }) { Text("Plus tard") } }
        )
    }

    if (showDndAlert) {
        AlertDialog(
            onDismissRequest = { showDndAlert = false },
            title = { Text("Mode Ne pas déranger activé", fontWeight = FontWeight.Bold) },
            text = { Text("Attention : le mode Ne pas déranger est actif. Il peut silencier ou limiter les alarmes et notifications de Mon Agenda & Alarmes selon les réglages du téléphone.") },
            confirmButton = {
                TextButton(onClick = {
                    showDndAlert = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)) }
                    }
                }) { Text("VÉRIFIER LES PARAMÈTRES") }
            },
            dismissButton = { TextButton(onClick = { showDndAlert = false }) { Text("Fermer") } }
        )
    }

    if (showExactAlarmDialog) {
        AlertDialog(
            onDismissRequest = { showExactAlarmDialog = false },
            title = { Text("Autoriser les alarmes exactes") },
            text = { Text("Pour que les alarmes sonnent à l'heure prévue, Mon Agenda doit être autorisé à utiliser « Alarmes et rappels ». Active cette autorisation dans les paramètres Android.") },
            confirmButton = {
                TextButton(onClick = {
                    showExactAlarmDialog = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:" + context.packageName)
                        }
                        context.startActivity(intent)
                    }
                }) { Text("ACTIVER LES ALARMES EXACTES") }
            },
            dismissButton = {
                TextButton(onClick = { showExactAlarmDialog = false }) { Text("Plus tard") }
            }
        )
    }

    message?.let {
        AlertDialog(onDismissRequest = { message = null }, confirmButton = {
            TextButton(onClick = { message = null }) { Text("OK") }
        }, title = { Text("Information") }, text = { Text(it) })
    }
}

private data class AppThemePalette(
    val primary: Color, val onPrimary: Color, val primaryContainer: Color, val onPrimaryContainer: Color,
    val secondary: Color, val background: Color, val surface: Color, val onSurface: Color,
    val surfaceVariant: Color, val onSurfaceVariant: Color, val dark: Boolean = false
)

private fun appThemeOptions() = listOf(
    Triple("elegance", "Élégance – Bleu & Blanc", "Clair, épuré et professionnel"),
    Triple("midnight", "Midnight – Noir & Violet", "Sombre, confortable le soir"),
    Triple("pastel", "Pastel – Douceur & Couleurs", "Tons doux et chaleureux"),
    Triple("glass", "Glass – Moderne & Translucide", "Bleu et violet contemporains"),
    Triple("nature", "Nature – Vert & Sable", "Vert sauge et tons naturels")
)

private fun appThemePalette(id: String): AppThemePalette = when (id) {
    "midnight" -> AppThemePalette(Color(0xFFB99AFF), Color(0xFF24143D), Color(0xFF49336A), Color(0xFFE9DDFF), Color(0xFFCFB7FF), Color(0xFF12121A), Color(0xFF1D1C28), Color(0xFFF0EDF7), Color(0xFF302D3C), Color(0xFFC5BED2), true)
    "pastel" -> AppThemePalette(Color(0xFF8876C7), Color.White, Color(0xFFE9E1FA), Color(0xFF40345F), Color(0xFF70A99A), Color(0xFFFFFAF5), Color(0xFFFFFEFC), Color(0xFF40394A), Color(0xFFF4EAF1), Color(0xFF756B7B))
    "glass" -> AppThemePalette(Color(0xFF356BD6), Color.White, Color(0xFFDCE9FF), Color(0xFF19396F), Color(0xFF7856D8), Color(0xFFF1F5FF), Color(0xFFFFFFFF), Color(0xFF1D2B45), Color(0xFFE4EBF8), Color(0xFF5D6B83))
    "nature" -> AppThemePalette(Color(0xFF477B5A), Color.White, Color(0xFFDDEBDD), Color(0xFF23452E), Color(0xFF91A987), Color(0xFFF7F6EF), Color(0xFFFFFEF8), Color(0xFF29372B), Color(0xFFEAEBDD), Color(0xFF687360))
    else -> AppThemePalette(Color(0xFF245A9B), Color.White, Color(0xFFDCEBFA), Color(0xFF173A63), Color(0xFF4E83B9), Color(0xFFF5F8FC), Color.White, Color(0xFF202B39), Color(0xFFE8EFF7), Color(0xFF637184))
}

private fun dayStart(time: Long): Calendar = Calendar.getInstance().apply {
    timeInMillis = time
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}
private fun sameDay(a: Long, b: Long): Boolean {
    val x = dayStart(a); val y = dayStart(b)
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}
private fun shiftDate(time: Long, view: String, amount: Int): Long = Calendar.getInstance().apply {
    timeInMillis = time
    add(when(view) { "Jour" -> Calendar.DAY_OF_MONTH; "Semaine", "Papier" -> Calendar.WEEK_OF_YEAR; else -> Calendar.MONTH }, amount)
}.timeInMillis

@Composable
private fun CalendarNavigator(view: String, selected: Long, onPrevious: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    val title = when(view) {
        "Jour" -> SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date(selected))
        "Semaine", "Papier" -> {
            val c = dayStart(selected); c.firstDayOfWeek = Calendar.MONDAY; c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            val first = c.timeInMillis; c.add(Calendar.DAY_OF_MONTH, 6)
            SimpleDateFormat("d MMM", Locale.FRANCE).format(Date(first)) + " – " + SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(c.time)
        }
        else -> SimpleDateFormat("MMMM yyyy", Locale.FRANCE).format(Date(selected))
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(onClick = onPrevious, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(38.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronLeft, "Période précédente", tint = MaterialTheme.colorScheme.onSurface) }
        }
        Spacer(Modifier.width(8.dp))
        Text(title.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface,
            fontSize = 20.sp, maxLines = 1, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Spacer(Modifier.width(6.dp))
        TextButton(onClick = onToday, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 3.dp)) {
            Text("Aujourd'hui", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Surface(onClick = onNext, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(38.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ChevronRight, "Période suivante", tint = MaterialTheme.colorScheme.onSurface) }
        }
    }
}

@Composable
private fun DayAgenda(selected: Long, events: List<AgendaEvent>, expanded: Boolean) {
    // Une graduation tous les quarts d'heure : deux événements espacés de 15 minutes
    // occupent ainsi deux lignes distinctes au lieu d'être fusionnés sur une ligne horaire.
    val dayEvents = events.filter { sameDay(it.timeMillis, selected) }
    val eventsByQuarter = dayEvents.groupBy { event ->
        Calendar.getInstance().apply { timeInMillis = event.timeMillis }.let {
            it.get(Calendar.HOUR_OF_DAY) * 4 + it.get(Calendar.MINUTE) / 15
        }
    }
    Column(Modifier.fillMaxWidth().heightIn(max = if (expanded) 520.dp else 230.dp).padding(bottom = 6.dp)) {
        Text("Planning horaire · précision 15 min", style = MaterialTheme.typography.labelLarge)
        LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false)) {
            items(96) { quarter ->
                val hour = quarter / 4
                val minute = (quarter % 4) * 15
                val atQuarter = eventsByQuarter[quarter].orEmpty().sortedBy { it.timeMillis }
                Row(
                    Modifier.fillMaxWidth().heightIn(min = if (atQuarter.isEmpty()) 27.dp else 40.dp).padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        String.format(Locale.FRANCE, "%02d:%02d", hour, minute),
                        modifier = Modifier.width(52.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelSmall
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        if (atQuarter.isEmpty()) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        } else {
                            atQuarter.forEach { event ->
                                val exactTime = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(7.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        "$exactTime  ${event.title}",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        style = MaterialTheme.typography.labelMedium,
                                        maxLines = 2
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeekAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, expanded: Boolean) {
    val start = dayStart(selected).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }
    Column(Modifier.fillMaxWidth().heightIn(max = if (expanded) 520.dp else 230.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(7) { index ->
            val day = Calendar.getInstance().apply { timeInMillis = start.timeInMillis; add(Calendar.DAY_OF_MONTH, index) }
            val dayEvents = events.filter { sameDay(it.timeMillis, day.timeInMillis) }
            OutlinedButton(onClick = { onSelectDay(day.timeInMillis) }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)) {
                Text(SimpleDateFormat("EEE d", Locale.FRANCE).format(day.time).replaceFirstChar { it.uppercase() }, modifier = Modifier.width(75.dp))
                Text(if (dayEvents.isEmpty()) "—" else dayEvents.joinToString(" · ") { SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(it.timeMillis)) + " " + it.title }, maxLines = 1)
            }
        }
    }
}

@Composable
private fun WeeklyPaperAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, fullScreen: Boolean = false, modifier: Modifier = Modifier) {
    val weekStart = Calendar.getInstance().apply {
        timeInMillis = dayStart(selected).timeInMillis
        firstDayOfWeek = Calendar.MONDAY
        minimalDaysInFirstWeek = 4
        set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    }
    val days = (0..6).map { offset -> Calendar.getInstance().apply { timeInMillis = weekStart.timeInMillis; add(Calendar.DAY_OF_MONTH, offset) } }
    BoxWithConstraints(modifier.fillMaxWidth().then(if (fullScreen) Modifier.fillMaxHeight() else Modifier.heightIn(max = 560.dp))) {
        val columnWidth = if (fullScreen) (maxWidth - 48.dp) / 7 else if (maxWidth >= 700.dp) (maxWidth - 48.dp) / 7 else 116.dp
        val hourHeight = if (fullScreen) (maxHeight - 58.dp) / 18 else 62.dp
        val paper = Color(0xFFFFF8E7)
        val ink = Color(0xFF55452F)
        Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()).verticalScroll(rememberScrollState()).background(Color(0xFFE9DDBD))) {
            Column(Modifier.width(48.dp)) {
                Box(Modifier.height(if (fullScreen) 48.dp else 54.dp).fillMaxWidth().background(Color(0xFFF3E8CC)), contentAlignment = Alignment.Center) {
                    Text("Heure", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ink)
                }
                Column {
                    (6..23).forEach { hour ->
                        Box(Modifier.height(hourHeight).fillMaxWidth().background(Color(0xFFF3E8CC)).border(0.5.dp, Color(0xFFB9A987)), contentAlignment = Alignment.TopCenter) {
                            Text(String.format(Locale.FRANCE, "%02dh", hour), fontSize = if (fullScreen) 11.sp else 10.sp, color = ink, modifier = Modifier.padding(top = 3.dp))
                        }
                    }
                }
            }
            days.forEach { day ->
                val dayEvents = events.filter { sameDay(it.timeMillis, day.timeInMillis) }.sortedBy { it.timeMillis }
                Column(Modifier.width(columnWidth).background(paper).border(0.7.dp, Color(0xFFB9A987))) {
                    Surface(onClick = { onSelectDay(day.timeInMillis) }, color = if (sameDay(day.timeInMillis, selected)) Color(0xFFE9D7A9) else Color(0xFFF3E8CC)) {
                        Column(Modifier.fillMaxWidth().height(if (fullScreen) 48.dp else 54.dp).padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text(SimpleDateFormat("EEEE", Locale.FRANCE).format(day.time).replaceFirstChar { it.uppercase() }, fontSize = if (fullScreen) 12.sp else 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, color = ink)
                            Text(SimpleDateFormat("d MMM", Locale.FRANCE).format(day.time), fontSize = 10.sp, color = ink)
                        }
                    }
                    Column {
                        (6..23).forEach { hour ->
                            val hourEvents = dayEvents.filter { Calendar.getInstance().apply { timeInMillis = it.timeMillis }.get(Calendar.HOUR_OF_DAY) == hour }
                            Column(Modifier.height(hourHeight).fillMaxWidth().background(paper).border(0.5.dp, Color(0xFFD2C5A7)).padding(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                hourEvents.forEach { event ->
                                    val eventColor = when (event.reminderMode) {
                                        "alarm" -> Color(0xFFD52E35)
                                        "both" -> Color(0xFF8E44AD)
                                        "notification" -> Color(0xFF2878D0)
                                        else -> MaterialTheme.colorScheme.secondary
                                    }
                                    Surface(color = eventColor.copy(alpha = 0.12f), shape = RoundedCornerShape(2.dp), modifier = Modifier.fillMaxWidth().border(0.7.dp, eventColor.copy(alpha = 0.65f), RoundedCornerShape(2.dp))) {
                                        Column(Modifier.padding(horizontal = 3.dp, vertical = 2.dp)) {
                                            Text(SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(event.timeMillis)), fontSize = if (fullScreen) 10.sp else 9.sp, fontWeight = FontWeight.Bold, color = eventColor, maxLines = 1)
                                            Text(event.title, fontSize = if (fullScreen) 10.sp else 9.sp, lineHeight = if (fullScreen) 11.sp else 10.sp, color = ink, maxLines = if (fullScreen) 4 else 3)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (!fullScreen) Text("Vue agenda papier · ouvrez le plein écran pour afficher les 7 jours simultanément.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
}

// Jours fériés légaux en France métropolitaine, calculés pour chaque année.
private fun isFrenchPublicHoliday(date: Calendar): Boolean {
    val year = date.get(Calendar.YEAR)
    val month = date.get(Calendar.MONTH) + 1
    val day = date.get(Calendar.DAY_OF_MONTH)
    val fixed = setOf("1-1", "5-1", "5-8", "7-14", "8-15", "11-1", "11-11", "12-25")
    if ("$month-$day" in fixed) return true
    val easter = easterSunday(year)
    val easterMonday = easter.plusDays(1)
    val ascension = easter.plusDays(39)
    val whitMonday = easter.plusDays(50)
    val current = java.time.LocalDate.of(year, month, day)
    return current == easterMonday || current == ascension || current == whitMonday
}

private fun easterSunday(year: Int): java.time.LocalDate {
    val a = year % 19
    val b = year / 100
    val c = year % 100
    val d = b / 4
    val e = b % 4
    val f = (b + 8) / 25
    val g = (b - f + 1) / 3
    val h = (19 * a + b - d - g + 15) % 30
    val i = c / 4
    val k = c % 4
    val l = (32 + 2 * e + 2 * i - h - k) % 7
    val m = (a + 11 * h + 22 * l) / 451
    val month = (h + l - 7 * m + 114) / 31
    val day = (h + l - 7 * m + 114) % 31 + 1
    return java.time.LocalDate.of(year, month, day)
}

@Composable
private fun MonthAgenda(selected: Long, events: List<AgendaEvent>, onSelectDay: (Long) -> Unit, expanded: Boolean) {
    val month = Calendar.getInstance().apply { timeInMillis = selected; set(Calendar.DAY_OF_MONTH, 1); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
    val offset = (month.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY + 7) % 7
    val days = (0 until offset).map { 0 } + (1..month.getActualMaximum(Calendar.DAY_OF_MONTH)).toList()
    val weeks = days.chunked(7)
    Card(Modifier.fillMaxWidth().padding(top = 1.dp, bottom = 3.dp), shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(5.dp)) {
        Column(Modifier.padding(horizontal = 5.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp)).padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Sem.", Modifier.width(48.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                listOf("L", "M", "M", "J", "V", "S", "D").forEachIndexed { i, label ->
                    Text(label, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold,
                        color = when(i) { 5 -> Color(0xFF1769D2); 6 -> Color(0xFFD52E2E); else -> MaterialTheme.colorScheme.onSurface })
                }
            }
            weeks.forEachIndexed { wi, week ->
                Row(Modifier.fillMaxWidth().height(if (expanded) 43.dp else 38.dp), verticalAlignment = Alignment.CenterVertically) {
                    val weekStart = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; add(Calendar.DAY_OF_MONTH, wi * 7 - offset); firstDayOfWeek = Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
                    Box(Modifier.width(48.dp).fillMaxHeight().padding(vertical = 3.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text(weekStart.get(Calendar.WEEK_OF_YEAR).toString(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                    week.forEach { n ->
                        Box(Modifier.weight(1f).fillMaxHeight().padding(2.dp), contentAlignment = Alignment.Center) {
                            if (n > 0) {
                                val date = Calendar.getInstance().apply { timeInMillis = month.timeInMillis; set(Calendar.DAY_OF_MONTH, n) }
                                val hasNotification = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "notification" }
                                val hasAlarm = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "alarm" }
                                val hasBoth = events.any { sameDay(it.timeMillis, date.timeInMillis) && it.reminderMode == "both" }
                                val selectedDate = sameDay(date.timeInMillis, selected)
                                val dayColor = when { isFrenchPublicHoliday(date) || date.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY -> Color(0xFFD52E35); date.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY -> Color(0xFF1769D2); else -> MaterialTheme.colorScheme.onSurface }
                                Surface(
                                    onClick = { onSelectDay(date.timeInMillis) },
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .then(if (selectedDate) Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp)) else Modifier),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Transparent
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = dayColor, fontWeight = if (selectedDate || isFrenchPublicHoliday(date)) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp, lineHeight = 16.sp)
                                        // Réserve toujours la même hauteur sous le numéro :
                                        // l'apparition des points ne déplace jamais le chiffre.
                                        Box(Modifier.height(10.dp), contentAlignment = Alignment.Center) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                                if (hasNotification) Text("•", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                                if (hasAlarm) Text("•", color = Color(0xFFD52E35), style = MaterialTheme.typography.labelSmall)
                                                if (hasBoth) Text("•", color = Color(0xFF8E44AD), style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                }
                if (wi < weeks.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.7.dp)
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(start = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("●", color = MaterialTheme.colorScheme.primary); Text(" Notification", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.width(18.dp)); Text("●", color = Color(0xFFD52E35)); Text(" Alarme", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.width(18.dp)); Text("●", color = Color(0xFF8E44AD)); Text(" Les deux", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun EventCard(event: AgendaEvent, onEdit: () -> Unit, onDelete: () -> Unit, onAlarm: () -> Unit) {
    val context = LocalContext.current
    val date = remember(event.timeMillis) {
        SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis))
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Box(Modifier.width(5.dp).height(142.dp).background(MaterialTheme.colorScheme.secondary))
            Row(Modifier.padding(horizontal = 11.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    val delayLabel = when {
                        event.reminderMode == "outlook" -> ""
                        event.leadMinutes <= 0 -> ""
                        event.leadMinutes < 60 -> " · dans ${event.leadMinutes} min"
                        event.leadMinutes % 1440 == 0 -> " · dans ${event.leadMinutes / 1440} j"
                        event.leadMinutes % 60 == 0 -> " · dans ${event.leadMinutes / 60} h"
                        else -> " · dans ${event.leadMinutes / 60} h ${event.leadMinutes % 60} min"
                    }
                    Text(event.title + delayLabel, fontSize = 17.sp, lineHeight = 20.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.width(6.dp))
                        Text(date.replaceFirstChar { it.uppercase() }, fontSize = 13.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (event.reminderMode == "alarm") Icons.Default.Alarm else Icons.Default.Notifications, null,
                            modifier = Modifier.size(19.dp), tint = when (event.reminderMode) { "alarm" -> Color(0xFFD52E35); "both" -> Color(0xFF8E44AD); else -> MaterialTheme.colorScheme.primary })
                        Spacer(Modifier.width(6.dp))
                        Text((when (event.reminderMode) {
                            "alarm" -> "Alarme Mon Agenda"
                            "both" -> "Notification + alarme"
                            "outlook" -> "Événement Outlook sans rappel"
                            else -> if (event.outlookEventId != null) "Rappel Outlook" else "Notification"
                        }) + if (event.reminderMode == "outlook") "" else " · ${event.leadMinutes} min avant",
                            fontSize = 13.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    if (event.attachments.isNotEmpty()) {
                        event.attachments.forEach { attachment ->
                            TextButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(Uri.parse(attachment.uri), attachment.mimeType)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    runCatching { context.startActivity(intent) }
                                },
                                contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)
                            ) {
                                Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(attachment.name, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (event.outlookEventId != null) {
                            OutlinedButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)) {
                                Text("Modifier", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                            }
                        } else {
                            OutlinedButton(onClick = onAlarm, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)) {
                                Text("Modifier", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                            }
                        }
                        OutlinedButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                            shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)) {
                            Text("Supprimer", fontSize = 12.sp, color = MaterialTheme.colorScheme.error, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OutlookReminderEditor(
    event: AgendaEvent,
    onDismiss: () -> Unit,
    onSave: (String, Int, Long, String?, Boolean) -> Unit
) {
    var notificationEnabled by remember(event.id) { mutableStateOf(event.reminderMode == "notification" || event.reminderMode == "both") }
    var alarmEnabled by remember(event.id) { mutableStateOf(event.reminderMode == "alarm" || event.reminderMode == "both" || event.reminderMode == "outlook") }
    var alarmTimeMillis by remember(event.id) {
        mutableLongStateOf(event.alarmTimeMillis ?: run {
            val c = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
            val eventMinute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val alarmMinute = (eventMinute - 15).coerceAtLeast(0)
            c.set(Calendar.HOUR_OF_DAY, alarmMinute / 60)
            c.set(Calendar.MINUTE, alarmMinute % 60)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.timeInMillis
        })
    }
    var error by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var soundUri by remember(event.id) { mutableStateOf(event.alarmSoundUri) }
    var vibrate by remember(event.id) { mutableStateOf(event.vibrate) }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }
    val alarmTimeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(alarmTimeMillis))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rappel de l’événement Outlook") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(event.title, fontWeight = FontWeight.SemiBold)
                Text(SimpleDateFormat("EEEE d MMMM 'à' HH:mm", Locale.FRANCE).format(Date(event.timeMillis)))
                Text("Le jour du rendez-vous reste inchangé. Seule l’heure de l’alarme sera modifiée.", style = MaterialTheme.typography.bodySmall)
                Text("Type de rappel", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it })
                    Text("Alarme sonore")
                }
                if (!notificationEnabled && !alarmEnabled) Text("Sélectionne au moins un type de rappel.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("Heure de l’alarme", fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                    TimePickerDialog(
                        context,
                        { _, hour, minute ->
                            val selected = Calendar.getInstance().apply {
                                timeInMillis = event.timeMillis
                                set(Calendar.HOUR_OF_DAY, hour)
                                set(Calendar.MINUTE, minute)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                            alarmTimeMillis = selected.timeInMillis
                            error = false
                        },
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true
                    ).show()
                }) { Text("Choisir : $alarmTimeText") }
                Text("Sonnerie", fontWeight = FontWeight.SemiBold)
                Text(soundLabel, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                        }
                        ringtonePicker.launch(picker)
                    }) { Text("Choisir une sonnerie") }
                    TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Vibreur", modifier = Modifier.weight(1f))
                    Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                }
                if (error) Text("Choisis une heure future, le même jour que le rendez-vous.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val eventDay = Calendar.getInstance().apply { timeInMillis = event.timeMillis }
                val alarmDay = Calendar.getInstance().apply { timeInMillis = alarmTimeMillis }
                val sameDay = eventDay.get(Calendar.YEAR) == alarmDay.get(Calendar.YEAR) &&
                    eventDay.get(Calendar.DAY_OF_YEAR) == alarmDay.get(Calendar.DAY_OF_YEAR)
                if (!notificationEnabled && !alarmEnabled) error = true
                else if (alarmEnabled && (!sameDay || alarmTimeMillis <= System.currentTimeMillis())) error = true
                else onSave(when { notificationEnabled && alarmEnabled -> "both"; alarmEnabled -> "alarm"; else -> "notification" }, 0, alarmTimeMillis, soundUri, vibrate)
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun EventEditor(
    initialDateMillis: Long,
    initialEvent: AgendaEvent? = null,
    onDismiss: () -> Unit,
    eventStore: EventStore,
    onSave: (String, String, Long, String, Int, String?, Boolean, List<EventAttachment>) -> Unit
) {
    val context = LocalContext.current
    var title by remember(initialEvent?.id) { mutableStateOf(initialEvent?.title ?: "") }
    var description by remember(initialEvent?.id) { mutableStateOf(initialEvent?.description ?: "") }
    var notificationEnabled by remember(initialEvent?.id) { mutableStateOf(initialEvent?.reminderMode != "alarm") }
    var alarmEnabled by remember(initialEvent?.id) { mutableStateOf(initialEvent?.reminderMode == "alarm" || initialEvent?.reminderMode == "both") }
    var lead by remember(initialEvent?.id) { mutableStateOf((initialEvent?.leadMinutes ?: 15).toString()) }
    var customLead by remember(initialEvent?.id) { mutableStateOf("45") }
    var selectedTime by remember(initialEvent?.id, initialDateMillis) {
        mutableLongStateOf(
            initialEvent?.timeMillis ?: Calendar.getInstance().run {
                val now = System.currentTimeMillis()
                val chosenDay = Calendar.getInstance().apply { timeInMillis = initialDateMillis }
                val today = Calendar.getInstance()
                if (chosenDay.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    chosenDay.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                    timeInMillis = now + 3_600_000L
                } else {
                    timeInMillis = initialDateMillis
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                timeInMillis
            }
        )
    }
    var error by remember { mutableStateOf(false) }
    var soundUri by remember(initialEvent?.id) { mutableStateOf(initialEvent?.alarmSoundUri) }
    var vibrate by remember(initialEvent?.id) { mutableStateOf(initialEvent?.vibrate ?: true) }
    var attachments by remember(initialEvent?.id) { mutableStateOf(initialEvent?.attachments ?: emptyList()) }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val copied = eventStore.copyAttachment(uri, initialEvent?.id ?: System.currentTimeMillis())
            if (copied != null) attachments = attachments + copied
        }
    }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            soundUri = picked?.toString()
        }
    }
    val soundLabel = remember(soundUri) {
        if (soundUri == null) "Sonnerie d’alarme par défaut" else runCatching {
            RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context) ?: "Sonnerie personnalisée"
        }.getOrDefault("Sonnerie personnalisée")
    }

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedTime }
    val dateText = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(selectedTime))
    val timeText = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(selectedTime))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialEvent == null) "Programmer un événement" else "Modifier l’événement", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Détails du rendez-vous", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        OutlinedTextField(title, { title = it }, label = { Text("Titre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(description, { description = it }, label = { Text("Description (facultatif)") }, modifier = Modifier.fillMaxWidth())
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Date et heure", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(y, m, d)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text(dateText) }
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            val c = Calendar.getInstance().apply {
                                timeInMillis = selectedTime
                                set(Calendar.HOUR_OF_DAY, h)
                                set(Calendar.MINUTE, m)
                                set(Calendar.SECOND, 0)
                            }
                            selectedTime = c.timeInMillis
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    }) { Text(timeText) }
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Type de rappel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it })
                    Text("Notification")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it })
                    Text("Alarme sonore Mon Agenda")
                }
                if (!notificationEnabled && !alarmEnabled) Text("Sélectionne au moins un type de rappel.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("Délai avant l'événement", fontWeight = FontWeight.SemiBold)
                val choices = listOf("0" to "À l'heure", "5" to "5 min", "15" to "15 min", "30" to "30 min", "60" to "1 h", "1440" to "La veille", "custom" to "Personnalisé")
                choices.chunked(3).forEach { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { (value, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                RadioButton(lead == value, { lead = value })
                                Text(label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (lead == "custom") {
                    OutlinedTextField(
                        customLead, { customLead = it.filter(Char::isDigit).take(5) },
                        label = { Text("Minutes avant") },
                        singleLine = true
                    )
                }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Personnaliser l’alarme", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(soundLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie de l’alarme")
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                                }
                                ringtonePicker.launch(picker)
                            }) { Text("Choisir la sonnerie") }
                            TextButton(onClick = { soundUri = null }) { Text("Par défaut") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vibreur", modifier = Modifier.weight(1f))
                            Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                        }
                    }
                }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pièces jointes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text("Les fichiers sont copiés dans Documents/MonAgendaAlarmes/Pieces jointes pour être conservés avec la sauvegarde.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = {
                            attachmentPicker.launch(arrayOf("application/pdf", "image/*", "text/*", "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                        }) {
                            Icon(Icons.Default.AttachFile, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Ajouter une pièce jointe")
                        }
                        if (attachments.isEmpty()) {
                            Text("Aucune pièce jointe.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            attachments.forEach { attachment ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text(attachment.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                    IconButton(onClick = { attachments = attachments.filterNot { it.id == attachment.id } }) {
                                        Icon(Icons.Default.Close, contentDescription = "Retirer la pièce jointe")
                                    }
                                }
                            }
                        }
                    }
                }
                if (error) Text("Saisissez un titre, une date future et un délai valide.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val minutes = if (lead == "custom") customLead.toIntOrNull() else lead.toIntOrNull()
                if (title.isBlank() || selectedTime <= System.currentTimeMillis() || minutes == null || minutes < 0 || (!notificationEnabled && !alarmEnabled)) {
                    error = true
                } else {
                    val mode = when { notificationEnabled && alarmEnabled -> "both"; alarmEnabled -> "alarm"; else -> "notification" }
                    onSave(title.trim(), description.trim(), selectedTime, mode, minutes, soundUri, vibrate, attachments)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

