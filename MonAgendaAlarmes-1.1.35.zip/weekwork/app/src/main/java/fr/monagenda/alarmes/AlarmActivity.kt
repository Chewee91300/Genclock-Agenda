package fr.monagenda.alarmes

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        val title = intent.getStringExtra("title") ?: "Alarme"
        val description = intent.getStringExtra("description").orEmpty()
        val id = intent.getLongExtra("eventId", 0L)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER
            setPadding(32, 48, 32, 48); setBackgroundColor(0xFF17243A.toInt())
        }
        root.addView(TextView(this).apply { text = "⏰ ALARME"; textSize = 26f; setTextColor(-1); gravity = 17 })
        root.addView(TextView(this).apply { text = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date()); textSize = 64f; setTextColor(-1); gravity = 17; setPadding(0, 24, 0, 24) })
        root.addView(TextView(this).apply { text = title; textSize = 28f; setTextColor(-1); gravity = 17 })
        if (description.isNotBlank()) root.addView(TextView(this).apply { text = description; textSize = 18f; setTextColor(-1); gravity = 17; setPadding(0, 12, 0, 24) })
        root.addView(Button(this).apply { text = "Répéter 5 minutes"; textSize = 18f; setOnClickListener {
            startService(Intent(this@AlarmActivity, AlarmPlaybackService::class.java).apply {
                action = AlarmPlaybackService.ACTION_SNOOZE
                putExtra("title", title); putExtra("description", description); putExtra("eventId", id)
            })
            finish()
        } })
        root.addView(Button(this).apply { text = "ARRÊTER"; textSize = 20f; setOnClickListener {
            startService(Intent(this@AlarmActivity, AlarmPlaybackService::class.java).setAction(AlarmPlaybackService.ACTION_STOP))
            finish()
        } })
        setContentView(root)
    }
}
