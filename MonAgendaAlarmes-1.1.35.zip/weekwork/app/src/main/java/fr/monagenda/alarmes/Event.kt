package fr.monagenda.alarmes

data class EventAttachment(
    val id: String,
    val name: String,
    val uri: String,
    val mimeType: String
)

data class AgendaEvent(
    val id: Long,
    val title: String,
    val description: String,
    val timeMillis: Long,
    val reminderMode: String, // "notification" ou "alarm"
    val leadMinutes: Int,
    val outlookEventId: Long? = null,
    val alarmTimeMillis: Long? = null,
    val alarmSoundUri: String? = null,
    val vibrate: Boolean = true,
    val attachments: List<EventAttachment> = emptyList()
)
