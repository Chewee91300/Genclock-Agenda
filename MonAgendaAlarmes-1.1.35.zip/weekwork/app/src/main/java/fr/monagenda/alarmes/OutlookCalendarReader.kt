package fr.monagenda.alarmes

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.Calendar

object OutlookCalendarReader {
    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    fun readEvents(context: Context): List<AgendaEvent> {
        if (!hasPermission(context)) return emptyList()

        val now = Calendar.getInstance()
        val begin = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            add(Calendar.YEAR, -1)
            set(Calendar.MONTH, Calendar.JANUARY)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }.timeInMillis
        val end = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            add(Calendar.YEAR, 2)
            set(Calendar.MONTH, Calendar.DECEMBER)
            set(Calendar.DAY_OF_MONTH, 31)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
        }.timeInMillis

        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(builder, begin)
        android.content.ContentUris.appendId(builder, end)

        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.CALENDAR_ID
        )
        val result = mutableListOf<AgendaEvent>()
        context.contentResolver.query(
            builder.build(),
            projection,
            null,
            null,
            "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
            val titleCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
            val beginCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
            val descCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.DESCRIPTION)
            val calendarCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_ID)
            while (cursor.moveToNext()) {
                val title = cursor.getString(titleCol).orEmpty().ifBlank { "(Sans titre)" }
                val start = cursor.getLong(beginCol)
                val eventId = cursor.getLong(idCol)
                val calendarId = cursor.getLong(calendarCol)
                val description = cursor.getString(descCol).orEmpty()
                // Distinct negative IDs keep imported entries separate from locally-created events.
                val stableId = -((eventId * 100_003L) + ((start / 60_000L) % 100_003L) + 1L)
                result += AgendaEvent(
                    id = stableId,
                    title = title,
                    description = if (description.isBlank()) "Calendrier Android synchronisé (Outlook ou autre compte)" else description,
                    timeMillis = start,
                    reminderMode = "outlook",
                    leadMinutes = 0,
                    outlookEventId = eventId
                )
            }
        }
        return result.distinctBy { it.id }
    }

    fun deleteEvent(context: Context, event: AgendaEvent): Boolean {
        if (!hasWritePermission(context) || event.outlookEventId == null) return false
        return runCatching {
            val uri = android.content.ContentUris.withAppendedId(
                CalendarContract.Events.CONTENT_URI, event.outlookEventId
            )
            context.contentResolver.delete(uri, null, null) > 0
        }.getOrDefault(false)
    }

    fun hasWritePermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

}
