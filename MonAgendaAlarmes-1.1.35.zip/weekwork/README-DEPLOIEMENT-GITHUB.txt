MON AGENDA & ALARMES — structure du projet

IMPORTANT : le contenu de cette archive doit être placé directement à la racine
du dépôt GitHub (pas dans un sous-dossier MonAgendaAlarmes).

La racine du dépôt doit contenir :
- settings.gradle.kts
- build.gradle.kts
- gradle.properties
- app/build.gradle.kts
- app/src/...
- .github/workflows/android-apk.yml

Le fichier app/build.gradle.kts est inclus dans cette archive.

Après avoir remplacé les fichiers du dépôt par ceux de cette archive,
vérifier dans GitHub que le chemin app/build.gradle.kts existe bien.

Le workflow fourni compile une APK Debug pour vérifier le projet.
Il ne s'agit pas encore d'une APK Release signée avec la clé permanente.
Ne pas publier cette APK Debug sur Play Store et ne pas l'utiliser pour mettre
à jour une installation signée Release.
