Bellendar 1.1.60 — Fiabilisation de la suppression des événements synchronisés

- Vérification de l'existence de l'événement dans le calendrier source avant suppression.
- Une référence déjà absente de la source est traitée comme une suppression déjà effectuée (opération idempotente).
- Vérification des droits d'accès au calendrier source avant de tenter la suppression.
- Remplacement du message générique par le motif précis retourné par le fournisseur Android (droits insuffisants, source inaccessible, refus du fournisseur, etc.).
- Relecture des événements synchronisés après suppression pour rafraîchir l'affichage.
- Version Android : 1.1.60 (versionCode 69).
