Bellendar 1.1.59 — Enregistrement sans blocage de l'interface

- L'enregistrement local et la fermeture de la fiche événement sont effectués immédiatement.
- Les lectures/écritures du fournisseur de calendrier Android sont exécutées en arrière-plan (Dispatchers.IO).
- Le message initial indique que l'événement est enregistré dans Bellendar et que la mise à jour du calendrier est en cours.
- Le résultat final distingue l'ajout au calendrier Android sélectionné de la synchronisation ultérieure assurée par Android/Outlook.
- La lecture des événements du calendrier est également effectuée en arrière-plan.

La compilation et le test sur appareil restent à effectuer.
