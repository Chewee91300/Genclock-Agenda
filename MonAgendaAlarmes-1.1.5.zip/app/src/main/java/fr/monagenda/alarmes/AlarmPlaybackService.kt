package fr.monagenda.alarmes

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.Vibrator
import android.os.VibrationEffect
import android.os.VibratorManager
import android.net.Uri
import androidx.core.app.NotificationCompat

class AlarmPlaybackService : Service() {
    private var ringtone: Ringtone? = null
    private var eventId: Long = 0L
    private var vibrator: Vibrator? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SNOOZE) {
            val snooze = Intent(this, AlarmReceiver::class.java).apply {
                putExtra("title", intent.getStringExtra("title") ?: "Alarme")
                putExtra("description", intent.getStringExtra("description").orEmpty())
                putExtra("eventId", intent.getLongExtra("eventId", 0L))
                putExtra("alarmSoundUri", intent.getStringExtra("alarmSoundUri"))
                putExtra("vibrate", intent.getBooleanExtra("vibrate", true))
            }
            val pi = PendingIntent.getBroadcast(this, 991, snooze, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            val wakeAt = System.currentTimeMillis() + 5 * 60_000L
            try { am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, wakeAt, pi) }
            catch (_: SecurityException) { am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, wakeAt, pi) }
            stopSelf()
            return START_NOT_STICKY
        }
        val title = intent?.getStringExtra("title") ?: "Alarme"
        val description = intent?.getStringExtra("description").orEmpty()
        eventId = intent?.getLongExtra("eventId", 0L) ?: 0L
        val vibrate = intent?.getBooleanExtra("vibrate", true) ?: true
        val soundUri = intent?.getStringExtra("alarmSoundUri")?.let { Uri.parse(it) }
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification(title, description))
        try {
            if (ringtone == null) {
                val uri = soundUri ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) isLooping = true
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                    play()
                }
            }
        } catch (_: Exception) { }
        if (vibrate) startVibration()
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else (getSystemService(VIBRATOR_SERVICE) as Vibrator)
            val pattern = longArrayOf(0, 700, 350, 700)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            else vibrator?.vibrate(pattern, 0)
        } catch (_: Exception) { }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Alarmes Mon Agenda", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alarmes sonores de Mon Agenda"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            })
        }
    }

    private fun buildNotification(title: String, description: String): Notification {
        val fullScreen = PendingIntent.getActivity(this, 701, Intent(this, AlarmActivity::class.java).apply {
            putExtra("title", title); putExtra("description", description); putExtra("eventId", eventId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 702, Intent(this, AlarmPlaybackService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snoozeIntent = Intent(this, AlarmPlaybackService::class.java).apply {
            action = ACTION_SNOOZE
            putExtra("title", title); putExtra("description", description); putExtra("eventId", eventId)
        }
        val snooze = PendingIntent.getService(this, 703, snoozeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(description.ifBlank { "Alarme en cours" })
            .setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setOngoing(true)
            .setFullScreenIntent(fullScreen, true)
            .addAction(android.R.drawable.ic_media_pause, "Arrêter", stop)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "Répéter 5 min", snooze)
            .build()
    }

    override fun onDestroy() {
        try { ringtone?.stop() } catch (_: Exception) { }
        try { vibrator?.cancel() } catch (_: Exception) { }
        vibrator = null
        ringtone = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "agenda_full_alarm_v2"
        const val NOTIFICATION_ID = 8801
        const val ACTION_STOP = "fr.monagenda.alarmes.STOP_ALARM"
        const val ACTION_SNOOZE = "fr.monagenda.alarmes.SNOOZE_ALARM"
    }
}
