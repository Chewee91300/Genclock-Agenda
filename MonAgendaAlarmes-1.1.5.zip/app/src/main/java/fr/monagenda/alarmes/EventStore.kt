package fr.monagenda.alarmes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class EventStore(context: Context) {
    private val prefs = context.getSharedPreferences("agenda_events", Context.MODE_PRIVATE)

    fun load(): List<AgendaEvent> {
        val array = JSONArray(prefs.getString("events", "[]"))
        return (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                AgendaEvent(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    description = o.optString("description"),
                    timeMillis = o.getLong("timeMillis"),
                    reminderMode = o.getString("reminderMode"),
                    leadMinutes = o.getInt("leadMinutes"),
                    outlookEventId = if (o.has("outlookEventId") && !o.isNull("outlookEventId")) o.getLong("outlookEventId") else null,
                    alarmTimeMillis = if (o.has("alarmTimeMillis") && !o.isNull("alarmTimeMillis")) o.getLong("alarmTimeMillis") else null,
                    alarmSoundUri = o.optString("alarmSoundUri").takeIf { it.isNotBlank() },
                    vibrate = o.optBoolean("vibrate", true)
                )
            }.getOrNull()
        }.sortedBy { it.timeMillis }
    }

    fun save(events: List<AgendaEvent>) {
        val array = JSONArray()
        events.forEach { e ->
            array.put(JSONObject().apply {
                put("id", e.id)
                put("title", e.title)
                put("description", e.description)
                put("timeMillis", e.timeMillis)
                put("reminderMode", e.reminderMode)
                put("leadMinutes", e.leadMinutes)
                if (e.outlookEventId != null) put("outlookEventId", e.outlookEventId)
                if (e.alarmTimeMillis != null) put("alarmTimeMillis", e.alarmTimeMillis)
                if (e.alarmSoundUri != null) put("alarmSoundUri", e.alarmSoundUri)
                put("vibrate", e.vibrate)
            })
        }
        prefs.edit().putString("events", array.toString()).apply()
    }
}
