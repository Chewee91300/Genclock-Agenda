Bellendar 1.1.42

Correction de la réinitialisation des champs de l'éditeur lors de modifications successives d'un même événement.
Les états heure de début, heure de fin, présence d'une heure de fin et couleur sont désormais initialisés en tenant compte des valeurs de l'événement, et pas uniquement de son identifiant.
Un changement de couleur ne doit donc plus réafficher une ancienne heure de début ni effacer l'heure de fin enregistrée.

VersionName 1.1.42 / versionCode 52.
Compilation Android non exécutée dans cet environnement.
