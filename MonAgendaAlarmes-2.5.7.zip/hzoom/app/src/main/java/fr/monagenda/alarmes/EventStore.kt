package fr.monagenda.alarmes

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import android.util.Log
import java.security.MessageDigest

class EventStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("agenda_events", Context.MODE_PRIVATE)
    private val backupPrefs = context.getSharedPreferences("agenda_backup", Context.MODE_PRIVATE)
    private val backupFileName = "evenements_backup.json"
    private val attachmentsDirectoryName = "Pieces jointes"

    fun backupTreeUri(): Uri? = backupPrefs.getString("tree_uri", null)?.let { Uri.parse(it) }

    fun setBackupTreeUri(uri: Uri) {
        backupPrefs.edit().putString("tree_uri", uri.toString()).apply()
    }

    /**
     * Attache le dossier choisi par l'utilisateur.
     * Après réinstallation, la sauvegarde externe est prioritaire sur la liste locale
     * (qui est normalement vide). Une liste locale vide ne doit jamais écraser
     * une sauvegarde externe qui contient des événements.
     */
    fun attachBackupTree(uri: Uri, localEvents: List<AgendaEvent>): List<AgendaEvent> {
        setBackupTreeUri(uri)
        val externalEvents = readExternalBackup()
        return when {
            externalEvents.isNotEmpty() -> {
                prefs.edit().putString("events", serialize(externalEvents)).apply()
                externalEvents
            }
            localEvents.isNotEmpty() -> {
                writeExternalBackup(serialize(localEvents), localEvents.size)
                localEvents
            }
            else -> emptyList()
        }
    }

    fun load(): List<AgendaEvent> {
        val local = parse(prefs.getString("events", "[]") ?: "[]")
        if (local.isNotEmpty()) return local

        // Après réinstallation, les préférences privées sont vides : restaurer depuis le dossier choisi.
        val external = readExternalBackup()
        if (external.isNotEmpty()) {
            prefs.edit().putString("events", serialize(external)).apply()
            return external
        }
        return local
    }

    /**
     * Chaque sauvegarde est contrôlée après écriture :
     * - validation du JSON et du nombre d'événements ;
     * - relecture et comparaison SHA-256 ;
     * - remplacement du fichier principal seulement après validation du temporaire.
     * La dernière sauvegarde valide est conservée sous forme .previous.
     */
    fun save(events: List<AgendaEvent>) {
        val json = serialize(events)
        if (!isValidBackup(json, events.size)) {
            Log.e(TAG, "Sauvegarde refusée : données générées invalides")
            return
        }

        // commit() permet de vérifier que la copie locale a bien été enregistrée.
        val localWritten = prefs.edit().putString("events", json).commit()
        val localReadBack = prefs.getString("events", null)
        if (!localWritten || localReadBack == null || sha256(localReadBack) != sha256(json)) {
            Log.e(TAG, "Échec de vérification de la sauvegarde locale")
        }

        if (!writeExternalBackup(json, events.size)) {
            Log.w(TAG, "Sauvegarde externe non confirmée ; la copie locale reste disponible")
        }
    }

    private fun readExternalBackup(): List<AgendaEvent> = runCatching {
        val tree = backupTreeUri() ?: return emptyList()
        val directory = backupDirectory(tree) ?: return emptyList()
        val file = directory.findFile(backupFileName) ?: return emptyList()
        val input = context.contentResolver.openInputStream(file.uri) ?: return emptyList()
        val content = input.bufferedReader(Charsets.UTF_8).use { it.readText() }
        parse(content)
    }.getOrDefault(emptyList())

    private fun writeExternalBackup(json: String, expectedCount: Int): Boolean = runCatching {
        val tree = backupTreeUri() ?: return false
        val directory = backupDirectory(tree) ?: return false
        val tempName = "$backupFileName.tmp"
        val previousName = "$backupFileName.previous"

        // Un ancien temporaire incomplet n'est jamais considéré comme une sauvegarde.
        directory.findFile(tempName)?.delete()
        val temp = directory.createFile("application/json", tempName) ?: return false
        try {
            val output = context.contentResolver.openOutputStream(temp.uri, "wt") ?: return false
            output.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.write(json)
                writer.flush()
            }

            // Relecture réelle depuis le support choisi (mémoire externe, clé USB, etc.).
            val readBack = context.contentResolver.openInputStream(temp.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: return false
            if (sha256(readBack) != sha256(json) || !isValidBackup(readBack, expectedCount)) {
                Log.e(TAG, "Vérification de la sauvegarde externe échouée")
                return false
            }

            val current = directory.findFile(backupFileName)
            val previous = directory.findFile(previousName)
            // Ne jamais toucher à la sauvegarde courante avant d'avoir validé le temporaire.
            previous?.delete()
            if (current != null && !current.renameTo(previousName)) {
                Log.e(TAG, "Impossible de préserver l'ancienne sauvegarde")
                return false
            }
            if (!temp.renameTo(backupFileName)) {
                // Restauration de l'ancien fichier si la promotion du temporaire échoue.
                directory.findFile(previousName)?.renameTo(backupFileName)
                Log.e(TAG, "Impossible de finaliser la nouvelle sauvegarde")
                return false
            }

            // Dernier contrôle après renommage : le fichier officiel doit être lisible et identique.
            val finalFile = directory.findFile(backupFileName) ?: return false
            val finalContent = context.contentResolver.openInputStream(finalFile.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: return false
            val verified = sha256(finalContent) == sha256(json) && isValidBackup(finalContent, expectedCount)
            if (!verified) {
                finalFile.delete()
                directory.findFile(previousName)?.renameTo(backupFileName)
                Log.e(TAG, "Contrôle final échoué : restauration de la sauvegarde précédente")
                return false
            }
            true
        } finally {
            // Si l'écriture a échoué, le fichier temporaire n'est pas conservé comme backup.
            directory.findFile(tempName)?.delete()
        }
    }.getOrElse {
        Log.e(TAG, "Erreur pendant la sauvegarde externe", it)
        false
    }

    private fun isValidBackup(json: String, expectedCount: Int): Boolean = runCatching {
        val array = JSONArray(json)
        if (array.length() != expectedCount) return false
        // parse() ignore les éléments corrompus : on exige donc une correspondance exacte.
        parse(json).size == expectedCount
    }.getOrDefault(false)

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    companion object {
        private const val TAG = "EventStore"
    }


    private fun backupDirectory(tree: Uri): DocumentFile? {
        val root = DocumentFile.fromTreeUri(context, tree) ?: return null
        // Si l'utilisateur a sélectionné directement le dossier dédié, on l'utilise.
        if (root.name == "MonAgendaAlarmes") return root
        // Sinon, Documents est la racine autorisée : créer/utiliser son sous-dossier dédié.
        return root.findFile("MonAgendaAlarmes")?.takeIf { it.isDirectory }
            ?: root.createDirectory("MonAgendaAlarmes")
    }

    /**
     * Copie une pièce jointe dans Documents/MonAgendaAlarmes/Pieces jointes.
     * Le fichier est donc indépendant de son emplacement d'origine.
     */
    fun copyAttachment(sourceUri: Uri, eventId: Long): EventAttachment? = runCatching {
        val tree = backupTreeUri() ?: return null
        val directory = backupDirectory(tree) ?: return null
        val attachmentDirectory = directory.findFile(attachmentsDirectoryName)?.takeIf { it.isDirectory }
            ?: directory.createDirectory(attachmentsDirectoryName)
            ?: return null
        val sourceName = DocumentFile.fromSingleUri(context, sourceUri)?.name ?: "document"
        val safeName = sourceName.replace(Regex("[\\\\/:*?\\\"<>|]"), "_").take(100).ifBlank { "document" }
        val mime = context.contentResolver.getType(sourceUri) ?: "application/octet-stream"
        val uniqueName = "${eventId}_${System.currentTimeMillis()}_$safeName"
        val destination = attachmentDirectory.createFile(mime, uniqueName) ?: return null
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            context.contentResolver.openOutputStream(destination.uri, "w")?.use { output ->
                input.copyTo(output)
            } ?: return null
        } ?: return null
        EventAttachment(
            id = uniqueName,
            name = sourceName,
            uri = destination.uri.toString(),
            mimeType = mime
        )
    }.getOrNull()

    private fun serialize(events: List<AgendaEvent>): String {
        val array = JSONArray()
        events.forEach { e ->
            array.put(JSONObject().apply {
                put("id", e.id)
                put("title", e.title)
                put("description", e.description)
                put("timeMillis", e.timeMillis)
                // Conserver la fin dans la sauvegarde locale et le backup JSON.
                if (e.endTimeMillis != null) put("endTimeMillis", e.endTimeMillis)
                put("reminderMode", e.reminderMode)
                put("leadMinutes", e.leadMinutes)
                if (e.outlookEventId != null) put("outlookEventId", e.outlookEventId)
                if (e.alarmTimeMillis != null) put("alarmTimeMillis", e.alarmTimeMillis)
                if (e.alarmSoundUri != null) put("alarmSoundUri", e.alarmSoundUri)
                put("vibrate", e.vibrate)
                if (e.colorHex != null) put("colorHex", e.colorHex)
                put("recurrenceType", e.recurrenceType)
                put("recurrenceInterval", e.recurrenceInterval)
                put("recurrenceDays", JSONArray().apply { e.recurrenceDays.forEach { put(it) } })
                if (e.recurrenceEndMillis != null) put("recurrenceEndMillis", e.recurrenceEndMillis)
                if (e.recurrenceCount != null) put("recurrenceCount", e.recurrenceCount)
                if (e.seriesId != null) put("seriesId", e.seriesId)
                if (e.originalOccurrenceMillis != null) put("originalOccurrenceMillis", e.originalOccurrenceMillis)
                put("recurrenceExcludedMillis", JSONArray().apply { e.recurrenceExcludedMillis.forEach { put(it) } })
                put("attachments", JSONArray().apply {
                    e.attachments.forEach { attachment ->
                        put(JSONObject().apply {
                            put("id", attachment.id)
                            put("name", attachment.name)
                            put("uri", attachment.uri)
                            put("mimeType", attachment.mimeType)
                        })
                    }
                })
            })
        }
        return array.toString()
    }

    private fun parse(json: String): List<AgendaEvent> = runCatching {
        val array = JSONArray(json)
        (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                AgendaEvent(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    description = o.optString("description"),
                    timeMillis = o.getLong("timeMillis"),
                    endTimeMillis = if (o.has("endTimeMillis") && !o.isNull("endTimeMillis")) o.getLong("endTimeMillis") else null,
                    reminderMode = o.getString("reminderMode"),
                    leadMinutes = o.getInt("leadMinutes"),
                    outlookEventId = if (o.has("outlookEventId") && !o.isNull("outlookEventId")) o.getLong("outlookEventId") else null,
                    alarmTimeMillis = if (o.has("alarmTimeMillis") && !o.isNull("alarmTimeMillis")) o.getLong("alarmTimeMillis") else null,
                    alarmSoundUri = o.optString("alarmSoundUri").takeIf { it.isNotBlank() },
                    vibrate = o.optBoolean("vibrate", true),
                    colorHex = o.optString("colorHex").takeIf { it.matches(Regex("#[0-9A-Fa-f]{6}")) },
                    recurrenceType = o.optString("recurrenceType", "NONE"),
                    recurrenceInterval = o.optInt("recurrenceInterval", 1).coerceAtLeast(1),
                    recurrenceDays = (0 until (o.optJSONArray("recurrenceDays")?.length() ?: 0)).map { o.getJSONArray("recurrenceDays").getInt(it) },
                    recurrenceEndMillis = if (o.has("recurrenceEndMillis") && !o.isNull("recurrenceEndMillis")) o.getLong("recurrenceEndMillis") else null,
                    recurrenceCount = if (o.has("recurrenceCount") && !o.isNull("recurrenceCount")) o.getInt("recurrenceCount") else null,
                    seriesId = if (o.has("seriesId") && !o.isNull("seriesId")) o.getLong("seriesId") else null,
                    originalOccurrenceMillis = if (o.has("originalOccurrenceMillis") && !o.isNull("originalOccurrenceMillis")) o.getLong("originalOccurrenceMillis") else null,
                    recurrenceExcludedMillis = (0 until (o.optJSONArray("recurrenceExcludedMillis")?.length().orZero())).map { o.getJSONArray("recurrenceExcludedMillis").getLong(it) },
                    attachments = (0 until o.optJSONArray("attachments")?.length().orZero()).mapNotNull { index ->
                        runCatching {
                            val a = o.getJSONArray("attachments").getJSONObject(index)
                            EventAttachment(
                                id = a.getString("id"),
                                name = a.getString("name"),
                                uri = a.getString("uri"),
                                mimeType = a.optString("mimeType", "application/octet-stream")
                            )
                        }.getOrNull()
                    }
                )
            }.getOrNull()
        }.sortedBy { it.timeMillis }
    }.getOrDefault(emptyList())
}

private fun Int?.orZero(): Int = this ?: 0
