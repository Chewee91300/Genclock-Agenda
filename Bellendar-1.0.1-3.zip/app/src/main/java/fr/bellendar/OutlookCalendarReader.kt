package fr.bellendar

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.Calendar

data class DeviceCalendar(val id: Long, val displayName: String, val accountName: String, val accountType: String)

object OutlookCalendarReader {
    private const val PREFS_NAME = "calendar_sync"
    private const val KEY_SELECTED_IDS = "selected_calendar_ids"

    fun listCalendars(context: Context): List<DeviceCalendar> {
        if (!hasPermission(context)) return emptyList()
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME, CalendarContract.Calendars.ACCOUNT_NAME, CalendarContract.Calendars.ACCOUNT_TYPE)
        val result = mutableListOf<DeviceCalendar>()
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, "${CalendarContract.Calendars.VISIBLE}=1", null, "${CalendarContract.Calendars.ACCOUNT_NAME} ASC, ${CalendarContract.Calendars.CALENDAR_DISPLAY_NAME} ASC")?.use { cursor ->
            val id = cursor.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
            val name = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
            val account = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_NAME)
            val type = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_TYPE)
            while (cursor.moveToNext()) result += DeviceCalendar(cursor.getLong(id), cursor.getString(name).orEmpty().ifBlank { "Calendrier" }, cursor.getString(account).orEmpty(), cursor.getString(type).orEmpty())
        }
        return result
    }

    fun selectedCalendarIds(context: Context, calendars: List<DeviceCalendar> = listCalendars(context)): Set<Long> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_SELECTED_IDS)) return calendars.map { it.id }.toSet()
        return prefs.getStringSet(KEY_SELECTED_IDS, emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun saveSelectedCalendarIds(context: Context, ids: Set<Long>) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putStringSet(KEY_SELECTED_IDS, ids.map { it.toString() }.toSet()).apply()
    }

    /** Retourne un calendrier sélectionné et réellement modifiable par l'application. */
    fun firstWritableSelectedCalendarId(context: Context): Long? {
        if (!hasPermission(context) || !hasWritePermission(context)) return null
        val selected = selectedCalendarIds(context)
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.SYNC_EVENTS,
            CalendarContract.Calendars.VISIBLE
        )
        var destination: Long? = null
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            null,
            null,
            "${CalendarContract.Calendars._ID} ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
            val accessCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
            val syncCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.SYNC_EVENTS)
            val visibleCol = cursor.getColumnIndexOrThrow(CalendarContract.Calendars.VISIBLE)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val access = cursor.getInt(accessCol)
                val syncEnabled = cursor.getInt(syncCol) == 1
                val visible = cursor.getInt(visibleCol) == 1
                if (visible && syncEnabled && access >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR &&
                    (selected.isEmpty() || id in selected)
                ) {
                    destination = id
                    break
                }
            }
        }
        return destination
    }

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    fun readEvents(context: Context, selectedCalendarIds: Set<Long> = selectedCalendarIds(context)): List<AgendaEvent> {
        if (!hasPermission(context)) return emptyList()

        val now = Calendar.getInstance()
        val begin = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            add(Calendar.YEAR, -1)
            set(Calendar.MONTH, Calendar.JANUARY)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }.timeInMillis
        val end = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            add(Calendar.YEAR, 2)
            set(Calendar.MONTH, Calendar.DECEMBER)
            set(Calendar.DAY_OF_MONTH, 31)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
        }.timeInMillis

        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(builder, begin)
        android.content.ContentUris.appendId(builder, end)

        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.CALENDAR_ID
        )
        val result = mutableListOf<AgendaEvent>()
        context.contentResolver.query(
            builder.build(),
            projection,
            null,
            null,
            "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
            val titleCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
            val beginCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
            val descCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.DESCRIPTION)
            val calendarCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_ID)
            while (cursor.moveToNext()) {
                val language = context.getSharedPreferences("interface", Context.MODE_PRIVATE).getString("app_language", "fr") ?: "fr"
                val title = cursor.getString(titleCol).orEmpty().ifBlank {
                    when (language) { "en" -> "(Untitled)"; "es" -> "(Sin título)"; "de" -> "(Ohne Titel)"; else -> "(Sans titre)" }
                }
                val start = cursor.getLong(beginCol)
                val eventId = cursor.getLong(idCol)
                val calendarId = cursor.getLong(calendarCol)
                if (calendarId !in selectedCalendarIds) continue
                val description = cursor.getString(descCol).orEmpty()
                // Distinct negative IDs keep imported entries separate from locally-created events.
                val stableId = -((eventId * 100_003L) + ((start / 60_000L) % 100_003L) + 1L)
                result += AgendaEvent(
                    id = stableId,
                    title = title,
                    description = if (description.isBlank()) when (language) {
                        "en" -> "Android calendar synchronized (Outlook or another account)"
                        "es" -> "Calendario de Android sincronizado (Outlook u otra cuenta)"
                        "de" -> "Synchronisierter Android-Kalender (Outlook oder anderes Konto)"
                        else -> "Calendrier Android synchronisé (Outlook ou autre compte)"
                    } else description,
                    timeMillis = start,
                    reminderMode = "outlook",
                    leadMinutes = 0,
                    outlookEventId = eventId
                )
            }
        }
        return result.distinctBy { it.id }
    }

    fun deleteEvent(context: Context, event: AgendaEvent): Boolean {
        if (!hasWritePermission(context) || event.outlookEventId == null) return false
        return runCatching {
            val uri = android.content.ContentUris.withAppendedId(
                CalendarContract.Events.CONTENT_URI, event.outlookEventId
            )
            context.contentResolver.delete(uri, null, null) > 0
        }.getOrDefault(false)
    }

    /** Crée ou met à jour les événements locaux dans le calendrier choisi. */
    fun syncLocalEventsToCalendar(context: Context, localEvents: List<AgendaEvent>, calendarId: Long): List<AgendaEvent> {
        if (!hasWritePermission(context)) return localEvents
        val resolver = context.contentResolver
        val result = localEvents.toMutableList()
        localEvents.forEachIndexed { index, event ->
            // Les événements importés d'Outlook ont un identifiant local négatif : ne pas les réexporter.
            if (event.id < 0 || event.reminderMode == "outlook") return@forEachIndexed
            val values = android.content.ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calendarId)
                put(CalendarContract.Events.TITLE, event.title)
                put(CalendarContract.Events.DESCRIPTION, event.description)
                put(CalendarContract.Events.DTSTART, event.timeMillis)
                put(CalendarContract.Events.DTEND, event.endTimeMillis ?: (event.timeMillis + 60L * 60L * 1000L))
                put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 0)
            }
            val uri = runCatching {
                val linkedId = event.outlookEventId
                if (linkedId != null) {
                    val eventUri = android.content.ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, linkedId)
                    val updated = resolver.update(eventUri, values, null, null)
                    if (updated > 0) eventUri else null
                } else resolver.insert(CalendarContract.Events.CONTENT_URI, values)
            }.getOrNull()
            if (uri != null) {
                val newId = android.content.ContentUris.parseId(uri)
                result[index] = event.copy(outlookEventId = newId)
            }
        }
        return result
    }

    fun hasWritePermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

}
